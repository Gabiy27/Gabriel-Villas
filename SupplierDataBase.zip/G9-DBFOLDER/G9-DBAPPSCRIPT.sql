 -- Supplier & Product Purchasing Management (Food/ Perishable Ingredients)


DROP SCHEMA IF EXISTS purchase_db;
CREATE SCHEMA IF NOT EXISTS purchase_db;
USE purchase_db;

-- -----------------------------------------------------
-- Table address
-- -----------------------------------------------------
DROP TABLE IF EXISTS address;
CREATE TABLE IF NOT EXISTS address (
	address_id			INT(10) NOT NULL,
    stno				VARCHAR(45),
    stname				VARCHAR(45),
    brgy				VARCHAR(45),
    city				VARCHAR(45),
    province			VARCHAR(45),
    zipcode				VARCHAR(45),
    
    PRIMARY KEY			(address_id),
    INDEX				(address_id ASC)
);


-- -----------------------------------------------------
-- Table storage_information
-- -----------------------------------------------------
DROP TABLE IF EXISTS storage_information;
CREATE TABLE IF NOT EXISTS storage_information (
  
  location_id			INT(5) NOT NULL,
  location_name			VARCHAR(45),
  date_stored			DATE,
  location_addressid	INT(10),
  
  PRIMARY KEY			(location_id),
  INDEX					(location_id ASC),

  FOREIGN KEY			(location_addressid)
	REFERENCES			address(address_id) ON DELETE CASCADE
);


-- -----------------------------------------------------
-- Table supplier_information
-- -----------------------------------------------------
DROP TABLE IF EXISTS supplier_information;
CREATE TABLE IF NOT EXISTS supplier_information (
  supplier_id			INT(5) NOT NULL,
  supplier_name			VARCHAR(45),
  supplier_contactnum 	BIGINT(10),
  product_sold			VARCHAR(45),
  supplier_addressid	INT(10),
  
  PRIMARY KEY			(supplier_id),
  INDEX					(supplier_id ASC),
  
  FOREIGN KEY			(supplier_addressid)
	REFERENCES			address(address_id) ON DELETE CASCADE
);


-- -----------------------------------------------------
-- Table product_information
-- -----------------------------------------------------
DROP TABLE IF EXISTS product_information;
CREATE TABLE IF NOT EXISTS product_information (
  product_id			INT(10) NOT NULL,
  product_category		ENUM('Dairy', 'Fats', 'Fruits', 'Grain', 'Herbs & Spices', 'Meat', 'Pasta', 'Vegetables', 'Others'),
  product_name		 	VARCHAR(45),
  product_measurement	VARCHAR(45),
  product_retailprice	FLOAT,
  
  PRIMARY KEY			(product_id),
  INDEX					(product_id ASC)
);


-- -----------------------------------------------------
-- Table purchaser
-- -----------------------------------------------------
DROP TABLE IF EXISTS purchaser;
CREATE TABLE IF NOT EXISTS purchaser (
	purchaser_id			INT(5) NOT NULL,
    purchaser_position		VARCHAR(45),
    purchaser_lastname		VARCHAR(45),
    purchaser_firstname		VARCHAR(45),
    purchaser_mi			VARCHAR(45),
    purchaser_mobilenum		BIGINT(10),
    
    PRIMARY KEY				(purchaser_id),
    INDEX					(purchaser_id ASC)
);


-- -----------------------------------------------------
-- Table purchase
-- -----------------------------------------------------
DROP TABLE IF EXISTS purchase;
CREATE TABLE IF NOT EXISTS purchase (
  purchase_id				INT(10) NOT NULL,
  date_purchased			DATE,
  quantity_bought			INT,
  unit_price				FLOAT,
  product_expirationdate	DATE,
  supplier_fromid			INT(5),
  product_purchasedid		INT(10),
  purchaser_id				INT(5),
  location_storedid			INT(5),
  
  PRIMARY KEY			(purchase_id),
  INDEX					(purchase_id ASC),
  
  FOREIGN KEY			(supplier_fromid)
	REFERENCES			supplier_information(supplier_id),
  FOREIGN KEY			(product_purchasedid)
	REFERENCES			product_information(product_id),
  FOREIGN KEY			(purchaser_id)
	REFERENCES			purchaser(purchaser_id),
  FOREIGN KEY			(location_storedid)
	REFERENCES			storage_information(location_id)
);


-- -----------------------------------------------------
-- Table inventory
-- -----------------------------------------------------
DROP TABLE IF EXISTS inventory;
CREATE TABLE IF NOT EXISTS inventory (
	inventory_id		INT(10),
    product_id			INT(10),
    purchase_id			INT(10),
    
    PRIMARY KEY			(inventory_id),
    INDEX				(inventory_id ASC),
    
    FOREIGN KEY			(product_id)
		REFERENCES		product_information(product_id),
	FOREIGN KEY			(purchase_id)
		REFERENCES		purchase(purchase_id)
);

-- -----------------------------------------------------
-- Add records to address
-- -----------------------------------------------------
INSERT INTO address
	VALUES	(90000000, 16, 'Leon Guinto St.', '2921', 'Manila', 'NCR', '1000'), -- Suppliers
			(90000001, 21, 'Taft Ave.', '2001', 'Manila', 'NCR', '1001'),
            (90000002, 43, 'Boni Ave.', '2121', 'Mandaluyong', 'NCR', '1550'),
            (90000003, 71, 'Leonard Wood Rd.', 'Quezon Hill Proper', 'Baguio', 'CAR', '2600'), -- Storage Locations
            (90000004, 12, 'Session Road', 'Session Road Area', 'Baguio', 'CAR', '2600'),
            (90000005, 01, 'Kisad Road', 'Military Cut-off', 'Baguio', 'CAR', '2600');


-- -----------------------------------------------------
-- Add records to storage_information
-- -----------------------------------------------------
INSERT INTO storage_information
	VALUES 	(40000, 'Warehouse Alpha', '2023-07-16', 90000003),
			(40001, 'Warehouse Bravo', '2023-10-16', 90000004),
            (40002, 'Miguels Apartment', '2022-01-01', 90000005);


-- -----------------------------------------------------
-- Add records to supplier_information
-- -----------------------------------------------------
INSERT INTO supplier_information
	VALUES	(10000, 'Johns Paultry Shop', 9599804054, 'Meat', '90000000'),
			(10001, 'MS More Save', 9639021224, 'Vegetables', '90000001'),
            (10002, 'Bigas Bros', 9750385893, 'Grains', '90000002');


-- -----------------------------------------------------
-- Add records to product_information
-- -----------------------------------------------------
INSERT INTO product_information
	VALUES	(20000000, 'Meat', 'Frozen Pigeon', 'Per Pieces', 189.00),
			(20000001, 'Vegetables', 'Baguio Beans', 'Per Kilo', 23.50),
            (20000002, 'Grain', 'Basmati Rice', 'Per Kilo', 64.00);



-- -----------------------------------------------------
-- Add records to purchaser
-- -----------------------------------------------------
INSERT INTO purchaser
	VALUES	(50000, 'Clerk', 'Yap', 'Timmy', 'O.', 9397804615),
			(50001, 'Assisstant', 'Chuck', 'Christian', 'P.', 9865431964),
            (50002, 'Manager', 'Cancion', 'Miguel', 'A.', 9764563210);

-- -----------------------------------------------------
-- Add records to purchase
-- -----------------------------------------------------
INSERT INTO purchase
	VALUES	(30000000, '2023-07-15', 20, 170.00, '2023-12-03', 10000, 20000000, 50000, 40000), 
			(30000001, '2023-10-14', 20, 27.00, '2023-11-11', 10001, 20000001, 50001, 40001), 
            (30000002, '2022-01-01', 20, 60.75, '2024-01-01', 10002, 20000002, 50002, 40002);  
            

-- -----------------------------------------------------
-- Add records to inventory
-- -----------------------------------------------------
INSERT INTO inventory
	VALUES	(70000000, 20000000, 30000000),
			(70000001, 20000001, 30000001),
            (70000002, 20000002, 30000002);
