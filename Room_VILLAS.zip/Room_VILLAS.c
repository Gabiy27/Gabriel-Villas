/******************************************************************************
This is to certify that this project is my own & partners work, based on
my/our personal efforts in studying and applying the concepts learned. I/we
have constructed the functions and their respective algorithms and
corresponding code by me (and my partner). The program was run, tested, and
debugged by my own efforts. I further certify that I have not copied in
part or whole or otherwise plagiarized the work of other students and/or
persons.
<Gabriel N. Villas> - <12030325> - <S12>
******************************************************************************/
#include <stdio.h>
#include <string.h>
#define MAX 100
// typedef for admin module

typedef char DLSUBuildingName [2]; 
typedef char DLSURoomNumber [5];
typedef char DLSUCompleteRoom [50]; 
typedef char DLSUTypeRoom [20]; 
typedef char DLSUTimeSlot [40]; 

// typedef  for room reservation 
typedef char WholeName [30];

// Sturct for Room data
struct RoomData {
	DLSUBuildingName building; 
	DLSURoomNumber roomnumber;
	DLSUTypeRoom roomtype; 
	int capacity; 
	int nRooms; 
};

// struct reserve room
struct UserRoomReserve {
	DLSUBuildingName building; 
	DLSURoomNumber roomnumber;
	DLSUTypeRoom roomtype; 
	int capacity; 
};

// Struct for date today 
struct DateToday {
	int day;
	int month; 
	int year; 
};

// Struct for student info
struct StudentInfo 
{
	char IDnumber [9]; 
	int Year; 
	char Program [20]; 
	char Firstname [20];
	char Lastname [20];
};

// Struct for room reservation 
struct RoomReserve 
{
	struct StudentInfo InfoStudent; 
	struct DateToday TodayDate; 
	struct UserRoomReserve ReserveRoomUser; 
	int Reserveday;
	int Reservemonth; 
	int Reserveyear; 
	char weekofday [15]; 
	int participants; 
	char desciptionofactivity [60]; 
	int reservecount; 
	DLSUTimeSlot timeslot; 
	DLSUTimeSlot consecutivetimeslot; 
};

// Displays Divider for menu
void printDivider ()
{

printf ("\t\t=======================================\n"); 	
	
}

// prints another divider
void printDivider2 ()
{
	printf ("________________________________\n"); 
}

// Displays Menu
void displayMenu ()
{
	
	printDivider(); 
	printf ("\t\t\t DE LA SALLE UNIVERSITY \n");
	printDivider(); 
	printf ("\t\t\tMY LA SALLE ROOM RESERVATION \n"); 
	printDivider ();
	printf ("\t\t\t [1] Admin Module  \n");
	printf ("\t\t\t [2] Reserve a Room \n");
	printf ("\t\t\t [3] Exit \n");
	printf ("\t\t\t Enter Choice: ");
}

// Displays admin prompt
void displayAdminPrompt ()
{
	printDivider2 ();
	printf ("\n\tADMIN MODULE\n"); 
	printDivider2 ();
	printf ("Welcome to the Admin Module! \n");
 
}

// displays room reservation title
void displayRoomReservationPrompt ()
{
	printDivider2 ();
	printf ("Room Reservation\n");
	printDivider2 ();
	
}

// Displays choice prompt
void displayChoicePrompt ()
{
	printf ("[1] Continue to Admin Module? \n");
	printf ("[2] Go to Room Reservation \n"); 
	
}

// Displays Time Slots
void displayTimeSlots (DLSUTimeSlot TimeSlotMTHF [], DLSUTimeSlot TimeSlotWS [], int weekofday)
{
	int i; 
	switch (weekofday)
	{
	// Displays timeslots for Monday, Thursday, Tuesday, Friday
	
	case 1: 
	printDivider2 ();
	printf ("TimeSlots for M T H F \n");
	printDivider2 ();
	for ( i = 0; i < 6 ; i++)
	{
		printf ("[%d] %s \n", i+1, TimeSlotMTHF [i]);
	}
	break; 
	// Displays timeslots for Wednesday and Saturday 
	case 2:
	printDivider2 ();
	printf ("TimeSlots for W S\n");
	printDivider2 ();
	for ( i = 0; i < 3 ; i++)
	{
		printf ("[%d] %s \n", i+1, TimeSlotWS [i]);
	}
	printDivider2 ();
	}
}
// Displays type of room
void displayTypeofRoom ()
{
	int i; 
	DLSUTypeRoom TypeRoom [4] = {"classroom", "seminar room", "auditorium", "training room"}; 
	printf ("The Type of Rooms are: \n");
	
	for (i = 0; i < 4; i ++)
	{
		printf ("[%d] %s \n", i + 1, TypeRoom [i]); 
	}
	printDivider2 (); 
	printf ("Enter the number corresponding to the type of room :");
}

/* function inputs type of room
@param CompleteRoom [] - struct variable containing the room data
@return none
Pre-condition: CompleteRoom [].roomtype is variable containg room type which is only from choice 1 to 4 */
void inputTypeRoom (struct RoomData CompleteRoom [])
{
	int i; 
	int nChoice; 
	printDivider2 (); 
	displayTypeofRoom (); 
	printf ("\n"); 
	for (i = 0; i < CompleteRoom[i].nRooms; i++)
	{
		printf ("What type of room is room (%s%s) ?: ", CompleteRoom [i].building, CompleteRoom [i].roomnumber ); 
		scanf (" %d", &nChoice); 
		while (nChoice > 4 || nChoice < 0) // checks if invalid
		{
		printf ("Invalid Input! \n"); 
		printf ("What type of room is room (%s%s) ?: ", CompleteRoom [i].building, CompleteRoom [i].roomnumber ); 
		scanf (" %d", &nChoice);
		}
		if (nChoice == 1)
		{
			strcpy (CompleteRoom [i].roomtype, " classroom");
		}
		else if (nChoice == 2)
		{
			strcpy (CompleteRoom [i].roomtype, " seminar room");
		}
		else if (nChoice == 3)
		{
			strcpy (CompleteRoom [i].roomtype, " auditorium");
		}
		else if (nChoice == 4)
		{
			strcpy (CompleteRoom [i].roomtype, " training room");
		}
		
	}
	printDivider2 ();
	printf ("Your current inputs are: \n"); 
	printf ("Room Number| Type of Room \n");
	printDivider2 (); 
	for (i = 0 ; i < CompleteRoom[i].nRooms; i++)
	{
	printf ("%s%s %s\n", CompleteRoom [i].building, CompleteRoom [i].roomnumber, CompleteRoom [i].roomtype); 
	}
}

/* function inputs capacity of the room
@param CompleteRoom [] - struct variable containing the room data
@return none
Pre-condition: CompleteRoom[].Capacity contains capacity of the room */
void inputCapacity (struct RoomData CompleteRoom [])
{ 
	int i; 
	printDivider2 ();
	for (i = 0; i < CompleteRoom[i].nRooms; i++)
	{
		printf ("Enter Capacity [%s%s]: ", CompleteRoom [i].building, CompleteRoom [i].roomnumber);
		scanf (" %d", &CompleteRoom [i].capacity); 
		if (CompleteRoom [i].capacity  < 0 || CompleteRoom [i].capacity > 100) // checks if invalid input 
		{
		printf ("Invalid Input ! \n"); 
		printf ("Enter Capacity [%s%s]: ", CompleteRoom [i].building, CompleteRoom [i].roomnumber);
		scanf (" %d", &CompleteRoom [i].capacity); 
		}
	
	}
	printf ("\n");
	printDivider2 (); 
	printf ("Your current inputs are: \n"); 
	printDivider2 (); 
	printf ("Room Number\t| Type of Room \t | Capacity \n");
	printDivider2 (); 
	for (i = 0 ; i < CompleteRoom[i].nRooms; i++)
	{
	printf ("%s%s %s %d\n", CompleteRoom [i].building, CompleteRoom [i].roomnumber, CompleteRoom[i].roomtype, CompleteRoom[i].capacity); 
	} 
}


// Activity Completion Prompt
void displayActivityCompletionPrompt ()
{
	printDivider2 ();
	printf ("Welcome to Activity Completion checker \n"); 
	printDivider2 ();
	printf ("Check Activity to be checked on the list below: \n"); 	
}


/* function displays contents of Admin module
@param CompleteRoom [] - struct variable containing the room data
@return none
Pre condition: User inputs room number and building letter  */
void displayAdminMenu (struct RoomData CompleteRoom [])
{
	int i; 
	int RoomNumLength;
	int len; 
	int compare; 
	int nChoice; 
	int RoomInput; 
	struct RoomData temp; 
	// displays admin prompt 
	displayAdminPrompt ();

	 // encode room data 
	printf ("How many Rooms will you input ? : \n");
	scanf (" %d", &RoomInput);
	// asks user for first letter of building and room number
	for (i = 0; i < RoomInput;  i++)
	{
		CompleteRoom[i].nRooms = RoomInput; 
		printf ("Enter the first letter of the building: ");
		scanf (" %s", CompleteRoom[i].building); 
		// Checks for building letter
		len = strlen (CompleteRoom[i].building); 	
		while ( len > 1)
		{
			printf ("Invalid input! \n");
			printf ("Note: only input a single alphabetical character\n"); 
			scanf (" %s", CompleteRoom[i].building); 
			len = strlen (CompleteRoom[i].building); 
		}
	
		printf ("Enter the room number: ");
		scanf (" %s", CompleteRoom [i].roomnumber); 

		// checks if valid room number 
		RoomNumLength = strlen (CompleteRoom [i].roomnumber); 
		while (RoomNumLength > 4 || RoomNumLength < 3)
		{
			printf ("Invalid Room Number!\n");
			printf ("Enter the Room number: ");
			scanf (" %s", CompleteRoom [i].roomnumber); 
			RoomNumLength = strlen (CompleteRoom [i].roomnumber); 
		}
		// Concatinates 0 to a room number that has 3 digits
		if (RoomNumLength == 3)
		{
			strcpy (temp.roomnumber, CompleteRoom [i].roomnumber );
			strcpy (CompleteRoom [i].roomnumber, "0"); 
			strcat (CompleteRoom [i].roomnumber, temp.roomnumber); 
			// displays the room number
			printf ("The Room Number is %s%s\n", CompleteRoom [i].building, CompleteRoom[i].roomnumber);
		}
		else
		{
			printf ("The Room Number is %s%s\n", CompleteRoom [i].building, CompleteRoom[i].roomnumber);
		}
		
		
	}
	
	// Input type of room 
	inputTypeRoom (CompleteRoom); 
	
	// Input capacity 
	inputCapacity (CompleteRoom); 

}

// Displays room that can be reseved
void displayRoomToReserve (struct RoomData CompleteRoom [])
{
	int i; 
	printf ("\n");
	printDivider2 ();
	printf ("Current Available Rooms: \n"); 
	for (i = 0; i < CompleteRoom[i].nRooms; i++)
	{
		printf ("[%d] %s%s %s %d\n", i + 1 , CompleteRoom [i].building, CompleteRoom[i].roomnumber, CompleteRoom[i].roomtype, CompleteRoom[i].capacity );
	}
	printDivider2 ();
}

/* function displays contents of Admin module
@param CompleteRoom [] - struct variable containing the room data
@param count - number of students
@return none
Pre condition: User inputs date today  */
void inputDateToday (struct RoomReserve User [], int count)
{
	printf ("Enter Date today \n ");
	printf ("Enter Day : ");
	scanf (" %d", &(User + count)->TodayDate.day);
	printf ("Enter Month: ");
	scanf (" %d", &(User + count)->TodayDate.month);
	printf ("Enter Year:");
	scanf (" %d", &(User + count)->TodayDate.year); 
}

// displays date today
void displayDateToday (struct RoomReserve User [], int count)
{
	printf ("Date Today : [%d/%d/%d]\n", (User + count)->TodayDate.day, (User + count)->TodayDate.month, (User + count)->TodayDate.year); 
}

/* function checks ID number
@param User [] - struct variable containing the student's data
@param count the number of students 
@return none
Pre-condition: User[].IDnumber contains only 8 string length */
void checkIDnumber (struct RoomReserve User [], int count)
{
	int len;
	len = strlen ((User + count)->InfoStudent.IDnumber); 
	while (len != 8)
	{
		printf ("Invalid ID number \n");
		printf ("Enter ID number:"); 
		scanf (" %s", &(User + count)->InfoStudent.IDnumber);
		len = strlen ((User + count)->InfoStudent.IDnumber);
	}
}

// User inputs ID number
void inputIDNum (struct RoomReserve User [], int count)
{
	int len;
	// asks user ID number 
	printf ("Enter ID number:"); 
	scanf (" %s", &(User + count)->InfoStudent.IDnumber);

	// Checks if valid ID number
	checkIDnumber (User, count); 
}

//User inputs first name
void inputFirstName (struct RoomReserve User [], int count)
{
	// Asks user for First and Last name
	printf ("Enter First Name: "); 
	scanf (" %s", &(User + count)->InfoStudent.Firstname );
}

//user inputs Last name
void inputLastName (struct RoomReserve User [], int count)
{
	// Asks user for First and Last name
	printf ("Enter Last name: ");
	scanf (" %s", &(User + count)->InfoStudent.Lastname );
}

// User inputs year level 
void inputYearLevel (struct RoomReserve User [], int count)
{
	// Input year level 
	printf ("Enter year level: ");
	scanf (" %d", &(User + count)->InfoStudent.Year);
}

// User input degree program
void inputDegreeProgram (struct RoomReserve User [], int count)
{
	printf ("Enter degree program:");
	scanf (" %s", &(User + count)->InfoStudent.Program); 
	printf ("\n"); // Space
}


// Asks user date of reservation 
void inputDateReservation (struct RoomReserve User [], int count)
{
	printDivider2 ();
	printf ("Date of Reservation \n");
	printf ("Enter Day of reservation : ");
	scanf (" %d", &(User + count)->Reserveday);
	printf ("Enter Month of reservation : ");
	scanf (" %d", &(User + count)->Reservemonth);
	printf ("Enter Year of reservation: ");
	scanf (" %d", &(User+ count)->Reserveyear); 
 
}

/* function checks number of particpants is less than or equal to capacity
@param CompleteRoom [] - struct variable containing the room data
@param User [] - struct variable containg student's data
@param room choice - choice of the room of the student
@param count - number of students 
@return none
Pre-condition: User[].participants should be less than or equal to CompleteRoom [].capacity */
void checkNumberofParticipants (struct RoomReserve User [], struct RoomData CompleteRoom[],  int RoomChoice, int count)
{
	while (User [count].participants >  CompleteRoom [RoomChoice - 1].capacity )
	{
		printf ("Invalid participants\n");
		printf ("Participants must be less than or equal to %d\n", CompleteRoom [RoomChoice - 1].capacity );
		printf ("Enter number of participants: ");
		scanf ("%d", &User[count].participants); 
	}
}

// displays add consecutive time prompt
void displayAddTimePrompt (int addconsecutivetime)
{
		printf ("Add a consecutive time?: \n");
		printf ("[1] Yes\n");
		printf ("[2] No \n"); 
		scanf (" %d", &addconsecutivetime);
 } 
 
// displays exit prompt
 void displayExitPrompt ()
 {
 	printf ("\n [Thank you for using MY LASALLE ROOM RESERVATION!] \n");
 }
/* function checks number of particpants is less than or equal to capacity
@param User [] - struct variable containg student's data
@param maxcount - max reservation count
@return 0
Pre-condition: User[].participants should be less than or equal to CompleteRoom [].capacity */
int checkMaxReservation (struct RoomReserve User [], int maxcount)
{
	if (User[maxcount].reservecount < 0 )
	{
		return 0; 
	}
}

// Yes or no prompt
void displayYesorNo ()
{
	printf ("[1] Yes\n");
	printf ("[2] No\n");
}

// displays room of the reserver 
void displayReserverRooms (struct RoomReserve User [], int count )
{
	int i; 
	printf ("The Room you reserve: \n");
	for (i = 0; i <= count; i++ )
	{
		printf ("ID number: %s\n", User[count].InfoStudent.IDnumber); 
		printf ("Date Today: [%d/%d/%d]\n", User[count].TodayDate.day, User[count].TodayDate.month, User[count].TodayDate.year  ); 
		printf ("Reservation Date: %d/%d/%d\n", User [i].Reserveday, User [i].Reservemonth, User [i].Reserveyear);
		printf ("[%d] %s%s %s %d/%d \n",  i + 1, User[i].ReserveRoomUser.building, User[i].ReserveRoomUser.roomnumber, User[i].ReserveRoomUser.roomtype, User[i].participants, User[i].ReserveRoomUser.capacity);
	}
}

/* function checks if cancel date is valid
@param User [] - struct variable containing the student's data
@param count - number of students
@return none
Pre-condition: User inputs date today and cancelling on the same day */
int checkCancelDate (struct RoomReserve User[], int count)
{
	if ( User[count].Reserveday == User[count].TodayDate.day && User[count].Reservemonth == User[count].TodayDate.month && User[count].Reserveyear == User[count].TodayDate.year )
	{
		printf ("Sorry but you cannot cancel on the same day \n "); 
		return 0;
	}
}

/* function cancels a room reservation
@param User [] - struct variable containing the student's data
@param count - number of students
@return none
Pre-condition: User inputs date today and cancelling on the same day */
void CancelRoom (struct RoomReserve User [], int count )
{
	int CancelChoice; 
	int CancelAgain; 
	int cancel = 1; 
	cancel = checkCancelDate (User, count);
	if (cancel == 1)
	{
		do
		{
			printDivider2 (); 
			displayReserverRooms (User, count );
			printf ("What room will you want to cancel? \n"); 
			scanf (" %d", &CancelChoice);
			strcpy (User [CancelChoice - 1].ReserveRoomUser.building, " "); 
			strcpy (User [CancelChoice - 1].ReserveRoomUser.roomnumber,  " "); 
			strcpy (User [CancelChoice - 1].ReserveRoomUser.roomtype,  " "); 
			User [CancelChoice - 1].ReserveRoomUser.capacity = 0;
			User [CancelChoice - 1].participants = 0;
			printf ("would you like to cancel again? \n"); 
			displayYesorNo ();
			scanf (" %d", &CancelAgain); 
		} while (CancelAgain == 1);
	}

	printf ("Your remaining reserved rooms : \n");
	displayReserverRooms (User, count );
	printDivider2 (); 

}

// displays option prompt
void optionPrompt ()
{
	printDivider ();
	printf ("\t\t[1] Reserve again \n"); 
	printf ("\t\t[2] Cancel a room \n");
	printf ("\t\t[3] Exit\n");
	printDivider ();
	printf ("\t\tEnter Choice: "); 
}

//displays will reserve again prompt
void displayWillReserveAgainPrompt ()
{
	printf ("will you like to reserve time again?\n");
	displayYesorNo (); 
}

//displays add consecutive time prompt
void displayAddConsecutiveTimePrompt ()
{
		printf ("Add a consecutive time?: \n");
		printf ("[1] Yes\n");
		printf ("[2] No \n"); 
}


/* function displays room reservation
@param CompleteRoom [] - struct variable containing the room data
@param User [] - struct containg user's data
@param TimeSlotMTHF [] - timeslots for monday, tuesday, thursday, friday
@param TimeSlotWS [] - timeslots for saturday and sunday
@param count - number of students
@return none
Pre-condition: User input room reservation data */
int RoomReservation (struct RoomData CompleteRoom [], struct RoomReserve User [], DLSUTimeSlot TimeSlotMTHF [], DLSUTimeSlot TimeSlotWS [], int count)
{

 	// variable declaration 
 	int TimeChoice; 
 	int i; 
 	int RoomChoice; 
 	int weekofdaychoice; 
 	int addtime = 0; 
 	int nChoice;  
 	int addtimechoice = 0; 
 	int addconsecutivetimeMTHF; 
 	int addconsecutivetimeWS; 
 	int reservecontinue; 
 	int maxcount = 0; 
 	// User will be given 3 reservation times
 	User[count].reservecount = 3; 
do 
{ // start of while loop

	// Displays room reservation prompt
	displayRoomReservationPrompt ();
	 
	// Asks user date today
	inputDateToday (User, count); 
	
	//Asks user for personal information such as ID number, full name and year and degree 
	// input ID number 
	inputIDNum (User, count);
	
	// concatinates the first nad last name to be displayed
	inputFirstName (User, count); 
	inputLastName (User, count); 
	
	// Input college degree and year level 
	inputYearLevel (User, count); 
	inputDegreeProgram (User, count); 
	
	// Displays the personal iformation of the user
	printDivider2 ();
	displayDateToday (User, count); 
	printDivider2 (); 
	printf ("Welcome %s %s \n", User[count].InfoStudent.Firstname, User[count].InfoStudent.Lastname); 
	printf ("ID number [%s]\n", User[count].InfoStudent.IDnumber);
	printf ("Year [%d] and Degree [%s] \n", User[count].InfoStudent.Year, User[count].InfoStudent.Program);
	printf ("You only have %d reservation left\n", User[maxcount].reservecount); 
	
	// Enter room resevation details
	inputDateReservation (User, count); 
	
	// displays available rooms to be reserved
	displayRoomToReserve (CompleteRoom); 
	
	// User selects room to reserve
	printf ("Enter the room number to reserve: ");
	scanf (" %d", &RoomChoice);
	
	// USer inputs number of Participants
	printf ("Enter number of participants: ");
	scanf ("%d", &User[count].participants); 
	
	// Checks if the number of participants is valid
	checkNumberofParticipants ( User, CompleteRoom, RoomChoice, count); 
	
	// Stores choice of room in an array
	strcpy (User [count].ReserveRoomUser.building, CompleteRoom [RoomChoice - 1].building); 
	strcpy (User [count].ReserveRoomUser.roomnumber, CompleteRoom [RoomChoice - 1].roomnumber); 
	strcpy (User [count].ReserveRoomUser.roomtype, CompleteRoom [RoomChoice - 1].roomtype); 
	User [count].ReserveRoomUser.capacity = CompleteRoom [RoomChoice - 1].capacity; 
	//displays the room chosen by the user
	printf ("\n"); 
	printDivider2 ();
	printf ("the room you chose : \n");
	printf ("%s%s %s %d/%d\n", User [count].ReserveRoomUser.building, User [count].ReserveRoomUser.roomnumber, User [count].ReserveRoomUser.roomtype, User[count].participants, User [count].ReserveRoomUser.capacity); 
	printf ("\n"); 
	
	// User selects a day of the week
	printf ("Week of day of the reservation: \n");
	printf ("[1] Monday, Tuesday, Thursday, Friday [MTHF] \n");
	printf ("[2] Wednesday, Saturday [WS]\n"); 
	printf ("Enter week of day: "); 
	scanf (" %d", &weekofdaychoice); 
	
	// displays time slots available
	displayTimeSlots (TimeSlotMTHF, TimeSlotWS, weekofdaychoice); 

	// User will choose which week of day (Monday, Tuesday, Thursday, Friday) or (Wednesday, Saturday)
	switch (weekofdaychoice)
		{	
		case 1: // The user chooses (Monday, Tuesday, Thursday, Friday)
			// The chosen room and timeslot will be displayed
			// User enters time slot choice
			// Asks user for time of reservation 
			printf ("Enter time slot: ");
			scanf (" %d", &TimeChoice); 
			strcpy (User[count].timeslot, TimeSlotMTHF [TimeChoice - 1]);
			printf ("The Time you chose is: \n");
			printf ("%s\n", User[count].timeslot); 
			
			//User will be ask to add a consecutive time or not
			if (TimeChoice != 6) // Since the 6th choice does not have a cosecutive time
			{
			displayAddConsecutiveTimePrompt ();
			printf ("Enter choice: ");
			scanf (" %d", &addconsecutivetimeMTHF);
			}
		
			// The consecutive time will be added
			if ( addconsecutivetimeMTHF == 1 && TimeChoice != 6)
			{ 
				// The room choice and consecutive time will be added
				strcpy (User [count].consecutivetimeslot, TimeSlotMTHF [TimeChoice]);
				printf ("The consecutive time is : %s\n", TimeSlotMTHF [TimeChoice] ); 
				printf ("Your current time slots are : \n %s & %s \n", User [count].timeslot, User[count].consecutivetimeslot); 
			}
			break; 
			
		case 2: // User chooses (Wednesday, Saturday)
			printf ("Enter time slot: ");
			scanf (" %d", &TimeChoice); 
			strcpy (User [count].timeslot, TimeSlotWS [TimeChoice - 1]); 
			printf ("%s\n", User [count].timeslot); 
			if (TimeChoice != 3) // The 3rd option does not have a consecutive time
			{
			displayAddConsecutiveTimePrompt (); 
			scanf (" %d", &addconsecutivetimeWS);
			}
		
			// Adds consecutive time
			if (addconsecutivetimeWS == 1 && TimeChoice != 3)
			{
				strcpy (User [count].consecutivetimeslot, TimeSlotWS [TimeChoice]);
				printf ("The consecutive time is : %s\n", TimeSlotWS [TimeChoice] ); 
				printf ("Your current time slots are : \n %s & %s \n", User [count].timeslot, User[count].consecutivetimeslot); 
		
			}
		
		}
	
	// User enters reason of reserving
	printf ("\n");
	printDivider2(); 
	printf ("Description of Activity :");
	scanf (" %s", &User[count].desciptionofactivity);
	printf ("\n"); 
	
	// Displays reason of reserving 
	printDivider2 ();
	printf ("Reason for reservation: \n");
	printf (" %s\n", &User[count].desciptionofactivity);
	printDivider2 ();
	printf ("\n"); 
	


	// User chooses what option to choose
	optionPrompt (); 
	scanf (" %d", &nChoice); 
	
	// User chooses to reserve again
	if (nChoice == 1)
	{
	// number of reservation will be deducted 
	User[maxcount].reservecount--; 
	
	// checks if max reservation is reached 
	printf ("You only have %d reservations left \n", User[maxcount].reservecount); 
		if (checkMaxReservation (User, maxcount) == 0)
		{
			printf ("Sorry you have reached the maximum reservation per person \n");
			optionPrompt (); 
			scanf (" %d", &nChoice); 
		}
		else
		{
		// will add another count 
		count++;
		}
	}
	// Cancel Room
	while (nChoice == 2 )
	{
		CancelRoom (User, count ); 
		optionPrompt (); 
		scanf (" %d", &nChoice); 
	}
	
	// Exits the room reservation and retruns the number of arrays 
	if (nChoice == 3)
	{
		return count; 		
	}
} while (nChoice != 4);  // End of while loop
} // End of function

// TextFile Processing
void saveRoomReservationData (struct RoomReserve User [], struct RoomData CompleteRoom[], int count)
{	
	int i; 
	printf ("Room Data is Saved !\n"); 
	FILE *fp;
	fp = fopen ("records.txt", "w");
	// Room Data save
	for (i = 0; i < CompleteRoom [i].nRooms; i++)
	{
		fprintf (fp, "%s\n%s\n", CompleteRoom[i].building, CompleteRoom [i].roomnumber);
		fprintf (fp, "%s\n", CompleteRoom [i].roomtype ); 
		fprintf (fp, "%d\n", CompleteRoom[i].capacity ); 
	}
	//Reserved room data save
	for (i = 0; i <= count; i++)
	{
	fprintf (fp, "\n%d\n%d\n%d\n",  User [i].TodayDate.day, User [i].TodayDate.month, User[count].TodayDate.year);
	fprintf (fp, "%s\n%s\n", User[i].InfoStudent.Firstname, User[i].InfoStudent.Lastname);
	fprintf (fp, "%s", User[i].InfoStudent.IDnumber);
	fprintf (fp, "%d\n%s\n", User[i].InfoStudent.Year, User[i].InfoStudent.Program);
	fprintf (fp, "%d\n%d\n %d\n", User[i].Reserveday, User[i].Reservemonth, User[count].Reserveyear);
	fprintf (fp, "%s\n %s\n %s\n %d\n %d \n", User [i].ReserveRoomUser.building, User [i].ReserveRoomUser.roomnumber, User [i].ReserveRoomUser.roomtype, User[i].participants, User [i].ReserveRoomUser.capacity );
	fprintf (fp, "%s\n %s\n", User [i].timeslot, User [i].consecutivetimeslot);
	fprintf (fp, "%s\n", User[i].desciptionofactivity); 
	}
	fclose (fp); 
}


int main ()
{
	// Timeslots array 
	DLSUTimeSlot TimeSlotMTHF [6] = {"9:15- 10:45", "11:00 - 12:30", "12:45 - 14:15", "14:30 - 16:00", "16:15 - 17:45", "18:00 - 19:00"}; 
	DLSUTimeSlot TimeSlotWS [3] = {"09:00 - 12:00", "13:00 - 16:00", "16:15 - 19:15"}; 
	
	// variable declarations
	int nChoice; 
	int nRooms;
	int count = 0; 
	// struct for the data of the room and user's room choice data 
	struct RoomData CompleteRoom [MAX]; 
	struct RoomReserve User [MAX]; 

// displays the menu of the DLSU room reservation 
displayMenu (); 
scanf ("%d", &nChoice);

while (nChoice != 3)
{
	switch (nChoice)
	{
		case 1: // Admin menu choice
			displayAdminMenu (CompleteRoom); 
			displayMenu (); 
			scanf (" %d", &nChoice); 

			break; 
		case 2: // Room Reservation choice
			count = RoomReservation (CompleteRoom, User, TimeSlotMTHF, TimeSlotWS, count); 
			displayMenu (); 
			scanf (" %d", &nChoice); 
	}
	
}	
// displays exit prompt
	 saveRoomReservationData (User , CompleteRoom, count);
	displayExitPrompt (); 


}




