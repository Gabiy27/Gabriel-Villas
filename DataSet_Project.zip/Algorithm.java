import java.util.ArrayList;
import java.util.Arrays;

public class Algorithm {
    
    private static boolean contains(int[] array, int endIndex, int value) {
        for (int i = 0; i < endIndex; i++) {                                
            if (array[i] == value) {
                return true;
            }
        }
        return false;
    }
    
    public static int[] getFriendIds(int[][] friendships, int friendId) {
        int[] aFriends = new int[friendships.length * 2]; 
        int index = 0;
    
        for (int[] friendship : friendships) {
            if (friendship[0] == friendId) {
                if (!contains(aFriends, index, friendship[1])) {
                    aFriends[index++] = friendship[1];
                }
            } else if (friendship[1] == friendId) {
                if (!contains(aFriends, index, friendship[0])) {
                    aFriends[index++] = friendship[0];
                }
            }
        }
    
        aFriends = Arrays.copyOf(aFriends, index);
        mergeSort(aFriends, 0, aFriends.length - 1);
    
        return aFriends;
    }
    
    public static void getFriendList(int[][] friendships, int friendId) {
        int[] aFriends = getFriendIds(friendships, friendId);
        int nTotal = aFriends.length;
        
        if (nTotal > 0) {
            StringBuilder strOutput = new StringBuilder("List of friends: ");
    
            for (int friend : aFriends) {
                strOutput.append(friend).append(" ");
            }
    
            System.out.println("Person " + friendId + " has " + nTotal + " friends!");
            System.out.println(strOutput.toString().trim());
        } else {
            System.out.println("Person " + friendId + " has 0 friends.");
        }
    }    
    
    public static void mergeSort(int[] arr, int p, int r) {
        if (p < r) {
            int q = (p + r) / 2;
            mergeSort(arr, p, q);
            mergeSort(arr, q + 1, r);
            merge(arr, p, q, r);
        }
    }
    
    private static void merge(int[] arr, int p, int q, int r) {
        int n1 = q - p + 1;
        int n2 = r - q;
    
        int[] L = new int[n1];
        int[] R = new int[n2];
    
        for (int i = 0; i < n1; i++)
            L[i] = arr[p + i];
        for (int j = 0; j < n2; j++)
            R[j] = arr[q + 1 + j];
    
        int i = 0, j = 0, k = p;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }
    
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }
    
        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }
    public static void displayConnection(int[][] friendships, int nAFriendId, int nBFriendId) {
        if ((nAFriendId) >= 0 && nAFriendId < friendships.length && nBFriendId >= 0 && nBFriendId < friendships.length) {
            int[] friendIds1 = getFriendIds(friendships, nAFriendId);
            int[] friendIds2 = getFriendIds(friendships, nBFriendId);
             ArrayList <Integer> CommonFriends = new ArrayList<Integer>();
            boolean isConnected = false;
            CommonFriends.add(nAFriendId);
            for (int friend1 : friendIds1) {
                for (int friend2 : friendIds2) 
                {
                    if (friend1 == friend2) 
                    {
                        isConnected = true;
                        CommonFriends.add(friend1);
                        break;
                    }
                }
                if (isConnected) 
                {
                    break;
                }
            }
        CommonFriends.add(nBFriendId);

        if (isConnected) 
        {
        System.out.println("There is a connection from " + nAFriendId + " to " + nBFriendId + "!");
        for (int i = 0; i < CommonFriends.size() - 1; i++) 
            {
                int current = CommonFriends.get(i);
                int next = CommonFriends.get(i + 1);
                System.out.println(current + " is friends with " + next);
            }
        } 
             else {
                System.out.println("There is no connection between " + nAFriendId + " and " + nBFriendId + ".");
            }
        } else {
            System.out.println("Invalid person ID(s). Please try again.");
        }
    }
}