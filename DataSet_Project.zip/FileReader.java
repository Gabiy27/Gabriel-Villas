import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileReader {

    public int[][] readFile(String path) {
        try {
            File f = new File(path);
            Scanner scanner = new Scanner(f);

            int totalNodes = scanner.nextInt();
            int totalConnections = scanner.nextInt();
            scanner.nextLine();  

            int[][] friendships = new int[totalConnections][2];

            for (int i = 0; i < totalConnections; i++) {
                int aFriend = scanner.nextInt();
                int bFriend = scanner.nextInt();

                friendships[i][0] = aFriend;
                friendships[i][1] = bFriend;
            }

            System.out.println("Graph loaded!");
            scanner.close();
            return friendships;
        } catch (FileNotFoundException e) {
            System.err.println("File not found.");
            e.printStackTrace();
            return null;
        }
    }
}
