import java.util.Scanner;

public class Driver {

    public static void main(String[] args) {
        Scanner CScanner = new Scanner(System.in);

        System.out.print("Input file path: ");
        String strPath = CScanner.nextLine();

        FileReader CFileReader = new FileReader();
        int[][] friendships = CFileReader.readFile(strPath);
    
        if (friendships != null) {
            while (true) {
                System.out.println("\nMAIN MENU");
                System.out.println("[1] Get friend list");
                System.out.println("[2] Get connection");
                System.out.println("[3] Exit");
    
                System.out.print("\nEnter your choice: ");
                int nChoice = CScanner.nextInt();
    
                switch (nChoice) {
                    case 1:
                        System.out.print("\nEnter ID of person: ");
                        int nAccountId = CScanner.nextInt();
                        Algorithm.getFriendList(friendships, nAccountId);
                        break;
    
                    case 2:
                        System.out.print("\nEnter ID of first person: ");
                        int nAFriendId = CScanner.nextInt();
                        System.out.print("\nEnter ID of second person: ");
                        int nBFriendId = CScanner.nextInt();
                        Algorithm.displayConnection(friendships, nAFriendId, nBFriendId);
                        break;
    
                    case 3:
                        System.out.println("Exiting program. Bye!"); 
                        CScanner.close();
                        System.exit(0);
    
                    default:
                        System.out.println("Invalid Choice");
                }
            }
        }
        CScanner.close();
    }
}
