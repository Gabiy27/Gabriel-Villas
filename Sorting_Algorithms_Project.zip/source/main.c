/*
Belicina, John Pyro S.						   		   CCDSALG - S14
Cisneros, John Maverick Z.						  	   Group 7 
Loria, Andrea Euceli F.
Villas, Gabriel N.

*/

#include "record.c"
#include "sortingalgorithms.c"
#include "filereader.c"
#include "timer.c"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void printRecord(Record *record) {
    printf("ID: %d, Name: %s\n", record->idNumber, record->name);
}

void printRecordsArray(Record *records, int n) {
    for (int i = 0; i < n; i++) {
        printRecord(&records[i]);
    }
}

int isSorted(Record *records, int n) {
    for (int i = 0; i < n - 1; i++) {
        if (records[i].idNumber > records[i + 1].idNumber) {
            return 0;
        }
    }
    return 1;
}

int main()
{
    
	int n = 100; //number of elements
    char path[500] = "random100.txt"; //file name

    
    Record *records = malloc(n * sizeof(Record)); 
	
    if (records == NULL) {
        printf("Fail\n");
        return 1;
    }
    else{
    	printf("File found\n");
	}
    
    readFile(records, path);

    //execution time
    long startTime, endTime, executionTime;
    startTime = currentTimeMillis();

    selectionSort(records, n); 
	//insertionSort(records, n);
	//cocktailSort(records, n);
	//mergeSort(records, 0, n - 1);
	
    endTime = currentTimeMillis();
    executionTime = endTime - startTime;
       
	printf("Sorted Records:\n");
    printRecordsArray(records, n);

    printf("\nTime: %ld", executionTime);
    if (isSorted(records, n) == 1) {
        printf("\nTrue\n");
    } else {
        printf("\nFalse\n");
    }
	
	free(records);
    return 0;
}