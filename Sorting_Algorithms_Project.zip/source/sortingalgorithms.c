/*
Belicina, John Pyro S.						   		   CCDSALG - S14
Cisneros, John Maverick Z.						  	   Group 7 
Loria, Andrea Euceli F.
Villas, Gabriel N.

*/

#ifndef SORTINGALGORITHMS_C
#define SORTINGALGORITHMS_C
#include <stdio.h>
#include <string.h>
#include "record.c"

/*
* You may declare additional variables and helper functions
* as needed by the sorting algorithms here.
*/

void swap(Record *x, Record *y){
	Record temp;
	
	temp = *x;
	*x = *y;
	*y = temp;
}

void insertionSort(Record *arr, int n)
{
	int i; 
	int min; 
	int nNum; 
	for (i = 1; i < n; i++)
	{	
		nNum = arr[i].idNumber;
		for (min = i - 1; min >= 0; min--)
				{
					if (arr[min].idNumber > nNum)
						{
						// swap the values of the elements
						 swap(&arr[min], &arr[min + 1]);
						}
				}
	}	
}

void selectionSort(Record *arr, int n)
{
    // TODO: Implement this sorting algorithm here.
	int i;
    int j;
    int min;
    
    for(i = 0; i < n - 1; i++)
    {
    	min = i;
    	for(j = i + 1; j < n; j++)
    	{
    		if(arr[j].idNumber < arr[min].idNumber)
    		{
    			min = j;
			}
		}
		if(min != i)
		{
			swap(&arr[min], &arr[i]);
		}
	}
}


void cocktailSort(Record *arr, int n)										
{
    int nFirst = 0;															
    int nLast = n - 1;														
    int nSwap = 1;															

    while (nSwap) {															
        nSwap = 0;															

        // Forward pass 
        for (int i = nFirst; i < nLast; i++) {								
            if (arr[i].idNumber > arr[i + 1].idNumber) {					
                swap(&arr[i], &arr[i + 1]);									
                nSwap = 1;													
            }
        }
		
        if (!nSwap) //if sorted												
            break;															

        nLast--; //Decrement bc largest number is at the end				

        nSwap = 0;															
	
        // Backward pass
        for (int i = nLast; i > nFirst; i--) {								
            if (arr[i - 1].idNumber > arr[i].idNumber) {					
                swap(&arr[i - 1], &arr[i]);									
                nSwap = 1;												
            }	
        }
	
        nFirst++; //Increment bc smallest number is at the front		
    }
}

void merge(Record *arr, int p, int q, int r) {
    int n1 = q - p + 1;	
    int n2 = r - q;

    // Create temporary arrays to hold the two halves
    Record L[n1];
	Record R[n2];

    for (int i = 0; i < n1; i++)
        L[i] = arr[p + i];
    for (int j = 0; j < n2; j++)
        R[j] = arr[q + 1 + j];

    // Merge the two halves back into the original array
    int i = 0, j = 0, k = p;
    while (i < n1 && j < n2) {
        if (L[i].idNumber <= R[j].idNumber) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }	
        k++;
    }

    // Copy any remaining elements of L and R (if any)
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}

// Main merge sort function
void mergeSort(Record *arr, int p, int r) {
    if (p < r) {
        int q = (p + r) / 2;
        mergeSort(arr, p, q);
        mergeSort(arr, q + 1, r);
        merge(arr, p, q, r);
    }
}

#endif
