/** 
 * This class is the enemy class
 * 
 * @author  Daniel Ryan Baysa Ong
 * @author Gabriel N. Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class Enemy {
    /** 
    * This field is for the enemy name
    */
   private String strEnemyName;
    /** 
    * This field is for boss name
    */
   private String strBossName; 
    /** 
    * This field is for health
    */
   private int nHealth; 
   /** 
    * This field is for low health 
    */
   private int nHealthLow;
   /** 
    * This field is for high health
    */
   private int nHealthHigh;
   /** 
    * This field is for attack
    */
   private int nAttack;
   /** 
    * This field is for low attack
    */
   private int nAttackLow;
   /** 
    * This field is for high attack
    */
   private int nAttackHigh; 
   /** 
    * This field is for low damage
    */
   private int nDamageLow; 
   /** 
    * This field is for high damage
    */
   private int nDamageHigh; 
   /** 
    * This field is for damage
    */
   private int nDamage; 
   /** 
    * This field is for physicial defense
    */
   private double dPhysicalDefense;
   /** 
    * This field is for the sorcery defense
    */
   private double dSorceryDefense; 
   /** 
    * This field is for Incantation defense
    */
   private double dIncantationDefense; 


   private int nPreviousEnemyHealth;
   /** 
    * This constructor is for the enemy
    */
   public Enemy (){
       strEnemyName = "";
       strBossName = " "; 
       nHealth = 0; 
       nHealthLow = 0;
       nHealthHigh = 0;
       nAttack = 0;
       nAttackLow = 0;
       nAttackHigh= 0; 
       nDamageLow =0; 
       nDamageHigh =0; 
       nDamage = 0 ; 
       dPhysicalDefense = 0.0;
       dSorceryDefense= 0.0; 
       dIncantationDefense= 0.0; 
       nPreviousEnemyHealth = 0;
   }

   /** 
    * This method is to set Enemy stats
    * @param nRandNum is for the random numbers
    * @param nAreaIndex is for the index area
    */
   public void setEnemyStats (int nRandNum, int nAreaIndex){
        if (nAreaIndex == 1)
        {
            switch (nRandNum){
            case 1: 
            setAreaOneTypeOneEnemy();
            break; 
            case 2:
            setAreaOneTypeTwoEnemy();
            break;
            case 3:
            setAreaOneTypeThreeEnemy();
            }
        }
        else if (nAreaIndex == 2)
        {
            switch (nRandNum){
                case 1: 
                setAreaTwoTypeOneEnemy();
                break; 
                case 2:
                setAreaTwoTypeTwoEnemy();
                break;
                case 3:
                setAreaTwoTypeThreeEnemy();
                }
        }
         
   }
   /** 
    * This method is to set boss stats
    * @param nAreaIndex is the index of area
    */
   public void setBossStats (int nAreaIndex)
   {
        switch (nAreaIndex)
        {
            case 1:
            setAreaOneBossStats();
            break;
            case 2: 
            setAreaTwoBossStats ();
            break;
            case 3:
            setAreaThreeBossStats ();
            break;
        }
   }
   /** 
    * This method is to set boss stats
    */
   public void setAreaOneBossStats ()
   {
           strBossName = "GODRICK THE GRAFTED"; 
           nHealth = 200; 
           nDamageLow = 150;
           nDamageHigh = 300; 
           dPhysicalDefense = 0.35;
           dSorceryDefense = 0.20;
           dIncantationDefense = 0.15; 

   }
    /** 
    * This method is to set boss stats
    */
   public void setAreaTwoBossStats (){
            strBossName = "Renala, Queen Of The Full Moon"; 
            nHealth = 400; 
            nDamageLow = 200;
            nDamageHigh = 300; 
            dPhysicalDefense = 0.15;
            dSorceryDefense = 0.35;
            dIncantationDefense = 0.25; 
   }
    /** 
    * This method is to set boss stats
    */
   public void setAreaThreeBossStats (){
            strBossName = "The Elden Beast"; 
            nHealth = 800; 
            nDamageLow = 250;
            nDamageHigh = 500; 
            dPhysicalDefense = 0.25;
            dSorceryDefense = 0.50;
            dIncantationDefense = 0.40; 
   }
    /** 
    * This method is to set enemy stats
    */
   public void setAreaOneTypeOneEnemy ()
   {
        strEnemyName = "Godrick Soldier";
           nHealthLow = 20; 
           nHealthHigh = 30;  
           nAttackLow = 70;
           nAttackHigh = 80; 
           dPhysicalDefense = 0.20;
           dSorceryDefense = 0.15;
           dIncantationDefense = 0.10; 
   }
    /** 
    * This method is to set enemy stats
    */
   public void setAreaOneTypeTwoEnemy ()
   {
            strEnemyName = "Godrick Archer"; 
            nHealthLow = 25; 
            nHealthHigh = 35; 
            nAttackLow = 110;
            nAttackHigh = 120; 
            dPhysicalDefense = 0.50;
            dSorceryDefense = 0.15;
            dIncantationDefense = 0.20; 
   }
    /** 
    * This method is to set enemy stats
    */
   public void setAreaOneTypeThreeEnemy ()
   {
            strEnemyName = "Godrick Knight"; 
            nHealthLow = 70; 
            nHealthHigh = 80;
            nAttackLow = 120;
            nAttackHigh = 130; 
            dPhysicalDefense = 0.25;
            dSorceryDefense = 0.25;
            dIncantationDefense = 0.20; 
   }
    /** 
    * This method is to set enemy stats
    */
   public void setAreaTwoTypeOneEnemy ()
   {
        strEnemyName = "Living Jar";
        nHealthLow = 20; 
        nHealthHigh = 30;  
        nAttackLow = 70;
        nAttackHigh = 80; 
        dPhysicalDefense = 0.20;
        dSorceryDefense = 0.15;
        dIncantationDefense = 0.10; 
   }
   /** 
    * This method is to set enemy stats
    */
   public void setAreaTwoTypeTwoEnemy ()
   {
            strEnemyName = "Glinstone Sorcerer"; 
            nHealthLow = 25; 
            nHealthHigh = 35; 
            nAttackLow = 110;
            nAttackHigh = 120; 
            dPhysicalDefense = 0.50;
            dSorceryDefense = 0.15;
            dIncantationDefense = 0.20; 
   }
   /** 
    * This method is to set enemy stats
    */
   public void setAreaTwoTypeThreeEnemy ()
   {
            strEnemyName = "BattleMage"; 
            nHealthLow = 70; 
            nHealthHigh = 80;
            nAttackLow = 120;
            nAttackHigh = 130; 
            dPhysicalDefense = 0.25;
            dSorceryDefense = 0.25;
            dIncantationDefense = 0.20; 
   }
   /** 
    * This method sets previous enemy health
    * @param nPreviousEnemyHealth
    */
   public void setPreviousEnemyHealth (int nPreviousEnemyHealth)
   {
     this.nPreviousEnemyHealth = nPreviousEnemyHealth; 
   }
   /** 
    * This method is to set Enemy health
    * @param nHealth for health of enemy
    */
   public void setEnemyHealth (int nHealth) {
       this.nHealth = nHealth; 
   }
    /** 
    * This method is to set Enemy health
    * @param nAttack for attack of enemy
    */
   public void setAttack  (int nAttack){
       this.nAttack = nAttack; 
   }
    /** 
    * This method is to set Enemy health
    * @param nDamage for damage of boss
    */


// Getters
    /** 
    * This method gets boss health
    */
    public int getBossHealth ()
    {
        return nHealth;
    }
    /** 
    * This method is to  gets enemy name
    */
   public String getEnemyName (){
       return strEnemyName; 
   }
     /** 
    * This method is to  gets enemy health
    */
   public int getEnemyHealth (){
       return nHealth;
   }
   /** 
    * This method gets previous enemy health
    */
   public int getPreviousEnemyHealth (){
    return nPreviousEnemyHealth;
   }
     /** 
    * This method is to  gets attack
    */
   public int getEnemyAttack (){
       return nAttack; 
   }

     /** 
    * This method is to  gets health low
    */
   public int getHealthLow ()
   {
       return nHealthLow;
   }

   /** 
    * This method is to  gets health high
    */
   public int getHealthHigh ()
   {
       return nHealthHigh;
   }
   /** 
    * This method is to  gets attack low
    */
   public int getAttackLow ()
   {
       return nAttackLow;
   }

   /** 
    * This method is to  gets attack high 
    */
   public int getAttackHigh ()
   {
       return nAttackHigh;
   }
     /** 
    * This method is to  gets boss Name
    */
   public String getBossName (){
       return strBossName; 
   }
     /** 
    * This method is to  gets Damage low
    */
   public int  getDamageLow (){
       return nDamageLow; 
   }
     /** 
    * This method is to  gets damage high
    */
   public int  getDamageHigh (){
       return nDamageHigh; 
   }
    /** 
    * This method is to  gets damage low
    */
   public int getBossDamage (){
       return nDamage; 
   }
   /** 
    * This method is to  gets physical defense
    */
   public double getPhysicalDefense () {
       return dPhysicalDefense; 
   }
    /** 
    * This method is to  gets sorcery defense
    */
   public double getSorceryDefense () {
       return dSorceryDefense; 
   }
   /** 
    * This method is to  gets Incantation defense
    */
   public double getIncantationDefense() {
       return dIncantationDefense; 
   }


}
