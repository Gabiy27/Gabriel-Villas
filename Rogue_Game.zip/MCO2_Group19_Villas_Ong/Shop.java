import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/** 
 * This is the shop class
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class Shop extends Weapon{
    // GUI FIELDS
    /**
     * This field is for the Frame
     */
    private JFrame CShopFrame; 
     /**
     * This field is for the button
     */
    private JButton CSwordsButton; 
     /**
     * This field is for the button
     */
    private JButton CKatanasButton; 
    /**
     * This field is for the button
     */
    private JButton CWhipsButton;
    /**
     * This field is for the button
     */
    private JButton CGreatSwordsButton; 
    /**
     * This field is for the button
     */
    private JButton CStavesButton;
    /**
     * This field is for the button
     */
    private JButton CSealsButton; 
    /**
     * This field is for the button
     */
    private JButton CBackButton; 
    /**
     * This field is for the label
     */
    private JLabel CShopTitleLabel; 
    /**
     * This field is for the label
     */
    private JLabel CPlayerRunesLabel;
    /**
     * This field is for the image
     */ 
    private ImageIcon CShopTitleImage; 
    // Fields
    /**
     * This field is for weapon class
     */
    private Weapon CWeapon;
    /**
     * This field is for runes
     */
    private int nRunes;
    /**
     * This constructor is for the shop
     * @param nRunes
     */
    public Shop (int nRunes){
        this.CShopFrame = new JFrame();
        this.CSwordsButton = new JButton();
        this.CKatanasButton = new JButton();
        this.CWhipsButton = new JButton();
        this.CGreatSwordsButton = new JButton();
        this.CStavesButton = new JButton();
        this.CSealsButton = new JButton();
        this.CBackButton = new JButton(); 
        this.CShopTitleLabel = new JLabel();
        this.CPlayerRunesLabel = new JLabel();
        this.CShopTitleImage = new ImageIcon("ShopTitle.png");
        this.CWeapon = new Weapon(nRunes);
        this.nRunes = nRunes; 
    }
    /**
     * this method is for opening shop
     */
    public void openShop (){
        displayShopFrame();
        displaySwordsButton();
        displayKatanasButton();
        displayWhipsButton();
        displayGreatSwordsButton();
        displayStavesButton();
        displaySealsButton();
        displayBackButton();
        displayPlayerRunes();
        displayShopTitle();
        CShopFrame.setVisible(true);
    }
    /**
     * this method displays shop frame
     */
    public void displayShopFrame (){
        CShopFrame.setSize (800, 900);
        CShopFrame.setTitle("Shop");
        CShopFrame.setLayout(null);
        CShopFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CShopFrame.getContentPane().setBackground(Color.BLACK);
    }
     /**
     * this method displays shop title
     */
    public void displayShopTitle (){
        CShopTitleLabel.setIcon(CShopTitleImage);
        CShopTitleLabel.setVerticalAlignment(JLabel.TOP);
        CShopTitleLabel.setHorizontalAlignment(JLabel.CENTER);
        CShopTitleLabel.setBounds(100, 5, 400, 400);
        CShopFrame.add( CShopTitleLabel);
    }
     /**
     * this method displays button
     */
    public void displaySwordsButton (){
        CSwordsButton.setBounds(200, 250, 200, 50);
        CSwordsButton.setText("SWORDS");
        CSwordsButton.setBackground(Color.BLACK);
        CSwordsButton.setForeground (Color.YELLOW);
        CSwordsButton.setFocusable(false);
        CSwordsButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CSwordsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            CWeapon.openSwordsMenu();
            }   
        });
        CShopFrame.add (CSwordsButton);
    }
    /**
     * this method displays button
     */
    public void displayKatanasButton (){
        CKatanasButton.setBounds(200, 330, 200, 50);
        CKatanasButton.setText("KATANAS");
        CKatanasButton.setBackground(Color.BLACK);
        CKatanasButton.setForeground (Color.YELLOW);
        CKatanasButton.setFocusable(false);
        CKatanasButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CKatanasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CWeapon.openKatanasMenu();
            }   
        });
        CShopFrame.add (CKatanasButton);
    }
    /**
     * this method displays button
     */
    public void displayWhipsButton (){
        CWhipsButton.setBounds(200, 410, 200, 50);
        CWhipsButton.setText("WHIPS");
        CWhipsButton.setBackground(Color.BLACK);
        CWhipsButton.setForeground (Color.YELLOW);
        CWhipsButton.setFocusable(false);
        CWhipsButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CWhipsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CWeapon.openWhipMenu();
            }   
        });
        CShopFrame.add (CWhipsButton);
    }
    /**
     * this method displays button
     */
    public void displayGreatSwordsButton (){
        CGreatSwordsButton.setBounds(200, 490, 200, 50);
        CGreatSwordsButton.setText("GREATSWORDS");
        CGreatSwordsButton.setBackground(Color.BLACK);
        CGreatSwordsButton.setForeground (Color.YELLOW);
        CGreatSwordsButton.setFocusable(false);
        CGreatSwordsButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CGreatSwordsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CWeapon.openGreatSwordsMenu();
            }   
        });
        CShopFrame.add (CGreatSwordsButton);
    }
    /**
     * this method displays button
     */
    public void displayStavesButton (){
        CStavesButton.setBounds(200, 570, 200, 50);
        CStavesButton.setText("STAVES");
        CStavesButton.setBackground(Color.BLACK);
        CStavesButton.setForeground (Color.YELLOW);
        CStavesButton.setFocusable(false);
        CStavesButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CStavesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CWeapon.openStavesMenu();
            }   
        });
        CShopFrame.add (CStavesButton);
    }
    /**
     * this method displays button
     */
    public void displaySealsButton (){
        CSealsButton.setBounds(200, 650, 200, 50);
        CSealsButton.setText("SEALS");
        CSealsButton.setBackground(Color.BLACK);
        CSealsButton.setForeground (Color.YELLOW);
        CSealsButton.setFocusable(false);
        CSealsButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CSealsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CWeapon.openSealsMenu();
            }   
        });
        CShopFrame.add (CSealsButton);
    }
    /**
     * this method displays button
     */
    public void displayBackButton (){
        CBackButton.setBounds(200, 730, 100, 50);
        CBackButton.setText("Back");
        CBackButton.setBackground(Color.BLACK);
        CBackButton.setForeground (Color.YELLOW);
        CBackButton.setFocusable(false);
        CBackButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CShopFrame.dispose();
            }   
        });
        CShopFrame.add (CBackButton);
    }
    /**
     * this method displays button
     */
    public void displayPlayerRunes (){
        CPlayerRunesLabel.setText ("Runes: " + CWeapon.getRunes());
        CPlayerRunesLabel.setHorizontalAlignment(JLabel.CENTER);
        CPlayerRunesLabel.setVerticalAlignment(JLabel.BOTTOM);
        CPlayerRunesLabel.setBounds(500, 160, 200, 200);
        CPlayerRunesLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CPlayerRunesLabel.setForeground(Color.WHITE);
        CShopFrame.add (CPlayerRunesLabel);
    }

    /**
     * this method add weapon to inventory
     */
    public void addWeaponToInventory (Inventory CInventory){
        // CInventory.setWeapon();
    }
    /**
     * this method checks rune cost
     */
    public boolean  checkRuneCost (int nRunes, int nRuneCost){
        if (nRuneCost < nRunes)
        {
            return true;
        }
        else 
        {
            return false; 
        }
    }

   

}
