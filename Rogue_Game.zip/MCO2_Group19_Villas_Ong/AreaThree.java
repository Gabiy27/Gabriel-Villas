import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/** 
 * This is the Area One
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
     /** 
     * This constructor is for the area two
     * @param nAreaIndex for area index
     * @param strName for the name
     * @param nLevel for the level
     * @param nRunes for the runes
     * @param nPlayerHp for the player hp
     * @param nPlayerDex for the player dexterity 
     * @param nPlayerInt for the Player intelligence
     * @param nPlayerEnd for the player Endurance
     * @param nPlayerStr for the player strength
     * @param nPlayerFth for the player faith
     * @param nWeaponHp for the weapon hp
     * @param nWeaponDex for the weapon dexterity
     * @param nWeaponInt for the weapon intellgence
     * @param nWeaponEnd for the weapon endurance
     * @param nWeaponStr for the weapon strength 
     * @param nWeaponFth for the weapon faith
     */
public class AreaThree extends AreaOne {
    public AreaThree (int nAreaIndex, String strName, int nLevel, int nRunes, int nPlayerHp, int nPlayerDex, int nPlayerInt, int nPlayerEnd, int nPlayerStr, int nPlayerFth, int nWeaponHp, int nWeaponDex, int nWeaponInt, int nWeaponEnd,int nWeaponStr, int nWeaponFt)
    {
        super(nAreaIndex, strName, nAreaIndex, nAreaIndex, nAreaIndex, nAreaIndex, nAreaIndex, nAreaIndex, nAreaIndex, nAreaIndex, nAreaIndex, nAreaIndex, nAreaIndex, nAreaIndex, nAreaIndex, nAreaIndex);
        CAreaOneFloorOneImage = new ImageIcon("AreaThreeFloorOne.png");
        CAreaOneFloorTwoImage = new ImageIcon("AreaThreeFloorTwo.png");
        CAreaOneFloorThreeImage = new ImageIcon("AreaThreeFloorThree.png");
        CStromveilTitle = new ImageIcon ("AreaThreeTheEldenThrone.png");
        this.nAreaIndex = nAreaIndex;
        bBossAlive = true;
        bActiveTiles = new boolean[9];

    }
     /** 
     * This method is for the area three floor one
     * @param nX for the x axis
     * @param nY is for the y axis
     */
    public void openAreaThreeFloorOne (int nX, int nY){
        initializeActiveTiles(9);
        this.nX = nX;
        this.nY = nY;
        displayAreaOneTitle();
        displayPlayerToken(nX, nY);
        displayAreaOneFloorOneFrame();
        displayMoveButtons();
        displayAreaOneFloorOne();
        
        
        CAreaOneFloorOneFrame.setVisible (true); 
    }
    /** 
     * This method displays move up button
     */
    public void displayMoveUpButton (){
        CMoveUpButton.setBounds(200, 200, 50, 50);
        CMoveUpButton.setText("W");
        CMoveUpButton.setBackground(Color.BLACK);
        CMoveUpButton.setForeground (Color.YELLOW);
        CMoveUpButton.setFocusable(false);
        CMoveUpButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CMoveUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            switch (nFloorLevel)
            {
                case 1: 
                nY -= 43;
                if (nY >= 180)
                {
                    displayPlayerToken(nX, nY);
                    displayAreaOneFloorOne();
                }
                else
                {
                    nY += 43;
                }
                break; 
                case 2: 
                nY -= 43;
                if (nY >= 192 )
                {
                    displayPlayerToken(nX, nY);
                    displayAreaOneFloorTwo(); 
                }
                else
                {
                    nY += 43;
                }
  
                break;
               case 3:
               nY -= 43;
               if (nY >= 196 )
               {
                   displayPlayerToken(nX, nY);
                   displayAreaOneFloorThree(); 
               }
               else
               {
                   nY += 43;
               }
               break; 
                
            }
            
            }
        });
        CAreaOneFloorOneFrame.add (CMoveUpButton);
    }
      /** 
     * This method displays move down button
     */
    public void displayMoveDownButton (){
        CMoveDownButton.setBounds(200, 300, 50, 50);
        CMoveDownButton.setText("S");
        CMoveDownButton.setBackground(Color.BLACK);
        CMoveDownButton.setForeground (Color.YELLOW);
        CMoveDownButton.setFocusable(false);
        CMoveDownButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CMoveDownButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (nFloorLevel)
                {
                    case 1:
                    nY += 43;
                    if (nY <= 540)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorOne();
                    }
                    else
                    {
                        nY -= 43;
                    }
                    break; 
                    case 2:
                    nY += 43;
                    if (nY <= 450)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorTwo();
                    }
                    else
                    {
                        nY -= 43;
                    }
                    break; 
                    case 3:
                    nY += 43;
                    if (nY <= 540)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorThree();
                    }
                    else
                    {
                        nY -= 43;
                    }
                    break;
                    
                }
            }
        });
        CAreaOneFloorOneFrame.add (CMoveDownButton);
    }
      /** 
     * This method displays move left button
     */
    public void displayMoveLeftButton (){
        CMoveLeftButton.setBounds(150, 250, 50, 50);
        CMoveLeftButton.setText("A");
        CMoveLeftButton.setBackground(Color.BLACK);
        CMoveLeftButton.setForeground (Color.YELLOW);
        CMoveLeftButton.setFocusable(false);
        CMoveLeftButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CMoveLeftButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (nFloorLevel)
                {
                    case 1:
                    nX -= 50;
                    if (nX >= 445)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorOne();
                        
                    }
                    else
                    {
                        nX += 50;
                    }
                    break;
                    case 2:
                    nX -= 48;
                    if (nX >= 350)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorTwo();
                        
                    }
                    else
                    {
                        nX += 48;
                    }
                    case 3: 
                    nX -= 43;
                    if (nX >= 452 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorThree();
                        
                    }
                    else
                    {
                        nX += 43;
                    }
                    break; 
                }
              
            }
        });
        CAreaOneFloorOneFrame.add (CMoveLeftButton);
    }
      /** 
     * This method moves right button
     */
    public void displayMoveRightButton (){
        CMoveRightButton.setBounds(250, 250, 50, 50);
        CMoveRightButton.setText("D");
        CMoveRightButton.setBackground(Color.BLACK);
        CMoveRightButton.setForeground (Color.YELLOW);
        CMoveRightButton.setFocusable(false);
        CMoveRightButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CMoveRightButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (nFloorLevel)
                {
                    case 1:
                    nX += 50; 
                    if (nX <= 550)
                        {
                            displayPlayerToken(nX, nY);
                            displayAreaOneFloorOne();
                        }
                        else
                        {
                            nX -= 50;
                        }
                    break;

                    case 2:
                    nX += 48; 
                    if (nX <= 650 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorTwo();
                    }
                    else 
                    {
                        nX -= 48;
                    }
                    break;

                    case 3:
                    nX += 43;
                    if (nX <= 538 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorThree();
                    }
                    else
                    {
                        nX -= 43;
                    }
                    break;
                }
            }
        });
        CAreaOneFloorOneFrame.add (CMoveRightButton);
    }
      /** 
     * This method displays interact button
     */
    public void displayInteractButton (){
        CInteractButton.setBounds(200, 250, 50, 50);
        CInteractButton.setText("E");
        CInteractButton.setBackground(Color.BLACK);
        CInteractButton.setForeground (Color.YELLOW);
        CInteractButton.setFocusable(false);
        CInteractButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CInteractButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
         {
            switch (nFloorLevel)
            {
                case 1:
                if (nX == 495 && nY == 535)
                {
                    AreaTwo CAreaTwo = new AreaTwo(1, strName, nLevel, nRunes, nPlayerHp, nPlayerDex, nPlayerInt, nPlayerEnd, nPlayerStr, nPlayerFth, nWeaponHp, nWeaponDex, nWeaponInt, nWeaponEnd, nWeaponStr, nWeaponFth);
                    // Floor Five
                    nX = 495;
                    nY = 196;
                    CAreaTwo.openAreaTwo (495, 193);
                    CAreaOneFloorOneFrame.dispose ();
                }
                else if (nX == 495 && nY == 363 )
                {
                    if (CTiles.checkActiveTile(bActiveTiles[0]) == true)
                    {
                        CTiles.openTreasureRunesFrame();
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[0] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                   
                }
                else if (nX == 495 && nY == 191 ){
                    // Open Floor Two
                    nX = 495;
                    nY = 450;
                    nFloorLevel = 2; 
                    openAreaOneFloorTwo(nX, nY);
                    CAreaOneFloorOneFrame.dispose();
                }
                break;
                case 2:
                // Spawn Tiles Row 1
                if (nX == 495 && nY == 450)
                {
                    nFloorLevel = 1;
                    nX = 495;
                    nY = 195;
                    openAreaOneFloorOne(nX, nY);
                    CAreaOneFloorTwoFrame.dispose();
                }
                else if (nX == 495 && nY == 321)
                {
                    CTiles.openBossTile(nAreaIndex);
                    bBossAlive = false;
                }
                else if (nX == 495 && nY == 192 )
                {
                    nFloorLevel = 3;
                    CAreaOneFloorTwoFrame.dispose();
                    nX = 495;
                    nY = 540;
                    openAreaOneFloorThree(nX, nY);
                }
                break; 
                case 3:
                if (nX == 452 && nY == 497)
                {
                    
                    if (CTiles.checkActiveTile(bActiveTiles[1]) == true)
                    {
                        CTiles.openTreasureRunesFrame();
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[1] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                    
                }
                else if (nX == 452 && nY == 411 )
                {
                    if (CTiles.checkActiveTile(bActiveTiles[2]) == true)
                    {
                        CTiles.openTreasureRunesFrame();
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[2] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 452 && nY == 325)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[3]) == true)
                    {
                        CTiles.openTreasureRunesFrame();
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[3] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 452 && nY == 239)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[4]) == true)
                    {
                        CTiles.openTreasureRunesFrame();
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[4] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 538 && nY == 239)
                {
                
                    if (CTiles.checkActiveTile(bActiveTiles[5]) == true)
                    {
                        CTiles.openTreasureRunesFrame();
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[5] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 538 && nY == 325 )
                {
                    if (CTiles.checkActiveTile(bActiveTiles[6]) == true)
                    {
                        CTiles.openTreasureRunesFrame();
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[6] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if ( nX == 538 && nY == 411)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[7]) == true)
                    {
                        CTiles.openTreasureRunesFrame();
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[7] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 538 && nY == 497)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[8]) == true)
                    {
                        CTiles.openTreasureRunesFrame();
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[8] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 495 && nY == 196 )
                {
                    if (CTiles.checkFastTravel(bBossAlive) == true)
                    {
                        CTiles.openCreditsTileFrame();
                    }
                   
                }
                else if (nX == 495 && nY == 540)
                {
                    nX = 495;
                    nY = 192;
                    nFloorLevel = 2;
                    openAreaOneFloorTwo(nX, nY);
                    CAreaOneFloorThreeFrame.dispose ();
                }
            }
           
        }
        });
        CAreaOneFloorOneFrame.add (CInteractButton);
    }
}
