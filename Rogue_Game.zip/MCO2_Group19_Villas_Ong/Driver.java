/** 
 * This is the driver class
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class Driver {
    /** 
     * This is the main method of the program
     * 
     */
    public static void main(String[] args) {
        Application CApplication = new Application();
        CApplication.runApplication(); 
    }
}