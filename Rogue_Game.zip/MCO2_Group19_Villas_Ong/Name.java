import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
/** 
 * This is the Name class
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class Name {
    // GUI Fields
    /** 
    * This field is the frame
    */
    private JFrame NameFrame;
     /** 
    * This field is for the label
    */
    private JLabel NamePromptLabel;
     /** 
    * This field is for the label
    */
    private JLabel NameLabel;
     /** 
    * This field is for the label
    */
    private JLabel DisplayNameLabel;
     /** 
    * This field is for the textfield
    */
    private JTextField NameTextField; 
     /** 
    * This field is for the button 
    */
    private JButton SubmitButton; 
     /** 
    * This field is for the button 
    */
    private JButton BackButton; 
     /** 
    * This field is for the  image 
    */
    private ImageIcon BackButtonImage;
     /** 
    * This field is for the image
    */
    private ImageIcon SubmitButtonImage;
    // Fields
     /** 
    * This field is for the name 
    */
    private String strName; 
     /** 
    * This field is for the name
    */
    public Name (){
        this.NameFrame = new JFrame(); 
        this.NamePromptLabel = new JLabel (); 
        this.NameLabel = new JLabel();
        this.DisplayNameLabel = new JLabel();
        this.NameTextField = new JTextField(); 
        this.SubmitButton = new JButton();
        this.BackButton = new JButton();
        this.BackButtonImage = new ImageIcon("Back.png");
        this.SubmitButtonImage = new ImageIcon("Submit.png");
        this.strName = ""; 
    }
     /** 
    * This method is for the opens name
    */
    public void openName (){
        displayNameFrame();
        displayNamePrompt();
        displayNameTextField();
        displaySubmitButton();
        displayBackButton();
        NameFrame.setVisible(true);
    }
     /** 
    * This method is displays frame
    */
    public void displayNameFrame () {
        NameFrame.setSize (900, 500);
        NameFrame.setTitle("Name");
        NameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        NameFrame.setLayout(null);
        NameFrame.getContentPane().setBackground(Color.BLACK);
    }
     /** 
    * This method is displays name prompt
    */
    public void displayNamePrompt (){
        NamePromptLabel.setText("Only enter a name greater than 1 or less than 25. Above 25 characters will be cut off");
        NamePromptLabel.setFont (new Font ("Times New Roman", Font.PLAIN, 18));
        NamePromptLabel.setBounds(50, 50, 800, 100);
        NamePromptLabel.setBackground(Color.YELLOW);
        NamePromptLabel.setForeground (Color.white);
        NameFrame.add(NamePromptLabel);
    }
     /** 
    * This method is displays textfield
    */
    public void displayNameTextField (){
        NameLabel.setText ("Name:");
        NameLabel.setBounds(100, 120, 100, 100);
        NameLabel.setFont (new Font ("Times New Roman", Font.PLAIN, 30));
        NameLabel.setForeground (Color.white);
        NameTextField.setPreferredSize(new Dimension(600,40));
        NameTextField.setFont(new Font ("Consolas", Font.PLAIN, 35));
        NameTextField.setBackground(Color.WHITE);
        NameTextField.setBounds(200, 150, 600, 50);
        NameFrame.add (NameLabel);
        NameFrame.add (NameTextField);
    }
     /** 
    * This method is displays button
    */
    public void displaySubmitButton (){
        SubmitButton.setBounds(200, 250, 200, 50);
        SubmitButton.setIcon(SubmitButtonImage);
        SubmitButton.setBackground(Color.BLACK);
        SubmitButton.setFocusable(false);
        SubmitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                strName = NameTextField.getText();
                if (strName.length() > 25)
                {
                    strName = strName.substring(0,25); 
                }
                else if  (strName.length() < 1)
                {
                   displayInvalidNameInput();
                }
                else
                {
                    displayInputName(strName);
                }
            }
        });
        NameFrame.add (DisplayNameLabel);
        NameFrame.add (SubmitButton);
       
    }
     /** 
    * This method is displays prompt
    */
    public void displayInvalidNameInput (){
        DisplayNameLabel.setText(" PLS ENTER A VALID NAME !");
        DisplayNameLabel.setBounds(100, 300, 500, 100);
        DisplayNameLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        DisplayNameLabel.setHorizontalAlignment(JLabel.CENTER);
        DisplayNameLabel.setVerticalAlignment(JLabel.BOTTOM);
        DisplayNameLabel.setForeground(Color.WHITE);
    }
     /** 
    * This method is displays input
    */
    public void displayInputName (String strName){
        DisplayNameLabel.setText("NAME: "+ strName);
        DisplayNameLabel.setBounds(100, 300, 500, 100);
        DisplayNameLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        DisplayNameLabel.setHorizontalAlignment(JLabel.CENTER);
        DisplayNameLabel.setVerticalAlignment(JLabel.BOTTOM);
        DisplayNameLabel.setForeground(Color.WHITE);
    }
     /** 
    * This method is displays button
    */
    public void displayBackButton (){
        BackButton.setBounds(550, 250, 150, 50);
        BackButton.setIcon(BackButtonImage);
        BackButton.setBackground(Color.BLACK);
        BackButton.setFocusable(false);
        BackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                NameFrame.dispose();
            }
        });
        NameFrame.add (BackButton);
    }
    // Getters
     /** 
    * This method is getter
    */
    public String getName (){
        return strName; 
    }
}
