import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/** 
 * This is the Area One
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class AreaOne {
    /** 
     * This field is for Area One Floor one Frame
     */
    protected JFrame CAreaOneFloorOneFrame;
    /** 
     * This field is for Area One Floor Two Frame
     */
    protected JFrame CAreaOneFloorTwoFrame;
    /** 
     * This field is for the Area One Floor three frame
     */
    protected JFrame CAreaOneFloorThreeFrame; 
    /** 
     * This field is for the tile deactivation
     */
    protected JFrame CDeactivatedTileFrame;
    /** 
     * This field is for the deactivated tile label
     */
    protected JLabel CDeactivatedTileLabel;
    /** 
     * This field is for the Area one title Label;
     */
    protected JLabel CAreaOneTitleLabel;
    /** 
     * This field is for the area one floor one label
     */
    protected JLabel CAreaOneFloorOne;
    /** 
     * This field is for the area one floor two
     */
    protected JLabel CAreaOneFloorTwo; 
    /** 
     * This field is for the area one floor three
     */
    protected JLabel CAreaOneFloorThree; 
    /** 
     * This field is for the player health label
     */
    protected JLabel CPlayerHealthLabel; 
     /** 
     * This field is for the player level
     */
    protected JLabel CPlayerLevelLabel;
     /** 
     * This field is for the runes label
     */
    protected JLabel CRunesLabel;
     /** 
     * This field is for the image of stromviel
     */
    protected ImageIcon CStromveilTitle;
     /** 
     * This field is for the area one floor one image
     */
    protected ImageIcon  CAreaOneFloorOneImage;
     /** 
     * This field is for the area one floor two image
     */
    protected ImageIcon CAreaOneFloorTwoImage;
     /** 
     * This field is for the area one floor three image
     */
    protected ImageIcon CAreaOneFloorThreeImage; 
     /** 
     * This field is for the player token image
     */
    protected ImageIcon CPlayerTokenImage; 
     /** 
     * This field is for the move up button
     */
    protected JButton CMoveUpButton;
     /** 
     * This field is for the move down button
     */
    protected JButton CMoveDownButton;
     /** 
     * This field is for the move left button
     */
    protected JButton CMoveLeftButton;
     /** 
     * This field is for the move right button
     */
    protected JButton CMoveRightButton;
     /** 
     * This field is for the interact button
     */
    protected JButton CInteractButton;
     /** 
     * This field is for the player token label
     */
    protected JLabel CPlayerTokenLabel; 
     /** 
     * This field is for the tiles class
     */
    protected Tiles CTiles; 
     /** 
     * This field is for the enemy class
     */
    protected Enemy CEnemy; 
     /** 
     * This field is for the x axis of the frame
     */
    protected int nX; 
    /** 
     * This field is for the y axis of the frame
     */
    protected int nY; 
     /** 
     * This field is for the floor level
     */
    protected int nFloorLevel; 
     /** 
     * This field is for the Area Index
     */
    protected int nAreaIndex;
     /** 
     * This field is for the boss alive 
     */
    protected boolean bBossAlive;
     /** 
     * This field is for the Runes
     */
    protected int nRunes;
     /** 
     * This field is for the player level
     */
    protected int nPlayerLevel;
     /** 
     * This field is for the health
     */
    protected int nHealth; 
     /** 
     * This field is for the player class
     */
    protected Player CPlayer;
     /** 
     * This field is for the battle class
     */
    protected Battle CBattle;
     /** 
     * This field is for the active tile class
     */
    protected boolean [] bActiveTiles;
     /** 
     * This field is for the name
     */
    protected String strName;
     /** 
     * This field is for the level
     */
    protected int nLevel; 
     /** 
     * This field is for the player hp
     */
    protected int nPlayerHp;
     /** 
     * This field is for the player dexterity
     */
    protected int nPlayerDex;
     /** 
     * This field is for the player intelligence
     */
    protected int nPlayerInt;
     /** 
     * This field is for the player endurance
     */
    protected int nPlayerEnd;
     /** 
     * This field is for the strength
     */
    protected int nPlayerStr;
     /** 
     * This field is for the player faith
     */
    protected int nPlayerFth;
     /** 
     * This field is for the weapon hp
     */
    protected int nWeaponHp;
     /** 
     * This field is for the weapon dexterity
     */
    protected int nWeaponDex;
     /** 
     * This field is for the weapon intelligence
     */
    protected int nWeaponInt;
     /** 
     * This field is for the weapon endurance
     */
    protected int nWeaponEnd;
     /** 
     * This field is for the weapon strength
     */
    protected int nWeaponStr;
     /** 
     * This field is for the weapon faith
     */
    protected int nWeaponFth;
     /** 
     * This constructor is for the area one
     * @param nAreaIndex for area index
     * @param strName for the name
     * @param nLevel for the level
     * @param nRunes for the runes
     * @param nPlayerHp for the player hp
     * @param nPlayerDex for the player dexterity 
     * @param nPlayerInt for the Player intelligence
     * @param nPlayerEnd for the player Endurance
     * @param nPlayerStr for the player strength
     * @param nPlayerFth for the player faith
     * @param nWeaponHp for the weapon hp
     * @param nWeaponDex for the weapon dexterity
     * @param nWeaponInt for the weapon intellgence
     * @param nWeaponEnd for the weapon endurance
     * @param nWeaponStr for the weapon strength 
     * @param nWeaponFth for the weapon faith
     */
    public AreaOne (int nAreaIndex, String strName, int nLevel, int nRunes, int nPlayerHp, int nPlayerDex, int nPlayerInt, int nPlayerEnd, int nPlayerStr, int nPlayerFth, int nWeaponHp, int nWeaponDex, int nWeaponInt, int nWeaponEnd,int nWeaponStr, int nWeaponFth){
        CAreaOneFloorOneFrame = new JFrame ();
        CAreaOneFloorTwoFrame = new JFrame();
        CAreaOneFloorThreeFrame = new JFrame(); 
        CAreaOneTitleLabel = new JLabel();
        CPlayerHealthLabel = new JLabel();
        CPlayerLevelLabel = new JLabel();
        CRunesLabel = new JLabel();
        CStromveilTitle = new ImageIcon ("AreaOneStormveilCastle.png");
        CAreaOneFloorOne = new JLabel();
        CAreaOneFloorTwo = new JLabel();
        CAreaOneFloorThree = new JLabel(); 
        CAreaOneFloorOneImage = new ImageIcon("AreaOneFloorOne.png");
        CAreaOneFloorTwoImage = new ImageIcon("AreaOneFloorTwo.png");
        CAreaOneFloorThreeImage = new ImageIcon("AreaOneFloorThree.png");
        CMoveUpButton = new JButton();
        CMoveDownButton = new JButton();
        CMoveLeftButton = new JButton ();
        CMoveRightButton = new JButton(); 
        CInteractButton = new JButton();
        CPlayerTokenLabel = new JLabel();
        CPlayerTokenImage = new ImageIcon("PlayerToken.png");
        CEnemy = new Enemy(); 
        nX= 0;
        nY= 0;
        nFloorLevel = 1;
        this.nAreaIndex = nAreaIndex;
        bBossAlive = true;
        nPlayerLevel = 0;
        nHealth = 0;
        this.strName = strName;
        this.nLevel = nLevel;
        this.nRunes = nRunes;
        this.nPlayerHp = nPlayerHp;
        this.nPlayerDex = nPlayerDex;
        this.nPlayerInt = nPlayerInt;
        this.nPlayerEnd = nPlayerEnd;
        this.nPlayerStr = nPlayerStr;
        this.nPlayerFth = nPlayerFth;
        this.nWeaponHp = nWeaponHp;
        this.nWeaponDex = nWeaponDex;
        this.nWeaponInt= nWeaponInt;
        this.nWeaponEnd = nWeaponEnd;
        this.nWeaponStr = nWeaponStr;
        this.nWeaponFth = nWeaponFth;
        CTiles = new Tiles(1, strName, nRunes, nPlayerHp, nPlayerDex, nPlayerInt, nPlayerEnd, nPlayerStr, nPlayerFth, nWeaponHp, nWeaponDex, nWeaponInt, nWeaponEnd, nWeaponStr, nWeaponFth);
        CDeactivatedTileFrame = new JFrame();
        CDeactivatedTileLabel = new JLabel();
        bActiveTiles = new boolean[10];
     
    }
     /** 
     * This method is for the area one floor one
     * @param nX for the x axis
     * @param nY is for the y axis
     */
    public void openAreaOneFloorOne (int nX, int nY){
        CPlayer = new Player(strName, nPlayerEnd, nWeaponEnd,nPlayerHp, nWeaponHp, nPlayerStr, nWeaponStr, nPlayerInt, nWeaponInt, nPlayerFth, nWeaponFth, nRunes);
        CBattle = new Battle();
        this.nX = nX;
        this.nY = nY;
        initializeActiveTiles(10);
        displayAreaOneTitle();
        displayPlayerToken(nX, nY);
        displayAreaOneFloorOneFrame();
        displayMoveButtons();
        displayAreaOneFloorOne();
        displayPlayerHealth();
        displayPlayerLevel();
        displayPlayerRunes();
        
        CAreaOneFloorOneFrame.setVisible (true); 
    }
    /** 
     * This method is for initializing active tiles
     * @param nSpawnTiles
     */
    public void initializeActiveTiles (int nSpawnTiles)
    {
        for (int i = 0; i < nSpawnTiles; i++)
        {
            bActiveTiles [i] = true;
        }
    }
       /** 
     * This method is for the area one floor two
     * @param nX for the x axis
     * @param nY is for the y axis
     */
    public void openAreaOneFloorTwo (int nX, int nY){
        displayAreaOneFloorTwoFrame();
        displayAreaOneTitle();
        displayPlayerToken(nX, nY);
        displayPlayerHealth();
        displayPlayerLevel();
        displayPlayerRunes();
        CAreaOneFloorTwoFrame.add(CAreaOneTitleLabel);
        CAreaOneFloorTwoFrame.add(CMoveUpButton);
        CAreaOneFloorTwoFrame.add(CMoveRightButton);
        CAreaOneFloorTwoFrame.add(CMoveDownButton);
        CAreaOneFloorTwoFrame.add(CMoveLeftButton);
        CAreaOneFloorTwoFrame.add(CInteractButton);
        CAreaOneFloorTwoFrame.add(CPlayerTokenLabel);
        CAreaOneFloorTwoFrame.add(CPlayerHealthLabel);
        CAreaOneFloorTwoFrame.add(CPlayerLevelLabel);
        CAreaOneFloorTwoFrame.add(CRunesLabel);
        displayAreaOneFloorTwo();
      CAreaOneFloorTwoFrame.setVisible (true); 
    }
       /** 
     * This method is for the area one floor three
     * @param nX for the x axis
     * @param nY is for the y axis
     */
    public void openAreaOneFloorThree (int nX, int nY){
        displayAreaOneFloorThreeFrame();
        displayAreaOneTitle();
        displayPlayerToken(nX, nY);
        displayPlayerHealth();
        displayPlayerLevel();
        displayPlayerRunes();
        CAreaOneFloorThreeFrame.add(CAreaOneTitleLabel);
        CAreaOneFloorThreeFrame.add(CMoveUpButton);
        CAreaOneFloorThreeFrame.add(CMoveRightButton);
        CAreaOneFloorThreeFrame.add(CMoveDownButton);
        CAreaOneFloorThreeFrame.add(CMoveLeftButton);
        CAreaOneFloorThreeFrame.add(CInteractButton);
        CAreaOneFloorThreeFrame.add(CPlayerTokenLabel);
        CAreaOneFloorThreeFrame.add(CPlayerHealthLabel);
        CAreaOneFloorThreeFrame.add(CPlayerLevelLabel);
        CAreaOneFloorThreeFrame.add(CRunesLabel);
        displayAreaOneFloorThree();
        CAreaOneFloorThreeFrame.setVisible (true); 
    }
    /** 
     * This method is for the area one floor one frame
     */
    public void displayAreaOneFloorOneFrame (){
        CAreaOneFloorOneFrame.setSize (1000, 700);
        CAreaOneFloorOneFrame.setTitle("Area One Floor One");
        CAreaOneFloorOneFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CAreaOneFloorOneFrame.setLayout(null);
        CAreaOneFloorOneFrame.getContentPane().setBackground(Color.GRAY);
    }
    /** 
     * This method is for the area one floor two frame
     */
    public void displayAreaOneFloorTwoFrame (){
        CAreaOneFloorTwoFrame.setSize (1000, 700);
        CAreaOneFloorTwoFrame.setTitle("Area One Floor Two");
        CAreaOneFloorTwoFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CAreaOneFloorTwoFrame.setLayout(null);
        CAreaOneFloorTwoFrame.getContentPane().setBackground(Color.GRAY);
    }
    /** 
     * This method is for the area one floor three frame
     */
    public void displayAreaOneFloorThreeFrame (){
        CAreaOneFloorThreeFrame.setSize (1000, 700);
        CAreaOneFloorThreeFrame.setTitle("Area One Floor Three");
        CAreaOneFloorThreeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CAreaOneFloorThreeFrame.setLayout(null);
        CAreaOneFloorThreeFrame.getContentPane().setBackground(Color.GRAY);
    }
    /** 
     * This method displays area one title
     */
    public void displayAreaOneTitle (){
        CAreaOneTitleLabel.setIcon(CStromveilTitle);
        CAreaOneTitleLabel.setVerticalAlignment(JLabel.TOP);
        CAreaOneTitleLabel.setHorizontalAlignment(JLabel.CENTER);
        CAreaOneTitleLabel.setBounds(240,0, 550, 400);
        CAreaOneFloorOneFrame.add(CAreaOneTitleLabel);
    }
    /** 
     * This method displays player token
     */
    public void displayPlayerToken (int nX, int nY){
        CPlayerTokenLabel.setIcon(CPlayerTokenImage);
        CPlayerTokenLabel.setBounds(nX, nY, 50, 50);
        switch (nFloorLevel)
        {
            case 1:
            CAreaOneFloorOneFrame.add(CPlayerTokenLabel);
            break;
            case 2:
            CAreaOneFloorTwoFrame.add(CPlayerTokenLabel);
            break; 
            case 3:
            CAreaOneFloorThreeFrame.add(CPlayerTokenLabel);
            break; 
        }

    }
    /** 
     * This method displays area one floor one
     */
    public void displayAreaOneFloorOne (){
        CAreaOneFloorOne.setIcon(CAreaOneFloorOneImage);
        CAreaOneFloorOne.setVerticalAlignment(JLabel.TOP);
        CAreaOneFloorOne.setHorizontalAlignment(JLabel.CENTER);
        CAreaOneFloorOne.setBounds(240,200, 550, 400);
        CAreaOneFloorOneFrame.add(CAreaOneFloorOne);
    }
      /** 
     * This method area one floor two
     */
    public void displayAreaOneFloorTwo ()
    {
        CAreaOneFloorTwo.setIcon(CAreaOneFloorTwoImage);
        CAreaOneFloorTwo.setVerticalAlignment(JLabel.TOP);
        CAreaOneFloorTwo.setHorizontalAlignment(JLabel.CENTER);
        CAreaOneFloorTwo.setBounds(240,200, 550, 400);
        CAreaOneFloorTwoFrame.add(CAreaOneFloorTwo);
    }
      /** 
     * This method area one floor three
     */
    public void displayAreaOneFloorThree (){
        CAreaOneFloorThree.setIcon(CAreaOneFloorThreeImage);
        CAreaOneFloorThree.setVerticalAlignment(JLabel.TOP);
        CAreaOneFloorThree.setHorizontalAlignment(JLabel.CENTER);
        CAreaOneFloorThree.setBounds(240,200, 550, 400);
        CAreaOneFloorThreeFrame.add(CAreaOneFloorThree);
    }
     /** 
     * This method displays control buttons
     */
    public void displayMoveButtons (){
        displayMoveUpButton();
        displayMoveDownButton();
        displayMoveRightButton();
        displayMoveLeftButton();
        displayInteractButton();
    }
    /** 
     * This method displays move up button
     */
    public void displayMoveUpButton (){
        CMoveUpButton.setBounds(200, 200, 50, 50);
        CMoveUpButton.setText("W");
        CMoveUpButton.setBackground(Color.BLACK);
        CMoveUpButton.setForeground (Color.YELLOW);
        CMoveUpButton.setFocusable(false);
        CMoveUpButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CMoveUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            switch (nFloorLevel)
            {
                case 1: 
                nY -= 40;
                if (nY >= 195 )
                {
                    displayPlayerToken(nX, nY);
                    displayAreaOneFloorOne();
                }
                else
                {
                    nY += 40;
                }
            
                break; 
                case 2: 
                nY -= 40;
                if (nY >= 195 )
                {
                    displayPlayerToken(nX, nY);
                    displayAreaOneFloorTwo(); 
                  
                }
                else
                {
                    nY += 40;
                }
              
                break;
               case 3:
               nY -= 40;
               if (nY >= 195 )
               {
                   displayPlayerToken(nX, nY);
                   displayAreaOneFloorThree(); 
                
               }
               else
               {
                   nY += 40;
               }
         
               break; 
                
            }
            
            }
        });
        CAreaOneFloorOneFrame.add (CMoveUpButton);
    }
     /** 
     * This method displays move down button
     */
    public void displayMoveDownButton (){
        CMoveDownButton.setBounds(200, 300, 50, 50);
        CMoveDownButton.setText("S");
        CMoveDownButton.setBackground(Color.BLACK);
        CMoveDownButton.setForeground (Color.YELLOW);
        CMoveDownButton.setFocusable(false);
        CMoveDownButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CMoveDownButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (nFloorLevel)
                {
                    case 1:
                    nY += 40;
                    if (nY <= 435)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorOne();
                    }
                    else
                    {
                        nY -= 40;
                    }
                    break; 
                    case 2:
                    nY += 40;
                    if (nY <= 435)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorTwo();
                    }
                    else
                    {
                        nY -= 40;
                    }
                   
                    break; 
                    case 3:
                    nY += 40;
                    if (nY <= 435)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorThree();
                    }
                    else
                    {
                        nY -= 40;
                    }
                    
                    break;
                }
            }
        });
        CAreaOneFloorOneFrame.add (CMoveDownButton);
    }
     /** 
     * This method displays move left button
     */
    public void displayMoveLeftButton (){
        CMoveLeftButton.setBounds(150, 250, 50, 50);
        CMoveLeftButton.setText("A");
        CMoveLeftButton.setBackground(Color.BLACK);
        CMoveLeftButton.setForeground (Color.YELLOW);
        CMoveLeftButton.setFocusable(false);
        CMoveLeftButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CMoveLeftButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (nFloorLevel)
                {
                    case 1:
                    nX -= 40;
                    if (nX >= 455)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorOne();
                        
                    }
                    else
                    {
                        nX += 40;
                    }
                    
                    break;
                    case 2:
                    nX -= 45;
                    if (nX >= 360)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorTwo();
                        
                    }
                    else
                    {
                        nX += 45;
                    }
                  
                    break;
                    case 3: 
                    nX -= 40;
                    if (nX >= 415 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorThree();
                        
                    }
                    else
                    {
                        nX += 40;
                    }
             
                    break; 
                }
                
              
            }
        });
        CAreaOneFloorOneFrame.add (CMoveLeftButton);
    }
     /** 
     * This method displays move Right button
     */
    public void displayMoveRightButton (){
        CMoveRightButton.setBounds(250, 250, 50, 50);
        CMoveRightButton.setText("D");
        CMoveRightButton.setBackground(Color.BLACK);
        CMoveRightButton.setForeground (Color.YELLOW);
        CMoveRightButton.setFocusable(false);
        CMoveRightButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CMoveRightButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (nFloorLevel)
                {
                    case 1:
                    nX += 40; 
                    if (nX <= 535)
                        {
                            displayPlayerToken(nX, nY);
                            displayAreaOneFloorOne();
                        }
                        else
                        {
                            nX -= 40;
                        }
                      
                    break;

                    case 2:
                    nX += 45; 
                    if (nX <= 630 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorTwo();
                    }
                    else 
                    {
                        nX -= 45;
                    }
                   
                    break;

                    case 3:
                    nX += 40;
                    if (nX <= 575 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorThree();
                    }
                    else
                    {
                        nX -= 40;
                    }
                    break;
                }
                
            }
        });
        CAreaOneFloorOneFrame.add (CMoveRightButton);
    }
     /** 
     * This method displays interact button
     */
    public void displayInteractButton (){
        CInteractButton.setBounds(200, 250, 50, 50);
        CInteractButton.setText("E");
        CInteractButton.setBackground(Color.BLACK);
        CInteractButton.setForeground (Color.YELLOW);
        CInteractButton.setFocusable(false);
        CInteractButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CInteractButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
         {
            switch (nFloorLevel)
            {
                case 1:
                if (nX == 495 && nY == 195)
                {
                    nX = 495;
                    nY = 435;
                    nFloorLevel = 2; 
                    openAreaOneFloorTwo(nX, nY);
                    CAreaOneFloorOneFrame.dispose();
                }
                else if (nX == 535 && nY == 235 )
                {
                    if (CTiles.checkActiveTile(bActiveTiles[1]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        nRunes += CTiles.getRunes();
                        System.out.println ("nRunes" + CTiles.getRunes());
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[1] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 455 && nY == 235 ){
                    if (CTiles.checkActiveTile(bActiveTiles[2]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        nRunes += CTiles.getRunes();
                        System.out.println ("nRunes" + CTiles.getRunes());
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[2] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                  
                }
                else if (nX == 495 && nY == 435)
                {
                    GameLobby CGameLobby = new GameLobby();
                    CGameLobby.openGameLobby();
                }
                break;
                case 2:
                // Floor 2
                if (nX == 495 && nY == 435)
                {
                    nFloorLevel = 1;
                    nX = 495;
                    nY = 195;
                    openAreaOneFloorOne(nX, nY);
                    CAreaOneFloorTwoFrame.dispose();
                }
                else if (nX == 540 && nY == 395)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[3]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[3] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                  
                }
                else if ( nX == 450 && nY == 395)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[4]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[4] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 360 && nY == 315 )
                {
                    if (CTiles.checkActiveTile(bActiveTiles[5]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[5] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if ( nX == 450 && nY == 315)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[6]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[6] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 495 && nY == 315)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[7]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[7] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 540 && nY == 315)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[8]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[8] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 630 && nY == 315 )
                {
                    if (CTiles.checkActiveTile(bActiveTiles[9]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[9] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 495 && nY == 235 )
                {
                    if (CTiles.checkActiveTile(bActiveTiles[0]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[0] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 495 && nY == 195)
                {
                    nFloorLevel = 3;
                    CAreaOneFloorTwoFrame.dispose();
                    nX = 495;
                    nY = 435;
                    openAreaOneFloorThree(nX, nY);
                }
                break; 
                case 3:
                if (nX == 495 && nY == 435)
                {
                    nFloorLevel = 2; 
                    // Door Tile
                    nX = 495;
                    nY = 195;
                    openAreaOneFloorTwo(nX, nY);
                    CAreaOneFloorThreeFrame.dispose();
                    
                }
                else if (nX == 495 && nY == 315 )
                {
                    // Boss Tile
                    CTiles.openBossTile(nAreaIndex);
                    if (CEnemy.getEnemyHealth() <= 0)
                    {
                        bBossAlive = false;
                    }
                   
                }
                else if (nX == 495 && nY == 195 )
                {
                    if (CTiles.checkFastTravel(bBossAlive) == true)
                    {
                        AreaTwo CAreaTwo = new AreaTwo(2, strName, nLevel, nRunes, nPlayerHp, nPlayerDex, nPlayerInt, nPlayerEnd, nPlayerStr, nPlayerFth, nWeaponHp, nWeaponDex, nWeaponInt, nWeaponEnd, nWeaponStr, nWeaponFth);
                        CAreaTwo.openAreaTwo (495, 193);
                        CAreaOneFloorThreeFrame.dispose ();
                    }
                    
                }
            }
           
        }
        });
        CAreaOneFloorOneFrame.add (CInteractButton);
    }
     /** 
     * This method displays player health
     */
  public void displayPlayerHealth (){
        CPlayerHealthLabel.setText("Health [" + computePlayerHealth(nPlayerHp, nWeaponHp) + "]");
        CPlayerHealthLabel.setHorizontalAlignment(JLabel.CENTER);
        CPlayerHealthLabel.setVerticalAlignment(JLabel.BOTTOM);
        CPlayerHealthLabel.setBounds(100, 250, 300, 200);
        CPlayerHealthLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CPlayerHealthLabel.setForeground(Color.WHITE);
        CAreaOneFloorOneFrame.add (CPlayerHealthLabel);  
  }
   /** 
     * This method displays player level
     */
  public void displayPlayerLevel ()
  {
    CPlayerLevelLabel.setText("Level [" + nLevel + "]");
    CPlayerLevelLabel.setHorizontalAlignment(JLabel.CENTER);
    CPlayerLevelLabel.setVerticalAlignment(JLabel.BOTTOM);
    CPlayerLevelLabel.setBounds(100, 300, 300, 200);
    CPlayerLevelLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
    CPlayerLevelLabel.setForeground(Color.WHITE);
    CAreaOneFloorOneFrame.add (CPlayerLevelLabel);  
  }
   /** 
     * This method displays Runes
     */
  public void displayPlayerRunes (){
    CRunesLabel.setText("Runes [" + nRunes + "]");
    CRunesLabel.setHorizontalAlignment(JLabel.CENTER);
    CRunesLabel.setVerticalAlignment(JLabel.BOTTOM);
    CRunesLabel.setBounds(100, 350, 300, 200);
    CRunesLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
    CRunesLabel.setForeground(Color.WHITE);
    CAreaOneFloorOneFrame.add (CRunesLabel);  
  }
   /** 
     * This method displays deactivates tile frame
     */
  public void displayDeactivatedTileFrame (){
    CDeactivatedTileFrame.setSize (400, 400);
    CDeactivatedTileFrame.setTitle("Credits.png");
    CDeactivatedTileFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    CDeactivatedTileFrame.setLayout(null);
    CDeactivatedTileFrame.getContentPane().setBackground(Color.BLACK);
    displayDeactivatedTilePrompt();
    CDeactivatedTileFrame.setVisible(true);
  }
  /** 
     * This method displays deactivates tile prompt
     */
  public void displayDeactivatedTilePrompt ()
  {
    CDeactivatedTileLabel.setText("DEACTIVATED TILE !");
    CDeactivatedTileLabel.setHorizontalAlignment(JLabel.CENTER);
    CDeactivatedTileLabel.setVerticalAlignment(JLabel.BOTTOM);
    CDeactivatedTileLabel.setBounds(50, 10, 300, 200);
    CDeactivatedTileLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
    CDeactivatedTileLabel.setForeground(Color.RED);
    CDeactivatedTileFrame.add (CDeactivatedTileLabel);  
  }
  /** 
     * This method computes Player Health
     * @param nStatHealth for player health
     * @param nWeaponHealth for weapon health
     */
  public int computePlayerHealth (int nStatHealth, int nWeaponHealth){
    return (int) (100 * ((nStatHealth + nWeaponHealth)/2));
}
}


