import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/** 
 * This is the gamelobby class
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class GameLobby extends JobClasses {
    /** 
    * This field is for the frame
    */
    private JFrame GameLobbyFrame;
     /** 
    * This field is for the image
    */
    private ImageIcon GameLobbyTitleImage;
      /** 
    * This field is for the image
    */
    private ImageIcon FastTravelButtonImage;
      /** 
    * This field is for the image
    */
    private ImageIcon LevelUpButtonImage;
      /** 
    * This field is for the image
    */
    private ImageIcon InventoryButtonImage;
      /** 
    * This field is for the image
    */
    private ImageIcon ShopButtonImage;
      /** 
    * This field is for the image
    */
    private ImageIcon QuitGameButtonImage; 
      /** 
    * This field is for the label
    */
    private JLabel GameLobbyLabel;
      /** 
    * This field is for the button
    */
    private JButton FastTravelButton;
      /** 
    * This field is for the button
    */
    private JButton LevelUpButton;
     /** 
    * This field is for the button
    */
    private JButton InventoryButton;
     /** 
    * This field is for the button
    */
    private JButton ShopButton;
     /** 
    * This field is for the button
    */
    private JButton QuitGameButton;
     /** 
    * This field is for the label
    */
    private JLabel PlayerNameLabel;
     /** 
    * This field is for the label
    */
    private JLabel PlayerJobClassLabel;
     /** 
    * This field is for the label
    */
    private JLabel PlayerLevelLabel;
     /** 
    * This field is for the label
    */
    private JLabel PlayerRunesLabel; 
    // Fields
     /** 
    * This field is for the name
    */
    private String strName; 
     /** 
    * This field is for the level
    */
    private String strJobclass;
     /** 
    * This field is for the level
    */
    private int nLevel; 
     /** 
    * This field is for the runes
    */
    private int nRunes; 
     /** 
    * This field is for the weapon hp
    */
    private int nWeaponHp;
     /** 
    * This field is for the dexterity
    */
    private int nWeaponDex;
     /** 
    * This field is for the intellegence
    */
    private int nWeaponInt;
     /** 
    * This field is for the endurance
    */
    private int nWeaponEnd;
     /** 
    * This field is for the strength
    */
    private int nWeaponStr;
     /** 
    * This field is for the faith
    */
    private int nWeaponFth;
    // Class
     /** 
    * This field is for the inventory class
    */
    private Inventory CInventory;
     /** 
    * This field is for the weapon class
    */
    private Weapon CWeapon;
     /** 
    * This constructor is for the gamelobby
    */
    public GameLobby ()
    {
        this.CInventory = new Inventory();
        this.GameLobbyFrame = new JFrame();
        this.GameLobbyTitleImage = new ImageIcon("GameLobby.png");
        this.FastTravelButtonImage = new ImageIcon("FastTravel.png"); 
        this.LevelUpButtonImage = new ImageIcon("LevelUp.png");
        this.InventoryButtonImage = new ImageIcon("Inventory.png");
        this.ShopButtonImage = new ImageIcon("Shop.png");
        this.QuitGameButtonImage = new ImageIcon("QuitGame.png"); 
        this.GameLobbyLabel = new JLabel (); 
        this.FastTravelButton = new JButton();
        this.LevelUpButton = new JButton();
        this.InventoryButton = new JButton();
        this.ShopButton = new JButton();
        this.QuitGameButton = new JButton();
        this.PlayerNameLabel = new JLabel(); 
        this.PlayerJobClassLabel = new JLabel();
        this.PlayerLevelLabel = new JLabel ();
        this.PlayerRunesLabel = new JLabel (); 
        this.CWeapon = new Weapon(nRunes);
        this.PlayerNameLabel = new JLabel();

    }
      /** 
     * This constructor is for the game lobby
     * @param nAreaIndex for area index
     * @param strName for the name
     * @param nLevel for the level
     * @param nRunes for the runes
     * @param nPlayerHp for the player hp
     * @param nPlayerDex for the player dexterity 
     * @param nPlayerInt for the Player intelligence
     * @param nPlayerEnd for the player Endurance
     * @param nPlayerStr for the player strength
     * @param nPlayerFth for the player faith
     * @param nWeaponHp for the weapon hp
     * @param nWeaponDex for the weapon dexterity
     * @param nWeaponInt for the weapon intellgence
     * @param nWeaponEnd for the weapon endurance
     * @param nWeaponStr for the weapon strength 
     * @param nWeaponFth for the weapon faith
     */
    public GameLobby (String strName, String strJobClass, int nLevel, int nRunes, int nHp, int nEndurance, int nDexterity, int nStrength, int nIntelligence, int nFaith){
        this.CInventory = new Inventory();
        this.GameLobbyFrame = new JFrame();
        this.GameLobbyTitleImage = new ImageIcon("GameLobby.png");
        this.FastTravelButtonImage = new ImageIcon("FastTravel.png"); 
        this.LevelUpButtonImage = new ImageIcon("LevelUp.png");
        this.InventoryButtonImage = new ImageIcon("Inventory.png");
        this.ShopButtonImage = new ImageIcon("Shop.png");
        this.QuitGameButtonImage = new ImageIcon("QuitGame.png"); 
        this.GameLobbyLabel = new JLabel (); 
        this.FastTravelButton = new JButton();
        this.LevelUpButton = new JButton();
        this.InventoryButton = new JButton();
        this.ShopButton = new JButton();
        this.QuitGameButton = new JButton();
        this.PlayerNameLabel = new JLabel(); 
        this.PlayerJobClassLabel = new JLabel();
        this.PlayerLevelLabel = new JLabel ();
        this.PlayerRunesLabel = new JLabel (); 
        this.strName = strName; 
        this.strJobclass = strJobClass;
        this.nLevel = nLevel; 
        this.nRunes = nRunes; 
        this.nHp = nHp;
        this.nEndurance = nEndurance;
        this.nDexterity = nDexterity;
        this.nStrength = nStrength;
        this.nIntelligence = nIntelligence;
        this.nFaith = nFaith;
        this.CWeapon = new Weapon(nRunes);
        this.PlayerNameLabel = new JLabel();

    } 
    /** 
     * This method opens game lobby
     */
    public void openGameLobby (){
        displayPlayerInformation();
        displayGameLobbyFrame();
        displayFastTravelButton();
        displayLevelUpButton();
        displayInventoryButton();
        this.nWeaponHp = CInventory.getWeaponHp();
        this.nWeaponDex = CInventory.getWeaponDexterity();
        this.nWeaponInt= CInventory.getWeaponIntelligence();
        this.nWeaponEnd = CInventory.getWeaponEndurance();
        this.nWeaponStr = CInventory.getWeaponStrength();
        this.nWeaponFth = CInventory.getWeaponFaith();
        displayShopButton();
        displayQuitGameButton();
        displayGameLobbyTitle();
        GameLobbyFrame.setVisible(true);

    }
    /** 
     * This method displays game lobby frame
     */
    public void displayGameLobbyFrame (){
        GameLobbyFrame.setSize (600, 900);
        GameLobbyFrame.setTitle("GameLobby Menu");
        GameLobbyFrame.setLayout(null);
        GameLobbyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        GameLobbyFrame.getContentPane().setBackground(Color.BLACK);
    }
    /** 
     * This method displays game lobby title
     */
    public void displayGameLobbyTitle (){
        GameLobbyLabel.setIcon(GameLobbyTitleImage);
        GameLobbyLabel.setVerticalAlignment(JLabel.TOP);
        GameLobbyLabel.setHorizontalAlignment(JLabel.CENTER);
        GameLobbyLabel.setBounds(10, 10, 600, 300);
        GameLobbyFrame.add(GameLobbyLabel);
    }
    /** 
     * This method displays player information
     */
    public void displayPlayerInformation (){
        displayPlayerName();
        displayPlayerJobClass();
        displayPlayerLevel();
        displayPlayerRunes();
    }
    /** 
     * This method displays player name 
     */
    public void displayPlayerName (){
        PlayerNameLabel.setText("Name: " + strName);
        PlayerNameLabel.setHorizontalAlignment(JLabel.CENTER);
        PlayerNameLabel.setVerticalAlignment(JLabel.BOTTOM);
        PlayerNameLabel.setBounds(60, 100, 300, 200);
        PlayerNameLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        PlayerNameLabel.setForeground(Color.WHITE);
        GameLobbyFrame.add (PlayerNameLabel);
    }
    /** 
     * This method displays jobclass
     */
    public void displayPlayerJobClass (){
        PlayerJobClassLabel.setText ("JobClass: " + strJobclass);
        PlayerJobClassLabel.setHorizontalAlignment(JLabel.CENTER);
        PlayerJobClassLabel.setVerticalAlignment(JLabel.BOTTOM);
        PlayerJobClassLabel.setBounds(100, 120, 300, 200);
        PlayerJobClassLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        PlayerJobClassLabel.setForeground(Color.WHITE);
        GameLobbyFrame.add (PlayerJobClassLabel);
    }
       /** 
     * This method displays level
     */
    public void displayPlayerLevel () {
        PlayerLevelLabel.setText ("Level: " + nLevel);
        PlayerLevelLabel.setHorizontalAlignment(JLabel.CENTER);
        PlayerLevelLabel.setVerticalAlignment(JLabel.BOTTOM);
        PlayerLevelLabel.setBounds(100, 140, 200, 200);
        PlayerLevelLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        PlayerLevelLabel.setForeground(Color.WHITE);
        GameLobbyFrame.add (PlayerLevelLabel);
    }
       /** 
     * This method displays runes
     */
    public void displayPlayerRunes (){
        PlayerRunesLabel.setText ("Runes: " + nRunes);
        PlayerRunesLabel.setHorizontalAlignment(JLabel.CENTER);
        PlayerRunesLabel.setVerticalAlignment(JLabel.BOTTOM);
        PlayerRunesLabel.setBounds(100, 160, 200, 200);
        PlayerRunesLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        PlayerRunesLabel.setForeground(Color.WHITE);
        GameLobbyFrame.add (PlayerRunesLabel);
    }
       /** 
     * This method displays button
     */
    public void displayFastTravelButton (){
        FastTravelButton.setBounds(230, 400, 150, 50);
        FastTravelButton.setIcon(FastTravelButtonImage);
        FastTravelButton.setFocusable(false);
        FastTravelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              FastTravel CFastTravel = new FastTravel(strName, nLevel, nHp, nDexterity, nIntelligence, nEndurance, nStrength, nFaith, nWeaponHp, nWeaponDex, nWeaponInt, nWeaponEnd, nWeaponStr, nWeaponFth);
              CFastTravel.openFastTravel();
              GameLobbyFrame.dispose();
            }
        });
        GameLobbyFrame.add (FastTravelButton);
    }
      /** 
     * This method displays button
     */
    public void displayLevelUpButton (){
        LevelUpButton.setBounds(230, 470, 150, 50);
        LevelUpButton.setIcon(LevelUpButtonImage);
        LevelUpButton.setFocusable(false);
        LevelUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              LevelUp CLevelUp = new LevelUp(nRunes, nLevel, nHp, nEndurance, nDexterity, nStrength, nIntelligence, nFaith);
              CLevelUp.openLevelUp();
            }
        });
        GameLobbyFrame.add (LevelUpButton);
    }
      /** 
     * This method displays button
     */
    public void displayInventoryButton (){
        InventoryButton.setBounds(230, 530, 150, 50);
        InventoryButton.setIcon(InventoryButtonImage);
        InventoryButton.setFocusable(false);
        InventoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                CInventory.setArrayList(CWeapon.getPurchasedWeaponList(), CWeapon.getPurchasedWeaponSize());
              CInventory.openInventorySelectionMenu();
              
            }
        });
        GameLobbyFrame.add (InventoryButton);
    }
      /** 
     * This method displays button
     */
    public void displayShopButton (){
        ShopButton.setBounds(230, 600, 150, 50);
        ShopButton.setIcon(ShopButtonImage);
        ShopButton.setFocusable(false);
        ShopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              Shop CShop = new Shop(nRunes);
              CShop.openShop();
            }
        });
        GameLobbyFrame.add (ShopButton);
    }
    /** 
     * This method displays button
     */
    public void displayQuitGameButton (){
        QuitGameButton.setBounds(230, 670, 150, 50);
        QuitGameButton.setIcon(QuitGameButtonImage);
        QuitGameButton.setFocusable(false);
        QuitGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            GameLobbyFrame.dispose();
              TitleScreen CTitleScreen = new TitleScreen();
              CTitleScreen.openTitleScreen();
            }
        });
        GameLobbyFrame.add (QuitGameButton);
    }
    
}
