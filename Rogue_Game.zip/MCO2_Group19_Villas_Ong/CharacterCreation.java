import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/** 
 * This class creates character of the user
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class CharacterCreation {
    // GUI fields
    /**
     * This field is for the invalid prompt frame
     */
    private JFrame CInvalidPromptFrame;
     /**
     * This field is for the character creation frame
     */
    private JFrame CCharacterCreationFrame;
    /**
     * This field is for the character creation title
     */
    private ImageIcon CCharacterCreationTitle; 
    /**
     * This field is for the name button image 
     */
    private ImageIcon CNameButtonImage; 
    /**
     * This field is for the jobclass button image
     */
    private ImageIcon CJobClassButtonImage;
    /**
     * This field is for the confirm button image
     */
    private ImageIcon CConfirmButtonImage; 
    /**
     * This field is for the back button image
     */
    private ImageIcon CBackButtonImage;
    /**
     * This field is for the character creaction label
     */
    private JLabel CCharacterCreationLabel; 
    /**
     * This field is for the invalid prompt label
     */
    private JLabel CInvalidPromptLabel; 
    /**
     * This field is for the name label
     */
    private JLabel CNameLabel; 
    /**
     * This field is for the jobclass name label
     */
    private JLabel CJobClassNameLabel;
    /**
     * This field is for the level label
     */ 
    private JLabel CLevelLabel; 
    /**
     * This field is for the statistics label
     */
    private JLabel CStatisticsLabel;
    /**
     * This field is for the name button
     */
    private JButton CNameButton;
    /**
     * This field is for the jobclass button
     */
    private JButton CJobClassButton;
    /**
     * This field is for the confirm button
     */
    private JButton CConfirmButton;
    /**
     * This field is for the back button
     */
    private JButton CBackButton ; 
    /**
     * This field is for the invalid prompt back button
     */
    private JButton CInvalidPromptBackButton;
    /**
     * This field is for the check input button
     */
    private JButton CCheckInputButton;
    
    // Class Fields
    /**
     * This field is for the jobclass class
     */
    private JobClasses CJobClass;
    /**
     * This field is for the name class
     */
    private Name CName;
    /**
     * This field is for the input name once
     */
    private boolean bInputOnce; 
    // fields
    /**
     * This constructor is for the character creation
     */
    public CharacterCreation (){
        this.CCharacterCreationFrame = new JFrame();
        this.CCharacterCreationTitle = new ImageIcon("CharacterCreationTitle.png"); 
        this.CNameButtonImage = new ImageIcon("Name.png"); 
        this.CJobClassButtonImage = new ImageIcon("JobClass.png");
        this.CConfirmButtonImage = new ImageIcon ("Confirm.png"); 
        this.CBackButtonImage = new ImageIcon("Back.png");
        this.CCharacterCreationLabel = new JLabel (); 
        this.CInvalidPromptLabel = new JLabel();
        this.CNameLabel = new JLabel();
        this.CJobClassNameLabel = new JLabel();
        this.CLevelLabel = new JLabel();
        this.CStatisticsLabel = new JLabel();
        this.CNameButton = new JButton();
        this.CJobClassButton = new JButton();
        this.CConfirmButton = new JButton();
        this.CBackButton = new JButton(); 
        this.CInvalidPromptBackButton = new JButton();
        this.CCheckInputButton = new JButton();
        this.CInvalidPromptFrame = new JFrame ();
        this.CJobClass = new JobClasses();
        this.CName = new Name (); 
        this.bInputOnce = false; 
    }
    /**
     * This method is for opening character creation
     */
    public void openCharacterCreation () {
        displayNameButton();
        displayJobClassesButton();
        displayConfirmButton();
        displayBackButton();
        displayCharacterCreationTitle();
        displayCheckInputButton();
        displayCharacterCreationFrame();
     
        CCharacterCreationFrame.setVisible (true);
    }
    /**
     * This method is for the character creation frame
     */
    public void displayCharacterCreationFrame () {
        CCharacterCreationFrame.setSize (600, 800);
        CCharacterCreationFrame.setTitle("Character Creation Menu");
        CCharacterCreationFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CCharacterCreationFrame.setLayout(null);
        CCharacterCreationFrame.getContentPane().setBackground(Color.BLACK);
    }
    /**
     * This method displays the title of the character creation
     */
    public void displayCharacterCreationTitle (){
        CCharacterCreationLabel.setIcon(CCharacterCreationTitle);
        CCharacterCreationLabel.setVerticalAlignment(JLabel.TOP);
        CCharacterCreationLabel.setHorizontalAlignment(JLabel.CENTER);
        CCharacterCreationLabel.setBounds(50, 50, 500, 400);
        CCharacterCreationFrame.add(CCharacterCreationLabel);
    }
    /**
     * This method is displays name button
     */
    public void displayNameButton () {
        CNameButton.setBounds(230, 230, 150, 50);
        CNameButton.setIcon(CNameButtonImage);
        CNameButton.setFocusable(false);
        CNameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (bInputOnce == false)
                {
                    CName.openName (); 
                }
                
            }
        });
        CCharacterCreationFrame.add (CNameButton);
    }
    /**
     * This method is displays jobclass button
     */
    public void displayJobClassesButton (){
        CJobClassButton.setBounds(230, 300, 150, 50);
        CJobClassButton.setIcon(CJobClassButtonImage);
        CJobClassButton.setFocusable(false);
        CJobClassButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CJobClass.openJobClass();
            }
        });
        CCharacterCreationFrame.add (CJobClassButton);
    }
    /**
     * This method is displays confirm button
     */
    public void displayConfirmButton () {
        CConfirmButton.setBounds(230, 380, 150, 50);
        CConfirmButton.setIcon(CConfirmButtonImage);
        CConfirmButton.setFocusable(false);
        CConfirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // TO DO: PUT THE Game Lobby class here
                ProceedGameLobby (CJobClass, CName);
            }
        });
        CCharacterCreationFrame.add (CConfirmButton);
    }
     /**
     * This method is displays back button
     */
    public void displayBackButton () {
        CBackButton.setBounds(230, 450, 150, 50);
        CBackButton.setIcon(CBackButtonImage);
        CBackButton.setFocusable(false);
        CBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // TO DO: PUT THE title screen class here
                CCharacterCreationFrame.dispose();
                TitleScreen CTitleScreen = new TitleScreen();
                CTitleScreen.openTitleScreen();
            }
        });
        CCharacterCreationFrame.add (CBackButton);
    }
     /**
     * This method display inputs
     */
    public void displayCheckInputButton () {
        CCheckInputButton.setBounds(230, 530, 150, 50);
        CCheckInputButton.setText("Check Input");
        CCheckInputButton.setBackground(Color.BLACK);
        CCheckInputButton.setForeground (Color.YELLOW);
        CCheckInputButton.setFocusable(false);
        CCheckInputButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CCheckInputButton.setFocusable(false);
        CCheckInputButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              displayName();
              displayJobClassName();
              displayLevel();
              displayJobClassStats();
            }
        });
        CCharacterCreationFrame.add (CCheckInputButton);
    }
     /**
     * This method is displays name
     */
    public void displayName (){
        CNameLabel.setText("Name: " + CName.getName());
        CNameLabel.setHorizontalAlignment(JLabel.CENTER);
        CNameLabel.setVerticalAlignment(JLabel.BOTTOM);
        CNameLabel.setBounds(60, 440, 300, 200);
        CNameLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CNameLabel.setForeground(Color.WHITE);
        CCharacterCreationFrame.add ( CNameLabel);
    }
     /**
     * This method is displays jobclass name
     */
    public void displayJobClassName (){
        CJobClassNameLabel.setText("JobClass: " + CJobClass.getJobClassName());
        CJobClassNameLabel.setHorizontalAlignment(JLabel.CENTER);
        CJobClassNameLabel.setVerticalAlignment(JLabel.BOTTOM);
        CJobClassNameLabel.setBounds(60, 460, 300, 200);
        CJobClassNameLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CJobClassNameLabel.setForeground(Color.WHITE);
        CCharacterCreationFrame.add (CJobClassNameLabel);
    }
     /**
     * This method is displays level
     */
    public void displayLevel (){
        CLevelLabel.setText ("Level: " + CJobClass.getLevel());
        CLevelLabel.setHorizontalAlignment(JLabel.CENTER);
        CLevelLabel.setVerticalAlignment(JLabel.BOTTOM);
        CLevelLabel.setBounds(100, 480, 200, 200);
        CLevelLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CLevelLabel.setForeground(Color.WHITE);
        CCharacterCreationFrame.add (CLevelLabel);
    }
     /**
     * This method is displays jobclass stats
     */
    public void displayJobClassStats (){
        CStatisticsLabel.setText("|HP :" + CJobClass.getHp() + "|DEX: " + CJobClass.getDexterity() + "|INT :" + CJobClass.getIntelligence() 
        + "|END : " + CJobClass.getEndurance() + "|STR :" + CJobClass.getStrength() +  "|FTH : "  + CJobClass.getFaith() + "|");
        CStatisticsLabel.setHorizontalAlignment(JLabel.CENTER);
        CStatisticsLabel.setVerticalAlignment(JLabel.BOTTOM);
        CStatisticsLabel.setBounds(0, 500, 700, 200);
        CStatisticsLabel.setFont(new Font ("Consolas", Font.PLAIN, 15));
        CStatisticsLabel.setForeground(Color.WHITE);
        CCharacterCreationFrame.add (CStatisticsLabel);
    }

     /**
     * This method proceeds game lobby
     */
    public void ProceedGameLobby (JobClasses CJobClass, Name CName){
        if (CName.getName() != "" && CJobClass.getJobClassName() != "")
        {
            CCharacterCreationFrame.dispose ();
            bInputOnce = true; 
            GameLobby CGameLobby = new GameLobby(CName.getName(), CJobClass.getJobClassName(), CJobClass.getLevel(), CJobClass.getRunes(), CJobClass.getHp(), CJobClass.getEndurance(), CJobClass.getDexterity(), CJobClass.getStrength(), CJobClass.getIntelligence(), CJobClass.getFaith()); 
            CGameLobby.openGameLobby();
        }
        else if (CName.getName() == "" && CJobClass.getJobClassName() == "")
        {

            displayEmptyNameAndJobClassPromptFrame();
        }
        else if (CName.getName () == "")
        {
            displayEmptyNamePromptFrame();
        }
        else if (CJobClass.getJobClassName() == "")
        {
            displayEmptyJobClassPromptFrame();
        }
    }
     /**
     * This method displays Empty name and jobclass prompt frame
     */
    public void displayEmptyNameAndJobClassPromptFrame (){
        CInvalidPromptFrame.setSize (600, 300);
        CInvalidPromptFrame.setTitle("Invalid Prompt");
        CInvalidPromptFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CInvalidPromptFrame.getContentPane().setBackground(Color.BLACK);
        displayEmptyNameAndJobClassPrompt (); 
        CInvalidPromptFrame.setVisible(true);
    }
     /**
     * This method displays Empty name and jobclass prompt label
     */
    public void displayEmptyNameAndJobClassPrompt (){
        CInvalidPromptLabel.setText("PLEASE ENTER NAME AND JOBCLASS !");
        CInvalidPromptLabel.setHorizontalAlignment(JLabel.CENTER);
        CInvalidPromptLabel.setVerticalTextPosition(JLabel.TOP);
        CInvalidPromptLabel.setForeground(Color.WHITE);
        CInvalidPromptLabel.setFont (new Font ("Impact", Font.PLAIN, 20));
        CInvalidPromptBackButton.setBounds(200, 200, 150, 50);
        CInvalidPromptBackButton.setIcon(CBackButtonImage);
        CInvalidPromptBackButton.setFocusable(false);
        CInvalidPromptBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CInvalidPromptFrame.dispose();
            }
        });
        CInvalidPromptFrame.add (CInvalidPromptBackButton);
        CInvalidPromptFrame.add (CInvalidPromptLabel);
    }
    /**
     * This method displays empty jobclass frame
     */
    public void displayEmptyJobClassPromptFrame (){
        CInvalidPromptFrame.setSize (600, 300);
        CInvalidPromptFrame.setTitle("Invalid Prompt");
        CInvalidPromptFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CInvalidPromptFrame.getContentPane().setBackground(Color.BLACK);
        displayEmptyJobClassPrompt (); 
        CInvalidPromptFrame.setVisible(true);
    }
     /**
     * This method displays empty name frame
     */
    public void displayEmptyNamePromptFrame (){
        CInvalidPromptFrame.setSize (600, 300);
        CInvalidPromptFrame.setTitle("Invalid Prompt");
        CInvalidPromptFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CInvalidPromptFrame.getContentPane().setBackground(Color.BLACK);
        displayEmptyNamePrompt();  
        CInvalidPromptFrame.setVisible(true);
    }
     /**
     * This method displays empty name prompt
     */
    public void displayEmptyNamePrompt (){
        CInvalidPromptLabel.setText("PLEASE ENTER NAME !");
        CInvalidPromptLabel.setHorizontalAlignment(JLabel.CENTER);
        CInvalidPromptLabel.setVerticalTextPosition(JLabel.TOP);
        CInvalidPromptLabel.setForeground(Color.WHITE);
        CInvalidPromptLabel.setFont (new Font ("Impact", Font.PLAIN, 20));
        CInvalidPromptBackButton.setBounds(200, 200, 150, 50);
        CInvalidPromptBackButton.setIcon(CBackButtonImage);
        CInvalidPromptBackButton.setFocusable(false);
        CInvalidPromptBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CInvalidPromptFrame.dispose();
            }
        });
        CInvalidPromptFrame.add (CInvalidPromptBackButton);
        CInvalidPromptFrame.add (CInvalidPromptLabel);
    }
     /**
     * This method displays empty jobclass prompt
     */
    public void displayEmptyJobClassPrompt (){
        CInvalidPromptLabel.setText("PLEASE SELECT JOB CLASS !");
        CInvalidPromptLabel.setHorizontalAlignment(JLabel.CENTER);
        CInvalidPromptLabel.setVerticalTextPosition(JLabel.TOP);
        CInvalidPromptLabel.setForeground(Color.WHITE);
        CInvalidPromptLabel.setFont (new Font ("Impact", Font.PLAIN, 20));
        CInvalidPromptBackButton.setBounds(200, 200, 150, 50);
        CInvalidPromptBackButton.setIcon(CBackButtonImage);
        CInvalidPromptBackButton.setFocusable(false);
        CInvalidPromptBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CInvalidPromptFrame.dispose();
            }
        });
        CInvalidPromptFrame.add (CInvalidPromptBackButton);
        CInvalidPromptFrame.add (CInvalidPromptLabel);
    }
}
