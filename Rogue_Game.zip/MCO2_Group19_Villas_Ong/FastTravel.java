import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/** 
 * This class is the fast travel class
 * 
 * @author  Daniel Ryan Baysa Ong
 * @author Gabriel N. Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class FastTravel {
    /** 
    * This field is for frame
    */
    private JFrame CFastTravelFrame;
    /** 
    * This field is for frame
    */
    private JFrame CLockedFrame;
    /** 
    * This field is for the button
    */
    private JButton CStormveilCastleButton; 
    /** 
    * This field is for the button
    */
    private JButton CRayaLucariaAcademyButton;
    /** 
    * This field is for the button
    */
    private JButton CTheEldenThroneButton; 
    /** 
    * This field is for the button
    */
    private JButton CBackButton; 
    /** 
    * This field is for the image
    */
    private ImageIcon CStormveilCastleButtonImage; 
    /** 
    * This field is for the image
    */
    private ImageIcon CRayaLucariaAcademyButtonImage;
     /** 
    * This field is for the image
    */
    private ImageIcon CTheEldenThroneButtonImage; 
     /** 
    * This field is for the image
    */
    private ImageIcon CBackButtonImage; 
     /** 
    * This field is for the label
    */
    private JLabel CLockedLabel; 
    /** 
    * This field is for the name
    */
    private String strName;
    /** 
    * This field is for the level
    */
    private int nLevel; 
    /** 
    * This field is for the hp
    */
    private int nPlayerHp;
    /** 
    * This field is for the dexterity
    */
    private int nPlayerDex;
    /** 
    * This field is for the intllegence
    */
    private int nPlayerInt;
    /** 
    * This field is for the endurance
    */
    private int nPlayerEnd;
    /** 
    * This field is for the strength
    */
    private int nPlayerStr;
    /** 
    * This field is for the faith
    */
    private int nPlayerFth;
    /** 
    * This field is for the hp
    */
    private int nWeaponHp;
    /** 
    * This field is for the dexteirty
    */
    private int nWeaponDex;
    /** 
    * This field is for the intellegecne
    */
    private int nWeaponInt;
    /** 
    * This field is for the endurance
    */
    private int nWeaponEnd;
    /** 
    * This field is for the  strength 
    */
    private int nWeaponStr;
    /** 
    * This field is for the faith
    */
    private int nWeaponFth;
    /** 
    * This field is for the runes
    */
    private int nRunes; 
      /** 
     * This constructor is for the fast travel
     * @param nAreaIndex for area index
     * @param strName for the name
     * @param nLevel for the level
     * @param nRunes for the runes
     * @param nPlayerHp for the player hp
     * @param nPlayerDex for the player dexterity 
     * @param nPlayerInt for the Player intelligence
     * @param nPlayerEnd for the player Endurance
     * @param nPlayerStr for the player strength
     * @param nPlayerFth for the player faith
     * @param nWeaponHp for the weapon hp
     * @param nWeaponDex for the weapon dexterity
     * @param nWeaponInt for the weapon intellgence
     * @param nWeaponEnd for the weapon endurance
     * @param nWeaponStr for the weapon strength 
     * @param nWeaponFth for the weapon faith
     */
    public FastTravel (String strName, int nLevel, int nPlayerHp, int nPlayerDex, int nPlayerInt, int nPlayerEnd, int nPlayerStr, int nPlayerFth, int nWeaponHp, int nWeaponDex, int nWeaponInt, int nWeaponEnd, int nWeaponStr, int nWeaponFth){
        this.CFastTravelFrame = new JFrame(); 
        this.CStormveilCastleButton = new JButton ();
        this.CStormveilCastleButtonImage = new ImageIcon("StormveilCastle.png");
        this.CRayaLucariaAcademyButton = new JButton();
        this.CRayaLucariaAcademyButtonImage = new ImageIcon("RayaLucariaAcademy.png"); 
        this.CTheEldenThroneButton = new JButton();
        this.CTheEldenThroneButtonImage = new ImageIcon("TheEldenThrone.png"); 
        this.CBackButton = new JButton(); 
        this.CBackButtonImage = new ImageIcon("Back.png");
        this.CLockedFrame = new JFrame();
        this.CLockedLabel = new JLabel();
        this.strName = strName;
        this.nLevel = nLevel;
        this.nPlayerHp = nPlayerHp;
        this.nPlayerDex = nPlayerDex;
        this.nPlayerInt = nPlayerInt;
        this.nPlayerEnd = nPlayerEnd;
        this.nPlayerStr = nPlayerStr;
        this.nPlayerFth = nPlayerFth;
        this.nWeaponHp = nWeaponHp;
        this.nWeaponDex = nWeaponDex;
        this.nWeaponInt= nWeaponInt;
        this.nWeaponEnd = nWeaponEnd;
        this.nWeaponStr = nWeaponStr;
        this.nWeaponFth = nWeaponFth;
    }
    /** 
    * This method opens fast travel
    */
    public void openFastTravel (){
        displayFastTravelFrame();
        displayStormVeilCastleButton();
        displayRayaLucariaAcademyButton();
        displayTheEldenThroneButton();
        displayBackButton();
        CFastTravelFrame.setVisible(true);
    }
    /** 
    * This method displays fast travel frame
    */
    public void displayFastTravelFrame (){
        CFastTravelFrame.setSize (600, 600);
        CFastTravelFrame.setTitle("Fast Travel Menu");
        CFastTravelFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CFastTravelFrame.setLayout(null);
        CFastTravelFrame.getContentPane().setBackground(Color.BLACK);
    }
    /** 
    * This method displays button
    */
    public void displayStormVeilCastleButton (){
        CStormveilCastleButton.setBounds(150, 100, 280, 100);
        CStormveilCastleButton.setIcon(CStormveilCastleButtonImage);
        CStormveilCastleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AreaOne CAreaOne = new AreaOne(1, strName, nLevel, nRunes, nPlayerHp, nPlayerDex, nPlayerInt, nPlayerEnd, nPlayerStr, nPlayerFth, nWeaponHp, nWeaponDex, nWeaponInt, nWeaponEnd, nWeaponStr, nWeaponFth);
                CAreaOne.openAreaOneFloorOne(495, 435);
                CFastTravelFrame.dispose();
            }
        });
        CFastTravelFrame.add (CStormveilCastleButton);
    }
    /** 
    * This method displays button
    */
    public void displayRayaLucariaAcademyButton (){
        CRayaLucariaAcademyButton.setBounds(150, 200, 280, 100);
        CRayaLucariaAcademyButton.setIcon(CRayaLucariaAcademyButtonImage);
        CRayaLucariaAcademyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AreaTwo CAreaTwo = new AreaTwo(1, strName, nLevel, nRunes, nPlayerHp, nPlayerDex, nPlayerInt, nPlayerEnd, nPlayerStr, nPlayerFth, nWeaponHp, nWeaponDex, nWeaponInt, nWeaponEnd, nWeaponStr, nWeaponFth);
                //AreaTwo CAreaTwo = new AreaTwo (1, "Donielle", 1, 100, 15, 13, 9, 11, 14, 9, 0, 13, 15, 15, 15, 15);
                CAreaTwo.openAreaTwo (495, 193);
                CFastTravelFrame.dispose();
            }
        });
        CFastTravelFrame.add (CRayaLucariaAcademyButton);
    }
    /** 
    * This method displays button
    */
    public void displayTheEldenThroneButton (){
        CTheEldenThroneButton.setBounds(150, 300, 280, 100);
        CTheEldenThroneButton.setIcon(CTheEldenThroneButtonImage);
        CTheEldenThroneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              displayLockedFrame();
            }
        });
        CFastTravelFrame.add (CTheEldenThroneButton);
    }
    /** 
    * This method displays button
    */
    public void displayBackButton () {
        CBackButton.setBounds(150, 450, 150, 50);
        CBackButton.setIcon(CBackButtonImage);
        CBackButton.setFocusable(false);
        CBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CFastTravelFrame.dispose();
            }
        });
        CFastTravelFrame.add (CBackButton);
    }
    /** 
    * This method displays frame
    */
    public void displayLockedFrame ()
    {
        CLockedFrame.setSize (500, 300);
        CLockedFrame.setTitle("Locked Frame");
        CLockedFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        CLockedFrame.setLayout(null);
        CLockedFrame.getContentPane().setBackground(Color.BLACK);
        displayLockedLabel();
        CLockedFrame.setVisible(true);

    }
    /** 
    * This method displays label
    */
    public void displayLockedLabel ()
    {
        CLockedLabel.setText("AREA THREE IS LOCKED !");
        CLockedLabel.setForeground (Color.RED);
        CLockedLabel.setFont (new Font ("Impact", Font.PLAIN, 20));
        CLockedLabel.setBounds(100, 100, 100, 100);
        CLockedLabel.setVerticalAlignment(JLabel.TOP);
        CLockedLabel.setHorizontalAlignment(JLabel.CENTER);
        CLockedLabel.setBounds(50, 50, 500, 400);
        CLockedFrame.add(CLockedLabel);
    }
}
