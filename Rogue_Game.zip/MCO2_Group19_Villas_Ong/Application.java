/** 
 * This is the class where the application will run
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class Application {
    // Constructors
    /** 
     * This field is for the title screen
     */
    private TitleScreen CTitleScreen;
    /** 
     * This constructor is for the application 
     */
    public Application (){
        this.CTitleScreen = new TitleScreen();
    }
    /** 
     * This method runs the whole application
     */
    public void runApplication (){
      
        CTitleScreen.openTitleScreen();
    }
}
