import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
/** 
 * This class creates character of the user
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class JobClasses {
    // GUI Fields
      /** 
     * This field is for the frame
     */
    private JFrame  CJobClassFrame; 
      /** 
     * This field is for the button
     */
    private JButton CVagabondButton;
     /** 
     * This field is for the button
     */
    private JButton CSamuraiButton;
     /** 
     * This field is for the button
     */
    private JButton CWarriorButton;
     /** 
     * This field is for the button
     */
    private JButton CHeroButton;
     /** 
     * This field is for the button
     */
    private JButton CAstrologerButton;
     /** 
     * This field is for the button
     */
    private JButton CProphetButton;
     /** 
     * This field is for the image
     */
    private ImageIcon CVagabondButtonImage;
     /** 
     * This field is for the image
     */
    private ImageIcon CSamuraiButtonImage; 
     /** 
     * This field is for the image
     */
    private ImageIcon CWarriorButtonImage;
     /** 
     * This field is for the image
     */
    private ImageIcon CHeroButtonImage;
     /** 
     * This field is for the image
     */
    private ImageIcon CAstrologerButtonImage;
     /** 
     * This field is for the image
     */
    private ImageIcon CProphetButtonImage;
    // Fields
     /** 
     * This field is for name
     */
    protected String strName;
     /** 
     * This field is for the level
     */
    protected int nLevel; 
     /** 
     * This field is for the runes
     */
    protected int nRunes; 
    /** 
     * This field is for the hp
     */
    protected int nHp; 
    /** 
     * This field is for the dexterity
     */
    protected int nDexterity;
    /** 
     * This field is for the intellgence
     */
    protected int nIntelligence; 
    /** 
     * This field is for the endurance
     */
    protected int nEndurance; 
    /** 
     * This field is for the strength
     */
    protected int nStrength; 
    /** 
     * This field is for the faith
     */
    protected int nFaith; 
    /** 
     * This constructor is for the jobclass
     */
    public JobClasses (){
        this.CJobClassFrame = new JFrame(); 
        this.CVagabondButton = new JButton();
        this.CSamuraiButton = new JButton();
        this.CWarriorButton = new JButton();
        this.CHeroButton = new JButton();
        this.CAstrologerButton = new JButton();
        this.CProphetButton = new JButton();
        this.CVagabondButtonImage = new ImageIcon("Vagabond.png");
        this.CSamuraiButtonImage = new ImageIcon("Samurai.png"); 
        this.CWarriorButtonImage = new ImageIcon("Warrior.png"); 
        this.CHeroButtonImage = new ImageIcon ("Hero.png");
        this.CAstrologerButtonImage = new ImageIcon ("Astrologer.png");
        this.CProphetButtonImage = new ImageIcon ("Prophet.png");
        this.strName = ""; 
        this.nLevel = 0;
        this.nRunes = 0;
        this.nHp = 0;
        this.nDexterity = 0;
        this.nIntelligence = 0;
        this.nEndurance = 0;
        this.nStrength = 0;
        this.nFaith = 0;
    }
    /** 
     * This method opens jobclass
     */
    public void openJobClass (){
        
        
        displayJobClassFrame();
        displayVagabondButton (); 
        displaySamuraiButton();
        displayWarriorButton();
        displayHeroButton();
        displayAstrologerButton();
        displayProphetButton();
        CJobClassFrame.setVisible(true);
    }
    /** 
     * This method displays frame
     */
    public void displayJobClassFrame (){
        CJobClassFrame.setSize (1000, 500);
        CJobClassFrame.setTitle("Job Class");
        CJobClassFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CJobClassFrame.getContentPane().setBackground(Color.BLACK);
        CJobClassFrame.setLayout(new GridLayout(1,6, 10, 10));
    }

     /** 
     * This method displays button
     */
    public void displayVagabondButton (){
        CVagabondButton.setBounds(100, 300, 50, 150);
        CVagabondButton.setIcon(CVagabondButtonImage);
        CVagabondButton.setFocusable(false);
        CVagabondButton.setBackground (Color.BLACK);
        CVagabondButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            strName = "Vagabond"; 
            nLevel = 9; 
            nHp = 15;
            nDexterity = 13;
            nIntelligence = 9;
            nEndurance = 11;
            nStrength = 14;
            nFaith = 9;
            CJobClassFrame.dispose();
            }
        });
        CJobClassFrame.add (CVagabondButton);
    }
    /** 
     * This method displays button
     */
    public void displaySamuraiButton (){
        CSamuraiButton.setBounds(300, 300, 50, 150);
        CSamuraiButton.setIcon(CSamuraiButtonImage);
        CSamuraiButton.setFocusable(false);
        CSamuraiButton.setBackground (Color.BLACK);
        CSamuraiButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                strName = "Samurai"; 
                nLevel = 9; 
                nHp = 12;
                nDexterity = 15;
                nIntelligence = 9;
                nEndurance = 13;
                nStrength = 12;
                nFaith = 8;
                CJobClassFrame.dispose();
            }
        });
        CJobClassFrame.add (CSamuraiButton);

    }
    /** 
     * This method displays button
     */
    public void displayWarriorButton (){
        CWarriorButton.setBounds(300, 300, 50, 150);
        CWarriorButton.setIcon(CWarriorButtonImage);
        CWarriorButton.setFocusable(false);
        CWarriorButton.setBackground (Color.BLACK);
        CWarriorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                strName = "Warrior"; 
                nLevel = 8; 
                nHp = 11;
                nDexterity = 16;
                nIntelligence = 10;
                nEndurance = 13;
                nStrength = 10;
                nFaith = 8;
                CJobClassFrame.dispose();
            }
        });
        CJobClassFrame.add (CWarriorButton);

    }
    /** 
     * This method displays button
     */
    public void displayHeroButton (){
        CHeroButton.setBounds(300, 300, 50, 150);
        CHeroButton.setIcon(CHeroButtonImage);
        CHeroButton.setFocusable(false);
        CHeroButton.setBackground (Color.BLACK);
        CHeroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                strName = "Hero"; 
                nLevel = 7; 
                nHp = 14;
                nDexterity = 9;
                nIntelligence = 7;
                nEndurance = 12;
                nStrength = 16;
                nFaith = 8;
                CJobClassFrame.dispose();
            }
        });
        CJobClassFrame.add (CHeroButton);
    }
    /** 
     * This method displays button
     */
    public void displayAstrologerButton (){
        CAstrologerButton.setBounds(300, 300, 50, 150);
        CAstrologerButton.setIcon(CAstrologerButtonImage);
        CAstrologerButton.setFocusable(false);
        CAstrologerButton.setBackground (Color.BLACK);
        CAstrologerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                strName = "Astrologer"; 
                nLevel = 6; 
                nHp = 9;
                nDexterity = 12;
                nIntelligence = 16;
                nEndurance = 9;
                nStrength = 8;
                nFaith = 7;
                CJobClassFrame.dispose();
            }
        });
        CJobClassFrame.add (CAstrologerButton);
    }
    /** 
     * This method displays button
     */
    public void displayProphetButton (){
        CProphetButton.setBounds(300, 300, 50, 150);
        CProphetButton.setIcon(CProphetButtonImage);
        CProphetButton.setFocusable(false);
        CProphetButton.setBackground (Color.BLACK);
        CProphetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                strName = "Prophet"; 
                nLevel = 7; 
                nHp = 10;
                nDexterity = 10;
                nIntelligence = 7;
                nEndurance = 8;
                nStrength = 11;
                nFaith = 16;
                CJobClassFrame.dispose();
            }
        });
        CJobClassFrame.add (CProphetButton);
    }

    // Setters
    /** 
     * This method is the setter
     * @param nLevel level of player
     */
    public void setLevel (int nLevel){
        this.nLevel = nLevel;
    }
    /** 
     * This method is the setter
     * @param nHp of the player
     */
    public void setHp (int nHp){
        this.nHp = nHp;
    }
    /** 
     * This method is the setter
     * @param nDexterity for the dexterity
     */
    public void setDexterity (int nDexterity){
        this.nDexterity = nDexterity;
    }
    /** 
     * This method is the setter
     * @param nIntellegence for the intelligence
     */
    public void setIntelligence (int nIntelligence){
        this.nIntelligence = nIntelligence;
    }
    /** 
     * This method is the setter
     * @param nEndurance is for the endurance
     */
    public void setEndurance (int nEndurance){
        this.nEndurance = nEndurance;
    }
    /** 
     * This method is the setter
     * @param nStrength is for the strength
     */
    public void setStrength (int nStrength){
        this.nStrength = nStrength;
    }
    /** 
     * This method is the setter
     * @param nFaith is for the faith
     */
    public void setFaith (int nFaith){
        this.nFaith = nFaith;
    }
    /** 
     * This method is the setter
     * @param nRunes is for the runes
     */
    public void setRunes (int nRunes){
        this.nRunes = nRunes;
    }
// Getters
    /** 
     * This method is the getter
     */
    public String getJobClassName (){
        return strName;
    }
    /** 
     * This method is the getter
     */
    public int getLevel (){
        return nLevel; 
    }
    /** 
     * This method is the getter
     */
    public int getHp (){
        return nHp;
    }
    /** 
     * This method is the getter
     */
    public int getDexterity (){
        return nDexterity;
    }
    /** 
     * This method is the getter
     */
    public int getIntelligence(){
        return nIntelligence;
    }
    /** 
     * This method is the getter
     */
    public int getEndurance (){
        return nEndurance;
    }
    /** 
     * This method is the getter
     */
    public int getStrength (){
        return nStrength;
    }
    /** 
     * This method is the getter
     */
    public int getFaith (){
        return nFaith;
    }
    /** 
     * This method is the getter
     */
    public int getRunes (){
        return nRunes;  
    }

}
