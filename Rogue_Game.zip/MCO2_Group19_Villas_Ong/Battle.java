
import java.awt.Color;
import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
public class Battle {
    /**
     * This field is for the spawn tile frame
     */
    private JFrame CSpawnTileFrame;
    /**
     * This field for the results frame
     */
    private JFrame CResultFrame;
    /**
     * This field for the dodge frame
     */
    private JFrame CDodgeFrame;
       /**
     * This field for the godrickgrafted label
     */
    private JLabel CGodrickTheGraftedLabel;
    /**
     * This field for the Renala Queen Of The Full Moon Label
     */
    private JLabel CRenalaQueenOfTheFullMoonLabel;
    /**
     * This field for the the elden beast label
     */
    private JLabel CTheEldenBeastLabel;
    /**
     * This field for the label
     */
    private JLabel CRunesGainedLabel;
    /**
     * This field for the label
     */
    private JLabel CPlayerWinEnemyLabel;
    /**
     * This field for the label
     */
    private JLabel CPlayerWinBossLabel;
    /**
     * This field for the label
     */
    private JLabel CPlayerDiesLabel;
    /**
     * This field for the label
     */
    private JLabel CGodrickSoldierLabel;
    /**
     * This field for the label
     */
    private JLabel CGodrickArcherLabel;
    /**
     * This field for the label
     */
    private JLabel CGodrickKnightLabel;
    /**
     * This field for the label
     */
    private JLabel CLivingJarLabel;
    /**
     * This field for the label
     */
    private JLabel CGlinstoneSorcererLabel;
    /**
     * This field for the label
     */
    private JLabel CBattleMageLabel;
    /**
     * This field for the label
     */
    private JLabel CPlayerNameLabel;
    /**
     * This field for the label
     */
    private JLabel CPlayerHealthValueLabel;
    /**
     * This field for the label
     */
    private JLabel CPlayerSpriteLabel;
    /**
     * This field for the label
     */
    private JLabel CEnemyNameLabel;
    /**
     * This field for the label
     */
    private JLabel CEnemyHealthValueLabel;
    /**
     * This field for the label
     */
    private JLabel CIncomingEnemyDamageLabel;
    /**
     * This field for the label
     */
    private JLabel CDogdeSuccessLabel;
    /**
     * This field for the label
     */
    private JLabel CDodgeFailedLabel;
    /**
     * This field for the label
     */
    private ImageIcon CGodrickSoldierImage;
    /**
     * This field for the Image
     */
    private ImageIcon CGodrickArcherImage;
    /**
     * This field for the Image
     */
    private ImageIcon CGodrickKnightImage;
    /**
     * This field for the Image
     */
    private ImageIcon CGodrickTheGraftedImage;
    /**
     * This field for the Image
     */
    private ImageIcon CRenalaQueenOfTheFullMoonImage;
    /**
     * This field for the Image
     */
    private ImageIcon CLivingJarImage;
    /**
     * This field for the Image
     */
    private ImageIcon CGlinstoneSorcererImage;
    /**
     * This field for the Image
     */
    private ImageIcon CBattleMageImage;
    /**
     * This field for the Image
     */
    private ImageIcon CTheEldenBeastImage;
    /**
     * This field for the button
     */
    private JButton CResultBackButton;
    /**
     * This field for the button
     */
    private JButton CPlayerDeathBackButton;
    /**
     * This field for the button
     */
    private JButton CAttackButton;
    /**
     * This field for the button
     */
    private JButton CDodgeButton;
    /**
     * This field for the button
     */
    private JButton CPhysicalButton;
    /**
     * This field for the button
     */
    private JButton CSorceryButton;
    /**
     * This field for the button
     */
    private JButton CIncantationButton;
    /**
     * This field for the Image
     */
    private ImageIcon CPlayerImage;
    /**
     * This field for the health
     */
    private int nHealth;
    /**
     * This field for the attack
     */
    private int nPlayerAttack;
    /**
     * This field for the attack
     */
    private int nEnemyAttack;
    /**
     * This field for the area index
     */
    private int nAreaIndex;
    /**
     * This field for the enemy class
     */
    private Enemy CEnemy;
    /**
     * This field for the player class
     */
    private Player CPlayer;
    /**
     * This field for the spawn enemy min
     */
    private int nSpawnEnemyMinNum;
     /**
     * This field for the spawn enemy max
     */
    private int nSpawnEnemyMaxNum;
     /**
     * This field for the spawn rand num
     */
    private int nSpawnEnemyRandNum;
     /**
     * This field for the player turn
     */
    private boolean bPlayerTurn;
     /**
     * This field for the player dodge
     */
    private boolean bPlayerDodge;
     /**
     * This field for the enemy
     */
    private boolean bEnemy;
     /**
     * This field for the runes
     */
    private int nRunes;
     /**
     * This field for the level
     */
    protected int nLevel;
     /**
     * This field for the player dodge
     */
    /**
     * This field is for the player hp
     */
    protected int nPlayerHp;
     /**
     * This field is for the player dexterity
     */
    protected int nPlayerDex;
     /**
     * This field is for the player intelligence
     */
    protected int nPlayerInt;
     /**
     * This field is for the player endurance
     */
    protected int nPlayerEnd;
     /**
     * This field is for the strength
     */
    protected int nPlayerStr;
     /**
     * This field is for the player faith
     */
    protected int nPlayerFth;
     /**
     * This field is for the weapon hp
     */
    protected int nWeaponHp;
     /**
     * This field is for the weapon dexterity
     */
    protected int nWeaponDex;
     /**
     * This field is for the weapon intelligence
     */
    protected int nWeaponInt;
     /**
     * This field is for the weapon endurance
     */
    protected int nWeaponEnd;
     /**
     * This field is for the weapon strength
     */
    protected int nWeaponStr;
     /**
     * This field is for the weapon faith
     */
    protected int nWeaponFth;
    /**
     * This constructor is for the battle
     */

    public Battle ()
    {

    }
     /**
     * This constructor is for the battle
     * @param nAreaIndex for area index
     * @param strName for the name
     * @param nLevel for the level
     * @param nRunes for the runes
     * @param nPlayerHp for the player hp
     * @param nPlayerDex for the player dexterity
     * @param nPlayerInt for the Player intelligence
     * @param nPlayerEnd for the player Endurance
     * @param nPlayerStr for the player strength
     * @param nPlayerFth for the player faith
     * @param nWeaponHp for the weapon hp
     * @param nWeaponDex for the weapon dexterity
     * @param nWeaponInt for the weapon intellgence
     * @param nWeaponEnd for the weapon endurance
     * @param nWeaponStr for the weapon strength
     * @param nWeaponFth for the weapon faith
     */
    
    public Battle (int nAreaIndex, String strName, int nRunes, int nPlayerHp, int nPlayerDex, int nPlayerInt, int nPlayerEnd, int nPlayerStr, int nPlayerFth, int nWeaponHp, int nWeaponDex, int nWeaponInt, int nWeaponEnd,int nWeaponStr, int nWeaponFth)
    {
        this.CEnemy = new Enemy();
        this.nAreaIndex = nAreaIndex;
        this.CSpawnTileFrame = new JFrame();
        this.CPlayerWinBossLabel = new JLabel();
        this.CPlayerWinEnemyLabel = new JLabel();
        this.CRunesGainedLabel = new JLabel();
        this.CPlayerDiesLabel = new JLabel ();
        this.CResultBackButton = new JButton();
        this.CDodgeFrame = new JFrame();
        this.CSpawnTileFrame = new JFrame();
        this.CResultFrame = new JFrame();
        this.CDogdeSuccessLabel = new JLabel();
        this.CDodgeFailedLabel = new JLabel();
        this.CPlayerNameLabel = new JLabel();
        this.CPlayerHealthValueLabel = new JLabel(); 
        this.CPlayerSpriteLabel = new JLabel();
        this.CEnemyNameLabel = new JLabel(); 
        this.CEnemyHealthValueLabel = new JLabel();
        this.CAttackButton = new JButton();
        this.CDodgeButton = new JButton(); 
        this.CAttackButton = new JButton();
        this.CPhysicalButton = new JButton();
        this.CSorceryButton = new JButton(); 
        this.CIncantationButton = new JButton();
        this.CPlayerDeathBackButton = new JButton();
        this.CIncomingEnemyDamageLabel = new JLabel();
        this.CPlayerImage = new ImageIcon("Player.png");
        this.nPlayerHp = nPlayerHp;
        this.nPlayerDex = nPlayerDex;
        this.nPlayerInt = nPlayerInt;
        this.nPlayerEnd = nPlayerEnd;
        this.nPlayerStr = nPlayerStr;
        this.nPlayerFth = nPlayerFth;
        this.nWeaponHp = nWeaponHp;
        this.nWeaponDex = nWeaponDex;
        this.nWeaponInt= nWeaponInt;
        this.nWeaponEnd = nWeaponEnd;
        this.nWeaponStr = nWeaponStr;
        this.nWeaponFth = nWeaponFth;
        this.CPlayer = new Player(strName, nPlayerEnd, nWeaponEnd,nPlayerHp, nWeaponHp, nPlayerStr, nWeaponStr, nPlayerInt, nWeaponInt, nPlayerFth, nWeaponFth, nRunes);
        this.nHealth = 0;
        this.nPlayerAttack = 0;
        this.nEnemyAttack = 0;
        this.nAreaIndex = nAreaIndex; 
        this.bPlayerTurn = true; 
        this.bPlayerDodge = false;
        this.CGodrickTheGraftedImage = new ImageIcon("GodrickTheGrafted.png");
        this.CRenalaQueenOfTheFullMoonImage = new ImageIcon("RenalaQueenOfTheFullMoon.png");
        this.CTheEldenBeastImage = new ImageIcon("TheEldenBeast.PNG");
        this.CGodrickTheGraftedLabel = new JLabel();
        this.CRenalaQueenOfTheFullMoonLabel = new JLabel();
        this.CTheEldenBeastLabel = new JLabel();
        this.bEnemy = false;
        this.CPlayerNameLabel = new JLabel();
    }
     /**
     * This constructor is for the area one
     * @param Enemy for the enemy class
     * @param nSpawnEnemyMinNum for min num
     * @param nSpawnEnemyRandNum for the spawn enemy rand num
     * @param nAreaIndex for area index
     * @param strName for the name
     * @param nLevel for the level
     * @param nRunes for the runes
     * @param nPlayerHp for the player hp
     * @param nPlayerDex for the player dexterity
     * @param nPlayerInt for the Player intelligence
     * @param nPlayerEnd for the player Endurance
     * @param nPlayerStr for the player strength
     * @param nPlayerFth for the player faith
     * @param nWeaponHp for the weapon hp
     * @param nWeaponDex for the weapon dexterity
     * @param nWeaponInt for the weapon intellgence
     * @param nWeaponEnd for the weapon endurance
     * @param nWeaponStr for the weapon strength
     * @param nWeaponFth for the weapon faith
     */

    public Battle (Enemy CEnemy, int nSpawnEnemyMinNum, int nSpawnEnemyMaxNum, int nSpawnEnemyRandNum, int nAreaIndex, String strName, int nRunes, int nPlayerHp, int nPlayerDex, int nPlayerInt, int nPlayerEnd, int nPlayerStr, int nPlayerFth, int nWeaponHp, int nWeaponDex, int nWeaponInt, int nWeaponEnd,int nWeaponStr, int nWeaponFth)
    {
    this.nPlayerHp = nPlayerHp;
    this.nPlayerDex = nPlayerDex;
    this.nPlayerInt = nPlayerInt;
    this.nPlayerEnd = nPlayerEnd;
    this.nPlayerStr = nPlayerStr;
    this.nPlayerFth = nPlayerFth;
    this.nWeaponHp = nWeaponHp;
    this.nWeaponDex = nWeaponDex;
    this.nWeaponInt= nWeaponInt;
    this.nWeaponEnd = nWeaponEnd;
    this.nWeaponStr = nWeaponStr;
    this.nWeaponFth = nWeaponFth;
    this.CPlayerWinEnemyLabel = new JLabel();
    this.CEnemy = new Enemy(); 
    // Spawn Random Enimies monster
    this.nSpawnEnemyMinNum = nSpawnEnemyMinNum;
    this.nSpawnEnemyMaxNum = nSpawnEnemyMaxNum;
    this.nSpawnEnemyRandNum = nSpawnEnemyRandNum;
    // for runes
    this.CRunesGainedLabel = new JLabel();
    this.CPlayerDiesLabel = new JLabel ();
    this.CResultBackButton = new JButton();
    this.CDodgeFrame = new JFrame();
    this.CSpawnTileFrame = new JFrame();
    this.CResultFrame = new JFrame();
    this.CDogdeSuccessLabel = new JLabel();
    this.CDodgeFailedLabel = new JLabel();
    this.CPlayerWinEnemyLabel = new JLabel();
    // Area One Enemies
    this.CGodrickArcherLabel = new JLabel();
    this.CGodrickSoldierLabel = new JLabel();
    this.CGodrickKnightLabel = new JLabel ();
    // Player Information Labels
    this.CPlayerNameLabel = new JLabel();
    this.CPlayerHealthValueLabel = new JLabel(); 
    this.CPlayerSpriteLabel = new JLabel();
    // Enemy Lables
    this.CEnemyNameLabel = new JLabel(); 
    this.CEnemyHealthValueLabel = new JLabel();
    this.CIncomingEnemyDamageLabel = new JLabel();
    this.CLivingJarLabel = new JLabel();
    this.CGlinstoneSorcererLabel = new JLabel();
    this.CBattleMageLabel = new JLabel();
    // Enemy Images
    this.CGodrickSoldierImage = new ImageIcon("GodrickSoldier.png");
    this.CGodrickArcherImage = new ImageIcon("GodrickArcher.png");
    this.CGodrickKnightImage = new ImageIcon("GodrickKnight.png");
    this.CLivingJarImage = new ImageIcon("LivingJar.png");
    this.CBattleMageImage = new ImageIcon("BattleMage.png");
    this.CGlinstoneSorcererImage = new ImageIcon("GlinstoneSorcerer.png");
    // Player Image
    this.CPlayerImage = new ImageIcon("Player.png");
    // PLayer Buttons
    this.CAttackButton = new JButton();
    this.CDodgeButton = new JButton(); 
    this.CAttackButton = new JButton();
    this.CPhysicalButton = new JButton();
    this.CSorceryButton = new JButton(); 
    this.CIncantationButton = new JButton();
    this.CPlayer = new Player(strName, nPlayerEnd, nWeaponEnd,nPlayerHp, nWeaponHp, nPlayerStr, nWeaponStr, nPlayerInt, nWeaponInt, nPlayerFth, nWeaponFth, nRunes);
    this.nHealth = 0;
    this.nPlayerAttack = 0;
    this.nEnemyAttack = 0;
    this.nAreaIndex = nAreaIndex; 
    this.bPlayerTurn = true; 
    this.bPlayerDodge = false;
    this.bEnemy = true;
    this.CPlayerDeathBackButton = new JButton();
    }

    /**
     * This method is for opens enemy battle
     */
    public void OpenEnemyBattle (){

        openEnemySpawnFrame();
        CPlayer.setPlayerMaxHealth (computePlayerHealth(CPlayer.getPlayerHealth(), CPlayer.getWeaponHealth()));
        // Player Turn
        displayPlayerInformation();
        
        // Enemys Turn
        spawnEnemy(CEnemy, nSpawnEnemyMinNum, nSpawnEnemyRandNum, nSpawnEnemyMaxNum);
        CSpawnTileFrame.setVisible(true); 
    }
    /**
     * This method opens boss battle
     */
    public void openBossBattle ()
     {
        CSpawnTileFrame = new JFrame();
        openEnemySpawnFrame();
        // TO DO :  PICTURE ENEMY
        CPlayer.setPlayerMaxHealth (computePlayerHealth(CPlayer.getPlayerHealth(), CPlayer.getWeaponHealth()));
        displayPlayerInformation();
        spawnBoss(CEnemy);
        CSpawnTileFrame.setVisible(true); 
     }
    
    /**
     * displays enemySpawn Fram
     */
     public void openEnemySpawnFrame (){
        CSpawnTileFrame.setSize (1300, 700);
        CSpawnTileFrame.setTitle("Spawn Tile");
        CSpawnTileFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CSpawnTileFrame.setLayout(null);
        CSpawnTileFrame.getContentPane().setBackground(Color.BLACK);
    } 
    /**
     * This method spawns enemy
     */
    public void spawnEnemy (Enemy CEnemy, int nSpawnEnemyMinNum, int nSpawnEnemyRandNum, int nSpawnEnemyMaxNum){
        nSpawnEnemyRandNum = (int) Math.floor (Math.random() * (nSpawnEnemyMaxNum - nSpawnEnemyMinNum + 1) + nSpawnEnemyMinNum); 
        displayEnemyImages(nSpawnEnemyRandNum, nAreaIndex);
        CEnemy.setEnemyStats(nSpawnEnemyRandNum, nAreaIndex);
        nHealth = (int) Math.floor (Math.random() * (CEnemy.getHealthHigh() - CEnemy.getHealthLow() + 1 ) + CEnemy.getHealthLow());
        nEnemyAttack = (int) Math.floor (Math.random() * (CEnemy.getAttackHigh() - CEnemy.getAttackLow() + 1) + CEnemy.getAttackLow());
        CEnemy.setEnemyHealth(computeHealth (nHealth, nAreaIndex));
        CEnemy.setPreviousEnemyHealth(computeHealth (nHealth, nAreaIndex));
        CEnemy.setAttack(computeAttack(nEnemyAttack, nAreaIndex)); 
        displayEnemyInformation(CEnemy.getEnemyName(), CEnemy.getEnemyHealth());
        // displayEnemySpawnTileBackButton();
    }
    /**
     * This method  spawns boss
     */
    public void spawnBoss (Enemy CEnemy) {
        int nDamage;

        CEnemy.setBossStats(nAreaIndex);
        CEnemy.setPreviousEnemyHealth (CEnemy.getEnemyHealth());
        CEnemy.setEnemyHealth(CEnemy.getEnemyHealth());
        nDamage = (int) Math.floor (Math.random() * (CEnemy.getDamageHigh() - CEnemy.getDamageLow() + 1 ) + CEnemy.getDamageLow());
        CEnemy.setAttack(nDamage);
         displayBossImages(nAreaIndex);
        displayEnemyInformation(CEnemy.getBossName(), CEnemy.getEnemyHealth());

    }
    /**
     * This method displays Enemy Image
     */
    public void displayEnemyImages (int nSpawnEnemy, int nAreaIndex)
    {
       
        if (nAreaIndex == 1)
        {
            System.out.println ("Picture:" + nSpawnEnemy);
            switch (nSpawnEnemy)
            {
                case 1:
                displayGodrickSoldier();
                break;
                case 2:
                displayGodrickArcher();
                break;
                case 3:
                displayGodrickKnight();
                break;
            }
        }
        else if (nAreaIndex == 2)
        {
            switch (nSpawnEnemy)
            {
                case 1:
                displayLivingJar();
                break;
                case 2:
                displayGlinstoneSorcerer();
                break;
                case 3:
                displayBattleMage();
                break;
              
            }
        }
    
        
    }
    /**
     * This method displays boss image
     */
    public void displayBossImages (int nAreaIndex)
    {
        switch (nAreaIndex)
        {
            case 1: 
            displayGodrickTheGraftedBoss();
            break;
            case 2:
            displayRenalaQueenOfTheFullMoonBoss();
            break;
            case 3:
            displayTheEldenBeastBoss();
            break;
        }
    }
    /**
     * This method displays enemy info
     */
    public void displayEnemyInformation (String strEnemy, int nEnemyHealth){
            displayEnemyName(strEnemy);
            displayEnemyHealthValue(nEnemyHealth);
            displayIncomingEnemyDamage();

    }

    /**
     * This method displays enemy name
     */
    public void displayEnemyName(String strEnemy){
      
        CEnemyNameLabel.setText("Enemy [" + strEnemy + "]");
        CEnemyNameLabel.setHorizontalAlignment(JLabel.CENTER);
        CEnemyNameLabel.setVerticalAlignment(JLabel.BOTTOM);
        CEnemyNameLabel.setBounds(800, 300, 500, 200);
        CEnemyNameLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CEnemyNameLabel.setForeground(Color.WHITE);
        CSpawnTileFrame.add (CEnemyNameLabel);   
    }
    /**
     * This method displays enemy health value
     */
    public void displayEnemyHealthValue (int nEnemyHealth){
        CEnemyHealthValueLabel.setText("Health [" + nEnemyHealth + "]");
        CEnemyHealthValueLabel.setHorizontalAlignment(JLabel.CENTER);
        CEnemyHealthValueLabel.setVerticalAlignment(JLabel.BOTTOM);
        CEnemyHealthValueLabel.setBounds(800, 350, 300, 200);
        CEnemyHealthValueLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CEnemyHealthValueLabel.setForeground(Color.WHITE);
        CSpawnTileFrame.add ( CEnemyHealthValueLabel);   
    }
    /**
     * This method displays incoming enemy damage
     */
    public void displayIncomingEnemyDamage (){
        CIncomingEnemyDamageLabel.setText("Incoming Enemy Damage : " + CEnemy.getEnemyAttack() + " !");
        CIncomingEnemyDamageLabel.setHorizontalAlignment(JLabel.CENTER);
        CIncomingEnemyDamageLabel.setVerticalAlignment(JLabel.BOTTOM);
        CIncomingEnemyDamageLabel.setBounds(800, 400, 500, 200);
        CIncomingEnemyDamageLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CIncomingEnemyDamageLabel.setForeground(Color.WHITE);
        CSpawnTileFrame.add (CIncomingEnemyDamageLabel);
   }
   /**
     * This method displays dodge success
     */
    public void displayDodgeSuccess ()
    {   
        CDogdeSuccessLabel.setText("DODGE SUCCESS !");
        CDogdeSuccessLabel.setHorizontalAlignment(JLabel.CENTER);
        CDogdeSuccessLabel.setVerticalAlignment(JLabel.BOTTOM);
        CDogdeSuccessLabel.setBounds(200, 50, 300, 200);
        CDogdeSuccessLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CDogdeSuccessLabel.setForeground(Color.GREEN);
        CDodgeFrame.add (CDogdeSuccessLabel);   
    }
    /**
     * This method displays dodge failed
     */
    public void displayDodgeFailed ()
    {
        CDodgeFailedLabel.setText("DODGE FAILED !");
        CDodgeFailedLabel.setHorizontalAlignment(JLabel.CENTER);
        CDodgeFailedLabel.setVerticalAlignment(JLabel.BOTTOM);
        CDodgeFailedLabel.setBounds(200, 50, 300, 200);
        CDodgeFailedLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CDodgeFailedLabel.setForeground(Color.GREEN);
        CDodgeFrame.add (CDodgeFailedLabel);   
    }
    /**
     * This method displays Dodge frame
     */
    public void displayDodgeFrame ()
    {
        CDodgeFrame.setSize (700, 400);
        CDodgeFrame.setTitle("Dodge");
        CDodgeFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        CDodgeFrame.setLayout(null);
        CDodgeFrame.getContentPane().setBackground(Color.BLACK);
    }
    /**
     * This method displays enemy turn
     */
    public void displayEnemyTurn (){
        if (bPlayerDodge == false)
        {
            CPlayer.setPlayerMaxHealth (subtractHealth(CPlayer.getPlayerMaxHealth(), CEnemy.getEnemyAttack()));
            // Checks negative Player health
            checkNegativePlayerHealth (CPlayer.getPlayerMaxHealth());
            bPlayerTurn = true;
            displayPlayerInformation();
        }
        else if (bPlayerDodge == true)
        {
           if (checkDodge(randomizeDodgeValue(), computeDodgeRate(CPlayer.getPlayerEndurance (), CPlayer.getWeaponEndurance())) == true)
           {
            //Dodge Success
            displayDodgeFrame();
            displayDodgeSuccess();
            CDodgeFrame.setVisible(true);
            bPlayerDodge = false;
           }
           else // if (checkDodge(randomizeDodgeValue(), computeDodgeRate(CPlayer.getPlayerEndurance (), CPlayer.getWeaponEndurance())) == false)
           {
             // Dodge Failed
             displayDodgeFrame();
             displayDodgeFailed();
             CPlayer.setPlayerMaxHealth(subtractHealth(CPlayer.getPlayerMaxHealth(), CEnemy.getEnemyAttack())); 
             checkNegativePlayerHealth(CPlayer.getPlayerMaxHealth());
             displayPlayerInformation();
             bPlayerDodge = false;
             CDodgeFrame.setVisible(true);
           }
        }
    }
    /**
     * This method displays player information
     */
    public void displayPlayerInformation (){
        displayPlayerName();
        displayPlayerHealthValue();
        displayPlayerSprite();
        disableButtons(bPlayerTurn);
    }
    /**
     * This method disables buttons
     */
    public void disableButtons (boolean bPlayerTurn) {
        if (bPlayerTurn == true)
        {
            displayAttackButton();
            displayDodgeButton();
            CAttackButton.setVisible(true);
            CPhysicalButton.setVisible(true);
            CSorceryButton.setVisible(true);
            CIncantationButton.setVisible(true);
            CDodgeButton.setVisible(true);
        }
        else
        {
            CAttackButton.setVisible(false);
            CPhysicalButton.setVisible(false);
            CSorceryButton.setVisible(false);
            CIncantationButton.setVisible(false);
            CDodgeButton.setVisible(false);
        }
    }
   /**
     * This method displays name
     */
    public void displayPlayerName (){
        CPlayerNameLabel.setText("Player Name [" + CPlayer.getPlayerName() + "]");
        CPlayerNameLabel.setHorizontalAlignment(JLabel.CENTER);
        CPlayerNameLabel.setVerticalAlignment(JLabel.BOTTOM);
        CPlayerNameLabel.setBounds(100, 300, 300, 200);
        CPlayerNameLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CPlayerNameLabel.setForeground(Color.WHITE);
        CSpawnTileFrame.add (CPlayerNameLabel);  
    }
    /**
     * This method displays health value
     */
    public void displayPlayerHealthValue (){
        CPlayerHealthValueLabel.setText("Health [" + CPlayer.getPlayerMaxHealth() + "]");
        CPlayerHealthValueLabel.setHorizontalAlignment(JLabel.CENTER);
        CPlayerHealthValueLabel.setVerticalAlignment(JLabel.BOTTOM);
        CPlayerHealthValueLabel.setBounds(100, 350, 300, 200);
        CPlayerHealthValueLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CPlayerHealthValueLabel.setForeground(Color.WHITE);
        CSpawnTileFrame.add (CPlayerHealthValueLabel);  
    }
    /**
     * This method player sprite
     */
    public void displayPlayerSprite (){
        CPlayerSpriteLabel.setIcon(CPlayerImage);
        CPlayerSpriteLabel.setVerticalAlignment(JLabel.TOP);
        CPlayerSpriteLabel.setHorizontalAlignment(JLabel.CENTER);
        CPlayerSpriteLabel.setBounds(10,50, 550, 400);
        CSpawnTileFrame.add(CPlayerSpriteLabel);
    }
    /**
     * This method displays enemy
     */
    public void displayGodrickSoldier (){
        CGodrickSoldierLabel.setIcon(CGodrickSoldierImage);
        CGodrickSoldierLabel.setVerticalAlignment(JLabel.TOP);
        CGodrickSoldierLabel.setHorizontalAlignment(JLabel.CENTER);
        CGodrickSoldierLabel.setBounds(700,100, 550, 400);
        CSpawnTileFrame.add(CGodrickSoldierLabel);
    }
     /**
     * This method displays enemy
     */
    public void displayGodrickArcher (){
        CGodrickArcherLabel.setIcon(CGodrickArcherImage);
        CGodrickArcherLabel.setVerticalAlignment(JLabel.TOP);
        CGodrickArcherLabel.setHorizontalAlignment(JLabel.CENTER);
        CGodrickArcherLabel.setBounds(700,100, 550, 400);
        CSpawnTileFrame.add( CGodrickArcherLabel);
    }
     /**
     * This method displays enemy
     */
    public void displayGodrickKnight (){
        CGodrickKnightLabel.setIcon(CGodrickKnightImage);
        CGodrickKnightLabel.setVerticalAlignment(JLabel.TOP);
        CGodrickKnightLabel.setHorizontalAlignment(JLabel.CENTER);
        CGodrickKnightLabel.setBounds(700,100, 550, 400);
        CSpawnTileFrame.add( CGodrickKnightLabel);
    }
     /**
     * This method displays enemy
     */
    public void displayGodrickTheGraftedBoss ()
    {
        CGodrickTheGraftedLabel.setIcon(CGodrickTheGraftedImage);
        CGodrickTheGraftedLabel.setVerticalAlignment(JLabel.TOP);
        CGodrickTheGraftedLabel.setHorizontalAlignment(JLabel.CENTER);
        CGodrickTheGraftedLabel.setBounds(700,100, 550, 400);
        CSpawnTileFrame.add( CGodrickTheGraftedLabel);
    }
     /**
     * This method displays enemy
     */
    public void displayRenalaQueenOfTheFullMoonBoss ()
    {
        CRenalaQueenOfTheFullMoonLabel.setIcon(CRenalaQueenOfTheFullMoonImage);
        CRenalaQueenOfTheFullMoonLabel.setVerticalAlignment(JLabel.TOP);
        CRenalaQueenOfTheFullMoonLabel.setHorizontalAlignment(JLabel.CENTER);
        CRenalaQueenOfTheFullMoonLabel.setBounds(700,100, 550, 400);
        CSpawnTileFrame.add(CRenalaQueenOfTheFullMoonLabel);
    }
     /**
     * This method displays enemy
     */
    public void displayTheEldenBeastBoss ()
    {
        CTheEldenBeastLabel.setIcon(CTheEldenBeastImage);
        CTheEldenBeastLabel.setVerticalAlignment(JLabel.TOP);
        CTheEldenBeastLabel.setHorizontalAlignment(JLabel.CENTER);
        CTheEldenBeastLabel.setBounds(700,100, 550, 400);
        CSpawnTileFrame.add(CTheEldenBeastLabel);
    }
     /**
     * This method displays enemy
     */
    public void displayLivingJar ()
    {
        CLivingJarLabel.setIcon(CLivingJarImage);
        CLivingJarLabel.setVerticalAlignment(JLabel.TOP);
        CLivingJarLabel.setHorizontalAlignment(JLabel.CENTER);
        CLivingJarLabel.setBounds(700,100, 550, 400);
        CSpawnTileFrame.add( CLivingJarLabel);
    }
     /**
     * This method displays enemy
     */
    public void displayGlinstoneSorcerer (){
        CGlinstoneSorcererLabel.setIcon(CGlinstoneSorcererImage);
        CGlinstoneSorcererLabel.setVerticalAlignment(JLabel.TOP);
        CGlinstoneSorcererLabel.setHorizontalAlignment(JLabel.CENTER);
        CGlinstoneSorcererLabel.setBounds(700,100, 550, 400);
        CSpawnTileFrame.add(CGlinstoneSorcererLabel);
    }
     /**
     * This method displays enemy
     */
    public void displayBattleMage (){
        CBattleMageLabel.setIcon(CBattleMageImage);
        CBattleMageLabel.setVerticalAlignment(JLabel.TOP);
        CBattleMageLabel.setHorizontalAlignment(JLabel.CENTER);
        CBattleMageLabel.setBounds(700,100, 550, 400);
        CSpawnTileFrame.add(CBattleMageLabel);
    }
     /**
     * This method displays button
     */
    public void displayAttackButton (){
        CAttackButton.setBounds(500, 200, 200, 50);
        CAttackButton.setText("Attack");
        CAttackButton.setBackground(Color.BLACK);
        CAttackButton.setForeground (Color.YELLOW);
        CAttackButton.setFocusable(false);
        CAttackButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CAttackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displaySubOptions();
            }
        });
        CSpawnTileFrame.add (CAttackButton);
    }
    /**
     * This method displays button
     */
    public void displaySubOptions (){
        CPhysicalButton.setBounds(500, 250, 200, 50);
        CPhysicalButton.setText("Physical");
        CPhysicalButton.setBackground(Color.BLACK);
        CPhysicalButton.setForeground (Color.WHITE);
        CPhysicalButton.setFocusable(false);
        CPhysicalButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CPhysicalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                  // computes player incantation damage
                  nPlayerAttack = computePhysicalDamage(CPlayer.getPlayerStrength(), CPlayer.getWeaponStrength(), CEnemy.getPhysicalDefense());
                  // subtract Health and sets to enemy health
                  CEnemy.setEnemyHealth(subtractHealth(CEnemy.getEnemyHealth(), nPlayerAttack));
                  // checks negative health of enemy
                  checkNegativeEnemyHealth(CEnemy.getEnemyHealth());
                  // displays enemy Health value
                  displayEnemyHealthValue(CEnemy.getEnemyHealth());
                  // displays player info
                  displayPlayerInformation();
                  // player turns false
                  bPlayerTurn = false;
                  // displays enemy turn
                  displayEnemyTurn();
                  // displays player info
                  displayPlayerInformation();
                  setCurrentPlayerHealth(CPlayer.getPlayerMaxHealth());
                  // checks enemy result
                  if (bEnemy == true)
                  {
                    checkEnemyResult(CEnemy.getEnemyHealth(), CPlayer.getPlayerMaxHealth(), CEnemy.getPreviousEnemyHealth());
                  }
                  else 
                  {
                    checkBossResult(CEnemy.getEnemyHealth(), CPlayer.getPlayerMaxHealth(), CEnemy.getPreviousEnemyHealth());
                  }
                
            }
        });
        CSpawnTileFrame.add (CPhysicalButton);
        CSorceryButton.setBounds(500, 300, 200, 50);
        CSorceryButton.setText("Sorcery");
        CSorceryButton.setBackground(Color.BLACK);
        CSorceryButton.setForeground (Color.WHITE);
        CSorceryButton.setFocusable(false);
        CSorceryButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CSorceryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                   // computes player Sorcery damage
                   nPlayerAttack = computeSorceryDamage(CPlayer.getPlayerIntelligence(), CPlayer.getWeaponIntelligence(), CEnemy.getSorceryDefense());
                   // subtract Health and sets to enemy health
                   CEnemy.setEnemyHealth(subtractHealth(CEnemy.getEnemyHealth(), nPlayerAttack));
                   // checks negative health of enemy
                   checkNegativeEnemyHealth(CEnemy.getEnemyHealth());
                   // displays enemy Health value
                   displayEnemyHealthValue(CEnemy.getEnemyHealth());
                   // displays player info
                   displayPlayerInformation();
                   // player turns false
                   bPlayerTurn = false;
                   // displays enemy turn
                   displayEnemyTurn();
                   // displays player info
                   displayPlayerInformation();
                   setCurrentPlayerHealth(CPlayer.getPlayerMaxHealth());
                   // checks enemy result
                   if (bEnemy == true)
                   {
                     checkEnemyResult(CEnemy.getEnemyHealth(), CPlayer.getPlayerMaxHealth(), CEnemy.getPreviousEnemyHealth());
                   }
                   else 
                   {
                     checkBossResult(CEnemy.getEnemyHealth(), CPlayer.getPlayerMaxHealth(), CEnemy.getPreviousEnemyHealth());
                   }
            }
        });
        CSpawnTileFrame.add (CSorceryButton);
        CIncantationButton.setBounds(500, 350, 200, 50);
        CIncantationButton.setText("Incantation");
        CIncantationButton.setBackground(Color.BLACK);
        CIncantationButton.setForeground (Color.WHITE);
        CIncantationButton.setFocusable(false);
        CIncantationButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CIncantationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // computes player incantation damage
                nPlayerAttack = computeIncantationDamage(CPlayer.getPlayerFaith(), CPlayer.getWeaponFaith(), CEnemy.getIncantationDefense());
                // subtract Health and sets to enemy health
                CEnemy.setEnemyHealth(subtractHealth(CEnemy.getEnemyHealth(), nPlayerAttack));
                // checks negative health of enemy
                checkNegativeEnemyHealth(CEnemy.getEnemyHealth());
                // displays enemy Health value
                displayEnemyHealthValue(CEnemy.getEnemyHealth());
                // displays player info
                displayPlayerInformation();
                // player turns false
                bPlayerTurn = false;
                // displays enemy turn
                displayEnemyTurn();
                // displays player info
                displayPlayerInformation();
                // checks enemy result
                setCurrentPlayerHealth(CPlayer.getPlayerMaxHealth());
                if (bEnemy == true)
                {
                  checkEnemyResult(CEnemy.getEnemyHealth(), CPlayer.getPlayerMaxHealth(), CEnemy.getPreviousEnemyHealth());
                }
                else 
                {
                  checkBossResult(CEnemy.getEnemyHealth(), CPlayer.getPlayerMaxHealth(), CEnemy.getPreviousEnemyHealth());
                }
            }
        });
        CSpawnTileFrame.add (CIncantationButton);
    }
    /**
     * This method displays button
     */
    public void displayDodgeButton () {
        CDodgeButton.setBounds(500, 480, 100, 50);
        CDodgeButton.setText("Dodge");
        CDodgeButton.setBackground(Color.BLACK);
        CDodgeButton.setForeground (Color.YELLOW);
        CDodgeButton.setFocusable(false);
        CDodgeButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CDodgeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                bPlayerDodge = true;
                displayEnemyTurn ();
             
            }
        });
        CSpawnTileFrame.add (CDodgeButton);
    }
    /**
     * This method displays result
     */
    public void displayEnemyResult (int nEnemyHealth)
    {
            CPlayerWinEnemyLabel.setText("ENEMY FELLED");
            CPlayerWinEnemyLabel.setVerticalAlignment(JLabel.BOTTOM);
            CPlayerWinEnemyLabel.setHorizontalAlignment(JLabel.CENTER);
            CPlayerWinEnemyLabel.setFont(new Font ("Consolas", Font.PLAIN, 30));
            CPlayerWinEnemyLabel.setForeground(Color.GREEN);
            CPlayerWinEnemyLabel.setBounds(250, 50, 440, 300);
            CPlayer.setRunes(computeGainedEnemyRunes(nEnemyHealth));
            setRunes(CPlayer.getRunes());
            displayRunesGained(nRunes);
            CResultFrame.add(CPlayerWinEnemyLabel);
    }
    /**
     * This method displays frame
     */
    public void displayResultFrame (){
        CResultFrame.setSize (1000, 700);
        CResultFrame.setTitle("Result");
        CResultFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        CResultFrame.setLayout(null);
        CResultFrame.getContentPane().setBackground(Color.GRAY);
    }
    /**
     * This method checks enemy result
     */
    public void checkEnemyResult (int nEnemyHealth, int nPlayerHealth, int nPreviousEnemyHealth){
        if (nEnemyHealth <= 0)
        {
            displayResultFrame();
            displayEnemyResult(nPreviousEnemyHealth);
            displayResultBackButton();
            CResultFrame.setVisible(true); 
        }   
        else if (nPlayerHealth <= 0)
        {
            displayResultFrame();
            displayDeathResult();
            displayResultBackButton();
            CResultFrame.setVisible(true); 
        }
    }
    /**
     * This method displays runes gained
     */
    public void displayRunesGained (int nRunes)
    {
            CRunesGainedLabel.setText("RUNES GAINED [" + nRunes + "]");
            CRunesGainedLabel.setVerticalAlignment(JLabel.BOTTOM);
            CRunesGainedLabel.setHorizontalAlignment(JLabel.CENTER);
            CRunesGainedLabel.setFont(new Font ("Consolas", Font.PLAIN, 30));
            CRunesGainedLabel.setForeground(Color.GREEN);
            CRunesGainedLabel.setBounds(250, 100, 500, 300);
            CResultFrame.add(CRunesGainedLabel);
    }
    /**
     * This method displays boss result
     */
    public void displayBossResult (int nPreviousEnemyHealth)
    {
            CPlayerWinBossLabel.setText("GREAT ENEMY FELLED");
            CPlayerWinBossLabel.setVerticalAlignment(JLabel.BOTTOM);
            CPlayerWinBossLabel.setHorizontalAlignment(JLabel.CENTER);
            CPlayerWinBossLabel.setFont(new Font ("Consolas", Font.PLAIN, 30));
            CPlayerWinBossLabel.setForeground(Color.GREEN);
            CPlayerWinBossLabel.setBounds(250, 50, 440, 300);
            CPlayer.setRunes (computeGainedBossRunes(nPreviousEnemyHealth));
            setRunes(CPlayer.getRunes());
            displayRunesGained(nRunes);
            CResultFrame.add(CPlayerWinBossLabel);
    }
    /**
     * This method checks boss results
     */
    public void checkBossResult (int nBossHealth, int nPlayerHealth, int nPreviousEnemyHealth){
        if (nBossHealth <= 0)
        {
            displayResultFrame();
            displayBossResult(nPreviousEnemyHealth);
            displayResultBackButton();
            CResultFrame.setVisible(true);
        }
        else if (nPlayerHealth <= 0)
        {
            displayResultFrame();
            displayDeathResult();
            displayPlayerDeathBackButton();
            CResultFrame.setVisible(true);
        }
    }
    /**
     * This method displays death result
     */
    public void displayDeathResult (){
        CPlayer.setRunes(0);
        CPlayerDiesLabel.setText("YOU DIED !");
        CPlayerDiesLabel.setVerticalAlignment(JLabel.BOTTOM);
        CPlayerDiesLabel.setHorizontalAlignment(JLabel.CENTER);
        CPlayerDiesLabel.setFont(new Font ("Consolas", Font.PLAIN, 30));
        CPlayerDiesLabel.setForeground(Color.GREEN);
        CPlayerDiesLabel.setBounds(250, 50, 440, 300);
        CResultFrame.add(CPlayerDiesLabel);
    }
    /**
     * This method displays button
     */
    public void displayResultBackButton ()
    {
        CResultBackButton.setBounds(600, 600, 100, 50);
        CResultBackButton.setText("Back");
        CResultBackButton.setBackground(Color.BLACK);
        CResultBackButton.setForeground (Color.YELLOW);
        CResultBackButton.setFocusable(false);
        CResultBackButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CResultBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               CSpawnTileFrame.dispose();
               CResultFrame.dispose ();
            }
        });
        CResultFrame.add ( CResultBackButton);
    }
    /**
     * This method displays button
     */
    public void displayPlayerDeathBackButton ()
    {
        CPlayerDeathBackButton.setBounds(600, 600, 150, 50);
        CPlayerDeathBackButton.setText("Continue");
        CPlayerDeathBackButton.setBackground(Color.BLACK);
        CPlayerDeathBackButton.setForeground (Color.YELLOW);
        CPlayerDeathBackButton.setFocusable(false);
        CPlayerDeathBackButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CPlayerDeathBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               CSpawnTileFrame.dispose();
               CResultFrame.dispose();
               GameLobby CGameLobby = new GameLobby();
               CGameLobby.openGameLobby();
            }
        });
        CResultFrame.add ( CPlayerDeathBackButton);
    }
    /**
     * This method  computes
     */
    public int computeHealth (int num, int index){
        return num * index;
    }
    /**
     * This method  computes
     */
    public int computeAttack (int num, int index){
        return num * index; 
    }
    /**
     * This method  computes
     */
    public int computeDamage (int num, int index){
        return num * index;
    }
    /**
     * This method computes
     */
    public int computePlayerHealth (int nStatHealth, int nWeaponHealth){
        return (int) (100 * ((nStatHealth + nWeaponHealth)/2));
    }
    /**
     * This method  computes
     */
    public int computePhysicalDamage (int nStatStrength, int nWeaponStrength, double dIncantationDefense){
        return  (int) ((nStatStrength + nWeaponStrength) * (1 - dIncantationDefense));
    }
    /**
     * This method  computes
     */
    public int computeSorceryDamage (int nStatIntellegence, int nWeaponIntelligence, double dIncantationDefense){
        return (int) ((nStatIntellegence + nWeaponIntelligence) * (1 - dIncantationDefense));
    }
    /**
     * This method displays computes
     */
    public int computeIncantationDamage (int nStatFaith , int nWeaponFaith, double dIncantationDefense){
        return  (int) ((nStatFaith + nWeaponFaith) *  (1 - dIncantationDefense));
    }
    /**
     * This method computes
     */
    public float computeDodgeRate (int nStatEndurance, int nWeaponEndurance){
        return  (float) (20 + ((nStatEndurance + nWeaponEndurance)/ 2)) / 100;
    }
    /**
     * This method  checks
     */
    public void checkNegativeEnemyHealth (int nEnemyHealth)
    {
        if (nEnemyHealth < 0 )
        {
            CEnemy.setEnemyHealth(0);
        }
    }
    /**
     * This method displays checks
     */
    public void checkNegativePlayerHealth (int nPlayerHealth) {
        if (nPlayerHealth < 0)
        {
            CPlayer.setPlayerMaxHealth(0);
        }
    }
    /**
     * This method randomizes
     */
    public float randomizeDodgeValue ()
    {
        int nMinDodgeVal = 1;
        int nMaxDodgeVal = 100;
        int nDodgeVal; 
        nDodgeVal = (int) Math.floor (Math.random() * (nMaxDodgeVal - nMinDodgeVal + 1) + nMinDodgeVal);
        return (float) nDodgeVal / 100;
    }
    /**
     * This method subtracts health
     */
     public int subtractHealth (int nPlayerHealth, int nEnemyAttack)
     {
        return nPlayerHealth - nEnemyAttack;
    }
    /**
     * This method checks dodge
     */
    public boolean checkDodge (float fDodgeVal, float fDodgeRate)
    {
        System.out.println ("Dodge Rate :" + fDodgeRate); 
        System.out.println ("Doge Value :" + fDodgeVal);
        if (fDodgeVal <= fDodgeRate)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    /**
     * This method  computes
     */
    public int computeGainedEnemyRunes (int nEnemyHealth)
    {
        return nEnemyHealth * 2;
    }
    /**
     * This method  computes
     */
    public int computeGainedBossRunes (int nBossHealth)
    {
        return nBossHealth * 5; 
    }
    /**
     * This method computes
     */
    public void setCurrentPlayerHealth (int nHealth){
        this.nHealth = nHealth;
    }
    /**
     * This method computes
     */
    public int getCurrentPlayerHealth ()
    {
        return nHealth;
    }
    /**
     * This method  computes
     */
    public void setRunes (int nRunes)
    {
        this.nRunes = nRunes;
    }
    /**
     * This method  computes
     */
    public int getRunes ()
    {
        return nRunes; 
    }
}