import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/** 
 * This is the Level Up class
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class LevelUp extends JobClasses{
    /** 
     * This field is for the frame
     */
    private JFrame CLevelUpFrame;
    /** 
     * This field is for the frame
     */
    private JFrame CMaxLevelPromptFrame;
    /** 
     * This field is for the frame
     */
    private JFrame CInsufficientRunesPromptFrame;
    /** 
     * This field is for the button
     */
    private JButton CLevelHealthButton; 
     /** 
     * This field is for the button
     */
    private JButton CLevelEnduranceButton;
     /** 
     * This field is for the button
     */
    private JButton CLevelDexterityButton;
     /** 
     * This field is for the button
     */
    private JButton CLevelStrengthButton;
     /** 
     * This field is for the button
     */
    private JButton CLevelIntelligenceButton;
     /** 
     * This field is for the button
     */
    private JButton CLevelFaithButton;
     /** 
     * This field is for the button
     */
    private JButton CBackButton;
     /** 
     * This field is for the button
     */
    private JButton CMaxLevelBackButton;
     /** 
     * This field is for the button
     */
    private JButton CInsufficientRunesBackButton;
     /** 
     * This field is for the image
     */
    private ImageIcon CLevelUpTitleImage;
     /** 
     * This field is for the label
     */
    private JLabel CMaxLevelPromptLabel;
     /** 
     * This field is for the label
     */
    private JLabel CInsufficientRunesPromptLabel;
     /** 
     * This field is for the label
     */
    private JLabel CLevelUpLabel; 
     /** 
     * This field is for the label
     */
    private JLabel CRuneCostLabel;
     /** 
     * This field is for the label
     */
    private JLabel CRunesLabel;
     /** 
     * This field is for the label
     */
    private JLabel CHealthLabel;
     /** 
     * This field is for the label
     */
    private JLabel CEnduranceLabel;
     /** 
     * This field is for the label
     */
    private JLabel CDexterityLabel;
     /** 
     * This field is for the label
     */
    private JLabel CStrengthLabel;
     /** 
     * This field is for the label
     */
    private JLabel CIntelligenceLabel;
     /** 
     * This field is for the label
     */
    private JLabel CFaithLabel;
     /** 
     * This field is for the runecosy
     */
    private int nRuneCost;
     /** 
     * This constructor is for the level up
     * @param nRunes is for the runes
     * @param nLevel is for the level
     * @param nHp is for the hp
     * @param nEndruance is for the endurance
     * @param nDexterity is for the dexterity
     * @param nStrength is for the strength
     * @param nIntelligence is for the intelligence
     * @param nFaith is for the faith
     */
    public LevelUp (int nRunes, int nLevel, int nHp,  int nEndurance, int nDexterity, int nStrength, int nIntelligence, int nFaith){
        // GUI Fields 
        this.CLevelUpFrame = new JFrame();
        this.CMaxLevelPromptFrame = new JFrame();
        this.CMaxLevelPromptLabel = new JLabel ();
        this.CInsufficientRunesPromptFrame = new JFrame();
        this.CInsufficientRunesPromptLabel = new JLabel();
        this.CLevelHealthButton = new JButton (); 
        this.CLevelEnduranceButton = new JButton();
        this.CLevelDexterityButton = new JButton();
        this.CLevelStrengthButton = new JButton();
        this.CLevelIntelligenceButton = new JButton ();
        this.CLevelFaithButton = new JButton();
        this.CBackButton = new JButton ();
        this.CMaxLevelBackButton = new JButton ();
        this.CInsufficientRunesBackButton = new JButton();
        this.CLevelUpLabel = new JLabel(); 
        this.CLevelUpTitleImage = new ImageIcon("LevelUpTitle.png");
        this.CRuneCostLabel = new JLabel();
        this.CRunesLabel = new JLabel();
        this.CHealthLabel = new JLabel();
        this.CEnduranceLabel = new JLabel();
        this.CDexterityLabel = new JLabel();
        this.CStrengthLabel = new JLabel ();
        this.CIntelligenceLabel = new JLabel();
        this.CFaithLabel = new JLabel();
        this.nRunes = nRunes;
        this.nLevel = nLevel;
        this.nHp = nHp;
        this.nEndurance = nEndurance;
        this.nDexterity = nDexterity;
        this.nStrength = nStrength;
        this.nIntelligence = nIntelligence;
        this.nFaith = nFaith;
    }
     /** 
     * This method opens level up
     */
        public void openLevelUp (){
            
                displayLevelHealthButton();
                displayLevelEnduranceButton();
                displayLevelDexterityButton();
                displayLevelStrengthButton();
                displayLevelIntelligenceButton();
                displayFaithButton();
                displayBackButton();
                displayPlayerStatistics();
                displayLevelUpTitle();
                displayLevelUpFrame();
           
            CLevelUpFrame.setVisible (true); 
        }
    /** 
     * This method displays frame
     */
        public void displayLevelUpFrame (){
            CLevelUpFrame.setSize (1000, 700);
            CLevelUpFrame.setTitle("Level Up Menu");
            CLevelUpFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            CLevelUpFrame.setLayout(null);
            CLevelUpFrame.getContentPane().setBackground(Color.BLACK);
        }
        /** 
     * This method displays level up title
     */
        public void displayLevelUpTitle ()
        {
            CLevelUpLabel.setIcon(CLevelUpTitleImage);
            CLevelUpLabel.setVerticalAlignment(JLabel.TOP);
            CLevelUpLabel.setHorizontalAlignment(JLabel.CENTER);
            CLevelUpLabel.setBounds(100,0, 400, 400);
            CLevelUpFrame.add(CLevelUpLabel);
        }
        /** 
     * This method displays button
     */
        public void displayLevelHealthButton (){
            CLevelHealthButton.setBounds(200, 200, 200, 50);
            CLevelHealthButton.setText("Level Health");
            CLevelHealthButton.setBackground(Color.BLACK);
            CLevelHealthButton.setForeground (Color.YELLOW);
            CLevelHealthButton.setFocusable(false);
            CLevelHealthButton.setFont (new Font ("Caveat", Font.BOLD, 15));
            CLevelHealthButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    nRuneCost = computeLevelUpRuneCost(nLevel);
                    if (checkPlayerStats(nHp) == true && checkRuneCost(nRunes, nRuneCost) == true)
                    {
                        nRunes =  subtractRunes(nRuneCost, nRunes); 
                        nHp +=1;
                        nLevel += 1;
                        displayPlayerStatistics();
                    }
                    else if (checkPlayerStats(nHp) == false)
                    {
                        displayMaxLevelPromptFrame();
                    }
                    else if (checkRuneCost(nRunes, nRuneCost) == false)
                    {
                        displayInsufficientRunesPromptFrame();
                    }
                }
            });
            CLevelUpFrame.add (CLevelHealthButton);
        }
         /** 
     * This method displays button
     */
        public void displayLevelEnduranceButton (){
            CLevelEnduranceButton.setBounds(200, 260, 200, 50);
            CLevelEnduranceButton.setText("Level Endurance");
            CLevelEnduranceButton.setBackground(Color.BLACK);
            CLevelEnduranceButton.setForeground (Color.YELLOW);
            CLevelEnduranceButton.setFocusable(false);
            CLevelEnduranceButton.setFont (new Font ("Caveat", Font.BOLD, 15));
            CLevelEnduranceButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    nRuneCost = computeLevelUpRuneCost(nLevel);
                    if (checkPlayerStats(nEndurance) == true && checkRuneCost(nRunes, nRuneCost) == true)
                    {
                        
                        nEndurance +=1;
                        nLevel += 1;
                        nRunes =  subtractRunes(nRuneCost, nRunes); 
                        displayPlayerStatistics();
                    }
                    else if (checkPlayerStats(nEndurance) == false)
                    {
                        displayMaxLevelPromptFrame();
                    }
                    else if (checkRuneCost(nRunes, nRuneCost) == false)
                    {
                        displayInsufficientRunesPromptFrame();
                    }
                }
            });
            CLevelUpFrame.add (CLevelEnduranceButton);
        }
         /** 
     * This method displays button
     */
        public void displayLevelDexterityButton (){
            CLevelDexterityButton.setBounds(200, 320, 200, 50);
            CLevelDexterityButton.setText("Level Dexterity");
            CLevelDexterityButton.setBackground(Color.BLACK);
            CLevelDexterityButton.setForeground (Color.YELLOW);
            CLevelDexterityButton.setFocusable(false);
            CLevelDexterityButton.setFont (new Font ("Caveat", Font.BOLD, 15));
            CLevelDexterityButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    nRuneCost = computeLevelUpRuneCost(nLevel);
                    if (checkPlayerStats(nDexterity) == true && checkRuneCost(nRunes, nRuneCost) == true)
                    {
                        nDexterity +=1;
                        nLevel += 1;
                        nRunes =  subtractRunes(nRuneCost, nRunes); 
                        displayPlayerStatistics();
                    }
                    else if (checkPlayerStats(nDexterity) == false)
                    {
                        displayMaxLevelPromptFrame();
                    }
                    else if (checkRuneCost(nRunes, nRuneCost) == false)
                    {
                        displayInsufficientRunesPromptFrame();
                    }
                }
            });
            CLevelUpFrame.add (CLevelDexterityButton);
        }
         /** 
         * This method displays button
         */
        public void displayLevelStrengthButton (){
            CLevelStrengthButton.setBounds(200, 380, 200, 50);
            CLevelStrengthButton.setText("Level Strength");
            CLevelStrengthButton.setBackground(Color.BLACK);
            CLevelStrengthButton.setForeground (Color.YELLOW);
            CLevelStrengthButton.setFocusable(false);
            CLevelStrengthButton.setFont (new Font ("Caveat", Font.BOLD, 15));
            CLevelStrengthButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    nRuneCost = computeLevelUpRuneCost(nLevel);
                    if (checkPlayerStats(nStrength) == true && checkRuneCost(nRunes, nRuneCost) == true)
                    {
                        nStrength +=1;
                        nLevel += 1;
                        nRunes =  subtractRunes(nRuneCost, nRunes); 
                        displayPlayerStatistics();
                    }
                    else if (checkPlayerStats(nStrength) == false)
                    {
                        displayMaxLevelPromptFrame();
                    }
                    else if (checkRuneCost(nRunes, nRuneCost) == false)
                    {
                        displayInsufficientRunesPromptFrame();
                    }
                }
            });
            CLevelUpFrame.add (CLevelStrengthButton);
        }
        /** 
         * This method displays button
         */
        public void displayLevelIntelligenceButton ()
        {
            CLevelIntelligenceButton.setBounds(200, 440, 200, 50);
            CLevelIntelligenceButton.setText("Level Intelligence");
            CLevelIntelligenceButton.setBackground(Color.BLACK);
            CLevelIntelligenceButton.setForeground (Color.YELLOW);
            CLevelIntelligenceButton.setFocusable(false);
            CLevelIntelligenceButton.setFont (new Font ("Caveat", Font.BOLD, 15));
            CLevelIntelligenceButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    nRuneCost = computeLevelUpRuneCost(nLevel);
                    if (checkPlayerStats(nIntelligence) == true && checkRuneCost(nRunes, nRuneCost) == true)
                    {
                        nIntelligence +=1;
                        nLevel += 1;
                        nRunes =  subtractRunes(nRuneCost, nRunes); 
                        displayPlayerStatistics();
                    }
                    else if (checkPlayerStats(nIntelligence) == false)
                    {
                        displayMaxLevelPromptFrame();
                    }
                    else if (checkRuneCost(nRunes, nRuneCost) == false)
                    {
                        displayInsufficientRunesPromptFrame();
                    }
                }
            });
            CLevelUpFrame.add (CLevelIntelligenceButton);
        }
        /** 
         * This method displays button
         */
        public void displayFaithButton (){
            CLevelFaithButton.setBounds(200, 500, 200, 50);
            CLevelFaithButton.setText("Level Faith");
            CLevelFaithButton.setBackground(Color.BLACK);
            CLevelFaithButton.setForeground (Color.YELLOW);
            CLevelFaithButton.setFocusable(false);
            CLevelFaithButton.setFont (new Font ("Caveat", Font.BOLD, 15));
            CLevelFaithButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    nRuneCost = computeLevelUpRuneCost(nLevel);
                    if (checkPlayerStats(nFaith) == true && checkRuneCost(nRunes, nRuneCost) == true)
                    {
                        nHp +=1;
                        nLevel += 1;
                        nRunes =  subtractRunes(nRuneCost, nRunes); 
                        displayPlayerStatistics();
                    }
                    else if (checkPlayerStats(nFaith) == false)
                    {
                        displayMaxLevelPromptFrame();
                    }
                    else if (checkRuneCost(nRunes, nRuneCost) == false)
                    {
                        displayInsufficientRunesPromptFrame();
                    }
                }
            });
            CLevelUpFrame.add (CLevelFaithButton);
        }
        /** 
         * This method displays button
         */
        public void displayBackButton (){
            CBackButton.setBounds(200, 600, 100, 50);
            CBackButton.setText("Back");
            CBackButton.setBackground(Color.BLACK);
            CBackButton.setForeground (Color.YELLOW);
            CBackButton.setFocusable(false);
            CBackButton.setFont (new Font ("Caveat", Font.BOLD, 15));
            CBackButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CLevelUpFrame.dispose();
                }
            });
            CLevelUpFrame.add (CBackButton);
        }
        public void displayMaxLevelPromptFrame (){
            CMaxLevelPromptFrame.setSize (600, 300);
            CMaxLevelPromptFrame.setTitle("Max Level Prompt");
            CMaxLevelPromptFrame.setLayout(null);
            CMaxLevelPromptFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            CMaxLevelPromptFrame.getContentPane().setBackground(Color.BLACK);
            displayMaxLevelPrompt();
            CMaxLevelPromptFrame.setVisible(true);
        }
        /** 
         * This method displays frame
         */
        public void displayInsufficientRunesPromptFrame (){
            CInsufficientRunesPromptFrame.setSize (600, 300);
            CInsufficientRunesPromptFrame.setTitle("Insufficient Runes Prompt");
            CInsufficientRunesPromptFrame.setLayout(null);
            CInsufficientRunesPromptFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            CInsufficientRunesPromptFrame.getContentPane().setBackground(Color.BLACK);
            displayInsufficientRunesPrompt();
            CInsufficientRunesPromptFrame.setVisible(true);
        }
        /** 
         * This method displays prompt
         */
        public void displayMaxLevelPrompt (){

            CMaxLevelPromptLabel.setText("INVALID : MAX STATISTICS REACHED!");
            CMaxLevelPromptLabel.setHorizontalAlignment(JLabel.CENTER);
            CMaxLevelPromptLabel.setVerticalTextPosition(JLabel.TOP);
            CMaxLevelPromptLabel.setForeground(Color.WHITE);
            CMaxLevelPromptLabel.setFont (new Font ("Impact", Font.PLAIN, 20));
            CMaxLevelPromptLabel.setBounds(200, 100, 300, 50);
            CMaxLevelBackButton.setText("Back");
            CMaxLevelBackButton.setBounds(200,200, 100, 50);
            CMaxLevelBackButton.setFocusable(false);
            CMaxLevelBackButton.setBackground(Color.BLACK);
            CMaxLevelBackButton.setForeground (Color.YELLOW);
            CMaxLevelBackButton.setFont (new Font ("Caveat", Font.BOLD, 15));
            CMaxLevelBackButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CMaxLevelPromptFrame.dispose();
                }
            });
            CMaxLevelPromptFrame.add (CMaxLevelBackButton);
            CMaxLevelPromptFrame.add (CMaxLevelPromptLabel);
        }
        /** 
         * This method displays prompt
         */
        public void displayInsufficientRunesPrompt ()
        {
            CInsufficientRunesPromptLabel.setText("INSUFFICIENT RUNES!");
            CInsufficientRunesPromptLabel.setHorizontalAlignment(JLabel.CENTER);
            CInsufficientRunesPromptLabel.setVerticalTextPosition(JLabel.TOP);
            CInsufficientRunesPromptLabel.setForeground(Color.WHITE);
            CInsufficientRunesPromptLabel.setFont (new Font ("Impact", Font.PLAIN, 20));
            CInsufficientRunesPromptLabel.setBounds(200, 100, 200, 50);
            CInsufficientRunesBackButton.setText("Back");
            CInsufficientRunesBackButton.setBounds(200, 200, 100, 50);
            CInsufficientRunesBackButton.setFocusable(false);
            CInsufficientRunesBackButton.setBackground(Color.BLACK);
            CInsufficientRunesBackButton.setForeground (Color.YELLOW);
            CInsufficientRunesBackButton.setFont (new Font ("Caveat", Font.BOLD, 15));
            CInsufficientRunesBackButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    CInsufficientRunesPromptFrame.dispose();
                }
            });
            CInsufficientRunesPromptFrame.add (CInsufficientRunesBackButton);
            CInsufficientRunesPromptFrame.add (CInsufficientRunesPromptLabel);
        }
        /** 
         * This method displays statistics
         */
        public void displayPlayerStatistics (){
            displayRuneCost();
            displayRunes();
            displayHealth();
            displayEndurance();
            displayDexterity();
            displayStrength();
            displayIntelligence();
            displayFaith();
        }
        /** 
         * This method displays runecost
         */
        public void displayRuneCost (){
            nRuneCost = computeLevelUpRuneCost(nLevel);
            CRuneCostLabel.setText("Rune Cost [" + nRuneCost + "]");
            CRuneCostLabel.setHorizontalAlignment(JLabel.CENTER);
            CRuneCostLabel.setVerticalAlignment(JLabel.BOTTOM);
            CRuneCostLabel.setBounds(500, 100, 300, 200);
            CRuneCostLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
            CRuneCostLabel.setForeground(Color.WHITE);
            CLevelUpFrame.add (CRuneCostLabel);
        }
        /** 
         * This method displays rune
         */
        public void displayRunes (){;
            CRunesLabel.setText("Runes [" + nRunes + "]");
            CRunesLabel.setHorizontalAlignment(JLabel.CENTER);
            CRunesLabel.setVerticalAlignment(JLabel.BOTTOM);
            CRunesLabel.setBounds(500, 120, 300, 200);
            CRunesLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
            CRunesLabel.setForeground(Color.WHITE);
            CLevelUpFrame.add (CRunesLabel);
        }
        /** 
         * This method displays health
         */
        public void displayHealth (){
            CHealthLabel.setText("Health [" + getHp() + "]");
            CHealthLabel.setHorizontalAlignment(JLabel.CENTER);
            CHealthLabel.setVerticalAlignment(JLabel.BOTTOM);
            CHealthLabel.setBounds(500, 140, 300, 200);
            CHealthLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
            CHealthLabel.setForeground(Color.WHITE);
            CLevelUpFrame.add (CHealthLabel);
        }
        /** 
         * This method displays endurance
         */
        public void displayEndurance (){
            CEnduranceLabel.setText("Endurance [" + getEndurance() + "]");
            CEnduranceLabel.setHorizontalAlignment(JLabel.CENTER);
            CEnduranceLabel.setVerticalAlignment(JLabel.BOTTOM);
            CEnduranceLabel.setBounds(500, 160, 300, 200);
            CEnduranceLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
            CEnduranceLabel.setForeground(Color.WHITE);
            CLevelUpFrame.add (CEnduranceLabel);
        }
        /** 
         * This method displays dexterity
         */
        public void displayDexterity (){
            CDexterityLabel.setText("Dexterity [" + getDexterity() + "]");
            CDexterityLabel.setHorizontalAlignment(JLabel.CENTER);
            CDexterityLabel.setVerticalAlignment(JLabel.BOTTOM);
            CDexterityLabel.setBounds(500, 180, 300, 200);
            CDexterityLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
            CDexterityLabel.setForeground(Color.WHITE);
            CLevelUpFrame.add (CDexterityLabel);
        }
        /** 
         * This method displays strength 
         */
        public void displayStrength (){
            CStrengthLabel.setText("Strength [" + getStrength() + "]");
            CStrengthLabel.setHorizontalAlignment(JLabel.CENTER);
            CStrengthLabel.setVerticalAlignment(JLabel.BOTTOM);
            CStrengthLabel.setBounds(500, 200, 300, 200);
            CStrengthLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
            CStrengthLabel.setForeground(Color.WHITE);
            CLevelUpFrame.add (CStrengthLabel);
        }
        /** 
         * This method displays intelligence
         */
        public void displayIntelligence (){
            CIntelligenceLabel.setText("Intelligence [" + getIntelligence() + "]");
            CIntelligenceLabel.setHorizontalAlignment(JLabel.CENTER);
            CIntelligenceLabel.setVerticalAlignment(JLabel.BOTTOM);
            CIntelligenceLabel.setBounds(500, 220, 300, 200);
            CIntelligenceLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
            CIntelligenceLabel.setForeground(Color.WHITE);
            CLevelUpFrame.add (CIntelligenceLabel);
        }
        /** 
         * This method displays faith
         */
        public void displayFaith (){
            CFaithLabel.setText("Faith [" + getIntelligence() + "]");
            CFaithLabel.setHorizontalAlignment(JLabel.CENTER);
            CFaithLabel.setVerticalAlignment(JLabel.BOTTOM);
            CFaithLabel.setBounds(500, 240, 300, 200);
            CFaithLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
            CFaithLabel.setForeground(Color.WHITE);
            CLevelUpFrame.add (CFaithLabel);
        }
        /** 
         * This method computes runecost
         */
        public int computeLevelUpRuneCost (int nLevel){
            return (int) (nLevel * 100) / 2;
        }
        /** 
         * This method checks rune cost
         */
        public boolean checkRuneCost (int nRunes, int nRuneCost)
        {
            if (nRunes >= nRuneCost)
            {
                return true;
            }
            else 
            {
                return false; 
            }
        }   
        /** 
         * This method subtracts runes cost
         */
        public int subtractRunes (int nRuneCost, int nRunes)
        {
            return nRuneCost = nRunes - nRuneCost;
        }
        /** 
         * This method checks player stats
         */
        public boolean checkPlayerStats (int nStat){
            if (nStat < 50)
            {
                return true;
            }
            else {
                return false; 
            }
        }

}
