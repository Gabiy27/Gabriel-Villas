import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
/** 
 * This is the Area two
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class AreaTwo extends AreaOne{
    /** 
     * This field is for Area two floor four frame
     */
    private JFrame CAreaTwoFloorFourFrame;
     /** 
     * This field is for Area two floor five frame
     */
    private JFrame CAreaTwoFloorFiveFrame;
     /** 
     * This field is for Area two floor four label
     */
    private JLabel CAreaTwoFloorFourLabel;
    /** 
     * This field is for Area two floor five label
     */
    private JLabel CAreaTwoFloorFiveLabel;
    /** 
     * This field is for Area two floor four image
     */
    private ImageIcon CAreaTwoFloorFourImage;
    /** 
     * This field is for Area two floor five image
     */
    private ImageIcon CAreaTwoFloorFiveImage;
    /** 
     * This field is for the tiles class
     */
    private Tiles CTiles;
      /** 
     * This constructor is for the area one
     * @param nAreaIndex for area index
     * @param strName for the name
     * @param nLevel for the level
     * @param nRunes for the runes
     * @param nPlayerHp for the player hp
     * @param nPlayerDex for the player dexterity 
     * @param nPlayerInt for the Player intelligence
     * @param nPlayerEnd for the player Endurance
     * @param nPlayerStr for the player strength
     * @param nPlayerFth for the player faith
     * @param nWeaponHp for the weapon hp
     * @param nWeaponDex for the weapon dexterity
     * @param nWeaponInt for the weapon intellgence
     * @param nWeaponEnd for the weapon endurance
     * @param nWeaponStr for the weapon strength 
     * @param nWeaponFth for the weapon faith
     */
     public AreaTwo (int nAreaIndex, String strName, int nLevel, int nRunes, int nPlayerHp, int nPlayerDex, int nPlayerInt, int nPlayerEnd, int nPlayerStr, int nPlayerFth, int nWeaponHp, int nWeaponDex, int nWeaponInt, int nWeaponEnd,int nWeaponStr, int nWeaponFt)
    {
        super(nAreaIndex, strName, nLevel, nRunes, nPlayerHp, nPlayerDex, nPlayerInt, nPlayerEnd, nPlayerStr, nPlayerFth, nWeaponHp, nWeaponDex, nWeaponInt, nWeaponEnd, nWeaponStr, nWeaponFt);
        CAreaTwoFloorFourFrame = new JFrame();
        CAreaTwoFloorFiveFrame = new JFrame();
        CAreaTwoFloorFourLabel = new JLabel();
        CAreaTwoFloorFiveLabel = new JLabel();
        CAreaOneFloorOneImage = new ImageIcon("AreaTwoFloorOne.png");
        CAreaOneFloorTwoImage = new ImageIcon("AreaTwoFloorTwo.png");
        CAreaOneFloorThreeImage = new ImageIcon("AreaTwoFloorThree.png");
        CAreaTwoFloorFourImage = new ImageIcon("AreaTwoFloorFour.png");
        CAreaTwoFloorFiveImage = new ImageIcon("AreaTwoFloorFive.png");
        CStromveilTitle = new ImageIcon ("AreaTwoRayaLucariaAcademy.png");
        CTiles = new Tiles(2, strName, nRunes, nPlayerHp, nPlayerDex, nPlayerInt, nPlayerEnd, nPlayerStr, nPlayerFth, nWeaponHp, nWeaponDex, nWeaponInt, nWeaponEnd, nWeaponStr, nWeaponFth);
        this.nAreaIndex = nAreaIndex;
        bBossAlive = true;
        bActiveTiles = new boolean[19];

        
    }
     /** 
     * This method is for the area two floor one
     * @param nX for the x axis
     * @param nY is for the y axis
     */
    public void openAreaTwo (int nX, int nY)
    {
        
        this.nX = nX;
        this.nY = nY;
        initializeActiveTiles(19);
        displayAreaOneTitle();
        displayPlayerToken(nX, nY);
        displayAreaOneFloorOneFrame();
        displayMoveButtons();
        displayAreaOneFloorOne();
        displayAreaTwoFloorFour();
        displayPlayerHealth();
        displayPlayerLevel();
        displayPlayerRunes();
        CAreaOneFloorOneFrame.setVisible (true);
    }
     /** 
     * This method displays player token
     * @param nX for the x axis
     * @param nY is for the y axis
     */
    public void displayPlayerToken (int nX, int nY){
        CPlayerTokenLabel.setIcon(CPlayerTokenImage);
        CPlayerTokenLabel.setBounds(nX, nY, 50, 50);
        switch (nFloorLevel)
        {
            case 1:
            CAreaOneFloorOneFrame.add(CPlayerTokenLabel);
            break;
            case 2:
            CAreaOneFloorTwoFrame.add(CPlayerTokenLabel);
            break; 
            case 3:
            CAreaOneFloorThreeFrame.add(CPlayerTokenLabel);
            break; 
            case 4: 
            CAreaTwoFloorFourFrame.add (CPlayerTokenLabel);
            break; 
            case 5:
            CAreaTwoFloorFiveFrame.add(CPlayerTokenLabel);
        }

    }
    /** 
     * This method displays move up button
     */
    public void displayMoveUpButton (){
        CMoveUpButton.setBounds(200, 200, 50, 50);
        CMoveUpButton.setText("W");
        CMoveUpButton.setBackground(Color.BLACK);
        CMoveUpButton.setForeground (Color.YELLOW);
        CMoveUpButton.setFocusable(false);
        CMoveUpButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CMoveUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            switch (nFloorLevel)
            {
                case 1: 
                nY -= 43;
                if (nY >= 180)
                {
                    displayPlayerToken(nX, nY);
                    displayAreaOneFloorOne();
                }
                else
                {
                    nY += 43;
                }
                break; 
                case 2: 
                nY -= 43;
                if (nY >= 192 )
                {
                    displayPlayerToken(nX, nY);
                    displayAreaOneFloorTwo(); 
                }
                else
                {
                    nY += 43;
                }
                break;
               case 3:
               nY -= 43;
               if (nY >= 196 )
               {
                   displayPlayerToken(nX, nY);
                   displayAreaOneFloorThree(); 
               }
               else
               {
                   nY += 43;
               }
               break; 
               case 4: 
               nY -= 43;
               if (nY >= 197 )
               {
                   displayPlayerToken(nX, nY);
                   displayAreaTwoFloorFour(); 
               }
               else
               {
                   nY += 43;
               }
               break; 
               case 5:
               nY -= 42;
               if (nY >= 196 )
               {
                   displayPlayerToken(nX, nY);
                   displayAreaTwoFloorFive(); 
               }
               else
               {
                   nY += 42;
               }
               
            }
            }
        });
        CAreaOneFloorOneFrame.add (CMoveUpButton);
    }
    /** 
     * This method displays move down button
     */
    public void displayMoveDownButton (){
        CMoveDownButton.setBounds(200, 300, 50, 50);
        CMoveDownButton.setText("S");
        CMoveDownButton.setBackground(Color.BLACK);
        CMoveDownButton.setForeground (Color.YELLOW);
        CMoveDownButton.setFocusable(false);
        CMoveDownButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CMoveDownButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (nFloorLevel)
                {
                    case 1:
                    nY += 43;
                    if (nY <= 365)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorOne();
                    }
                    else
                    {
                        nY -= 43;
                    }
                    break; 
                    case 2:
                    nY += 43;
                    if (nY <= 493)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorTwo();
                    }
                    else
                    {
                        nY -= 43;
                    }
                    break; 
                    case 3:
                    nY += 43;
                    if (nY <= 490)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorThree();
                    }
                    else
                    {
                        nY -= 43;
                    }
                    break;
                    case 4: 
                    nY += 43;
                    if (nY <= 283 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaTwoFloorFour(); 
                    }
                    else
                    {
                        nY -= 43;
                    }
                    break;
                    case 5:
                    nY += 42;
                    if (nY <= 490 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaTwoFloorFive(); 
                    }
                    else
                    {
                        nY -= 42;
                    }
                    
                }
            }
        });
        CAreaOneFloorOneFrame.add (CMoveDownButton);
    }
    /** 
     * This method displays move left button
     */
    public void displayMoveLeftButton (){
        CMoveLeftButton.setBounds(150, 250, 50, 50);
        CMoveLeftButton.setText("A");
        CMoveLeftButton.setBackground(Color.BLACK);
        CMoveLeftButton.setForeground (Color.YELLOW);
        CMoveLeftButton.setFocusable(false);
        CMoveLeftButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CMoveLeftButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (nFloorLevel)
                {
                    case 1:
                    nX -= 50;
                    if (nX >= 365)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorOne();
                        
                    }
                    else
                    {
                        nX += 50;
                    }
                    break;
                    case 2:
                    nX -= 50;
                    if (nX >= 445)
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorTwo();
                        
                    }
                    else
                    {
                        nX += 50;
                    }
                    break;
                    case 3: 
                    nX -= 50;
                    if (nX >= 390 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorThree();
                        
                    }
                    else
                    {
                        nX += 50;
                    }
                    break; 
                    case 4:
                    nX -= 50;
                    if (nX >= 365 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaTwoFloorFour();
                        
                    }
                    else
                    {
                        nX += 50;
                    }
                    break;
                    case 5: 
                    nX -= 50;
                    if (nX >= 345 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaTwoFloorFive();
                        
                    }
                    else
                    {
                        nX += 50;
                    }
                }

              
            }
        });
        CAreaOneFloorOneFrame.add (CMoveLeftButton);
    }
    /** 
     * This method displays move right button
     */
    public void displayMoveRightButton (){
        CMoveRightButton.setBounds(250, 250, 50, 50);
        CMoveRightButton.setText("D");
        CMoveRightButton.setBackground(Color.BLACK);
        CMoveRightButton.setForeground (Color.YELLOW);
        CMoveRightButton.setFocusable(false);
        CMoveRightButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CMoveRightButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (nFloorLevel)
                {
                    case 1:
                    nX += 50; 
                    if (nX <= 595)
                        {
                            displayPlayerToken(nX, nY);
                            displayAreaOneFloorOne();
                        }
                        else
                        {
                            nX -= 50;
                        }
                    break;

                    case 2:
                    nX += 50; 
                    if (nX <= 550 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorTwo();
                    }
                    else 
                    {
                        nX -= 50;
                    }
                    break;

                    case 3:
                    nX += 50;
                    if (nX <= 590 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaOneFloorThree();
                    }
                    else
                    {
                        nX -= 50;
                    }
                    break;
                    case 4:
                    nX += 50;
                    if (nX <= 615 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaTwoFloorFour();
                        
                    }
                    else
                    {
                        nX -= 50;
                    }
                    break;
                    case 5: 
                    nX += 50;
                    if (nX <= 645 )
                    {
                        displayPlayerToken(nX, nY);
                        displayAreaTwoFloorFive();
                        
                    }
                    else
                    {
                        nX -= 50;
                    }
                    break;

                }
            }
        });
        CAreaOneFloorOneFrame.add (CMoveRightButton);
    }
    /** 
     * This method displays interact button
     */
    public void displayInteractButton (){
        CInteractButton.setBounds(200, 250, 50, 50);
        CInteractButton.setText("E");
        CInteractButton.setBackground(Color.BLACK);
        CInteractButton.setForeground (Color.YELLOW);
        CInteractButton.setFocusable(false);
        CInteractButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CInteractButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
         {
            switch (nFloorLevel)
            {
                // Floor 1
                case 1:
                if (nX == 495 && nY == 193)
                {
                    // TO DO : GO BACK AREA 1 HERE;
                }
                else if (nX == 495 && nY == 365 )
                {
                    nFloorLevel = 2;
                    nX = 500;
                    nY = 195;
                    openAreaOneFloorTwo(nX, nY);
                    CAreaOneFloorOneFrame.dispose();
                   
                }
                else if (nX == 545 && nY == 322){
                    if (CTiles.checkActiveTile(bActiveTiles[0]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[0] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 445 && nY == 322)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[1]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[1] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                break;
                // Floor 2
                case 2:
                
                if (nX == 500 && nY == 195)
                {
                    // Door Tile
                    nFloorLevel = 1;
                    nX = 495;
                    nY = 365;
                    openAreaOneFloorOne(nX, nY);
                    CAreaOneFloorTwoFrame.dispose();
                }
                else if (nX == 450 && nY == 238 )
                {
                    if (CTiles.checkActiveTile(bActiveTiles[2]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[2] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if ( nX == 450 && nY == 324)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[3]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[3] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 450 && nY == 410)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[4]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[4] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 550 && nY == 324)
                {
                    nFloorLevel = 3;
                    nX = 390;
                    nY = 325;
                    openAreaOneFloorThree(nX, nY);
                    CAreaOneFloorTwoFrame.dispose();
                }
                break; 
                // Level 3
                case 3:
                if (nX == 490 && nY == 239 )
                {
                    
                    if (CTiles.checkActiveTile(bActiveTiles[5]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[5] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                    
                }
                else if (nX == 490 && nY == 411)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[6]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[6] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 590 && nY == 325)
                {
                    // Floor Four
                    nX = 365;
                    nY = 240;
                    nFloorLevel = 4;
                    openAreaTwoFloorFour(nX, nY);
                    CAreaOneFloorThreeFrame.dispose();
                }
                else if (nX == 490 && nY == 196)
                {
                    // Floor Five
                    nX = 495;
                    nY = 490;
                    nFloorLevel = 5;
                    openAreaTwoFloorFive(nX, nY);
                    CAreaOneFloorThreeFrame.dispose();
                }
                // level 4
                break;
                case 4:
                if (nX == 365 && nY == 240)
                {
                    nFloorLevel = 3;
                    nX = 590;
                    nY = 325;
                    openAreaOneFloorThree(nX, nY);
                    CAreaTwoFloorFourFrame.dispose();
                }
                else if (nX == 465 && nY == 283)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[7]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[7] = false; 
                    }
                }
                else if (nX == 465 && nY == 197)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[8]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[8] = false; 
                    }
                }
                else if (nX == 565 && nY == 197)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[9]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[9] = false; 
                    }
                }
                else if (nX == 565 && nY == 283 )
                {
                    if (CTiles.checkActiveTile(bActiveTiles[10]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[10] = false; 
                    }
                }
                break;
                case 5:
                if (nX == 495 && nY == 196)
                {
                    if (CTiles.checkFastTravel(bBossAlive)== true)
                    {
                        AreaThree CAreaThree = new AreaThree(3, strName, nLevel, nRunes, nPlayerHp, nPlayerDex, nPlayerInt, nPlayerEnd, nPlayerStr, nPlayerFth, nWeaponHp, nWeaponDex, nWeaponInt, nWeaponEnd, nWeaponStr, nWeaponFth);
                        CAreaThree.openAreaThreeFloorOne (495, 535);
                        CAreaTwoFloorFiveFrame.dispose();
                    }
                    
                }
                else if (nX == 595 && nY == 448)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[11]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[11] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 395 && nY == 448)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[12]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[12] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 495 && nY == 364 )
                {
                    CTiles.openBossTile(nAreaIndex);
                    bBossAlive = false;
                }
                else if (nX == 395 && nY == 364)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[13]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[13] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 595 && nY == 364)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[14]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[14] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 595 && nY == 280)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[15]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[15] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 495 && nY == 280 )
                {
                    if (CTiles.checkActiveTile(bActiveTiles[16]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[16] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 595 && nY == 280)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[17]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[17] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 495 && nY == 196 )
                {
                    if (CTiles.checkFastTravel(bBossAlive) == true)
                    {
                        AreaThree CAreaThree = new AreaThree(3, strName, nLevel, nRunes, nPlayerHp, nPlayerDex, nPlayerInt, nPlayerEnd, nPlayerStr, nPlayerFth, nWeaponHp, nWeaponDex, nWeaponInt, nWeaponEnd, nWeaponStr, nWeaponFth);
                        CAreaThree.openAreaThreeFloorOne (495, 535);
                    }
                }
                else if (nX == 395 && nY == 280)
                {
                    if (CTiles.checkActiveTile(bActiveTiles[18]) == true)
                    {
                        CTiles.openSpawnTile(CEnemy);
                        if (CTiles.getTreasureboolean() == true)
                        {
                            nRunes = nRunes + CTiles.getTreasureRunes();
                            displayPlayerRunes();
                            CTiles.setTreasureBoolean(false);
                        }
                        bActiveTiles[18] = false; 
                    }
                    else 
                    {
                        displayDeactivatedTileFrame();
                    }
                }
                else if (nX == 495 && nY == 490)
                {
                    nFloorLevel = 3;
                    nX = 490;
                    nY = 196;
                    openAreaOneFloorThree(nX, nY);
                    CAreaTwoFloorFiveFrame.dispose();
                }
                break; 
            }
           
        }
        });
        CAreaOneFloorOneFrame.add (CInteractButton);
    }
     /** 
     * This method is for the area two floor four
     * @param nX for the x axis
     * @param nY is for the y axis
     */
    public void openAreaTwoFloorFour (int nX, int nY){
        
        displayAreaTwoFloorFourFrame();
        displayAreaOneTitle();
        displayPlayerToken(nX, nY);
        displayAreaTwoFloorFour();
        displayPlayerHealth();
        displayPlayerLevel();
        displayPlayerRunes();
        CAreaTwoFloorFourFrame.add(CPlayerTokenLabel);
        CAreaTwoFloorFourFrame.add(CAreaOneTitleLabel);
        CAreaTwoFloorFourFrame.add(CMoveUpButton);
        CAreaTwoFloorFourFrame.add(CMoveRightButton);
        CAreaTwoFloorFourFrame.add(CMoveDownButton);
        CAreaTwoFloorFourFrame.add(CMoveLeftButton);
        CAreaTwoFloorFourFrame.add(CInteractButton);
        CAreaTwoFloorFourFrame.add(CPlayerTokenLabel);
        CAreaTwoFloorFourFrame.add(CRunesLabel);
        CAreaTwoFloorFourFrame.add(CPlayerHealthLabel);
        CAreaTwoFloorFourFrame.add(CPlayerLevelLabel);
        CAreaTwoFloorFourFrame.setVisible (true); 
    }
      /** 
     * This method is for the area two floor five
     * @param nX for the x axis
     * @param nY is for the y axis
     */
    public void openAreaTwoFloorFive (int nX, int nY){
        
        displayAreaTwoFloorFiveFrame();
        displayAreaOneTitle();
        displayPlayerToken(nX, nY);
        displayAreaTwoFloorFive();
        displayPlayerHealth();
        displayPlayerLevel();
        displayPlayerRunes();
        CAreaTwoFloorFiveFrame.add(CAreaOneTitleLabel);
        CAreaTwoFloorFiveFrame.add(CMoveUpButton);
        CAreaTwoFloorFiveFrame.add(CMoveRightButton);
        CAreaTwoFloorFiveFrame.add(CMoveDownButton);
        CAreaTwoFloorFiveFrame.add(CMoveLeftButton);
        CAreaTwoFloorFiveFrame.add(CInteractButton);
        CAreaTwoFloorFiveFrame.add(CPlayerTokenLabel);
        CAreaTwoFloorFiveFrame.add(CRunesLabel);
        CAreaTwoFloorFiveFrame.add(CPlayerHealthLabel);
        CAreaTwoFloorFiveFrame.add(CPlayerLevelLabel);
        CAreaTwoFloorFiveFrame.setVisible (true); 
    }
      /** 
     * This method is for the area two floor four frame
     */
    public void displayAreaTwoFloorFourFrame (){
        CAreaTwoFloorFourFrame.setSize (1000, 700);
        CAreaTwoFloorFourFrame.setTitle("Area One Floor Four");
        CAreaTwoFloorFourFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CAreaTwoFloorFourFrame.setLayout(null);
        CAreaTwoFloorFourFrame.getContentPane().setBackground(Color.GRAY);
    }
      /** 
     * This method is for the area two floor five frame
     */
    public void displayAreaTwoFloorFiveFrame (){
        CAreaTwoFloorFiveFrame.setSize (1000, 700);
        CAreaTwoFloorFiveFrame.setTitle("Area One Floor Five");
        CAreaTwoFloorFiveFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CAreaTwoFloorFiveFrame.setLayout(null);
        CAreaTwoFloorFiveFrame.getContentPane().setBackground(Color.GRAY);
    }
      /** 
     * This method displays area two floor four 
     */
    public void displayAreaTwoFloorFour(){
       CAreaTwoFloorFourLabel.setIcon(CAreaTwoFloorFourImage);
       CAreaTwoFloorFourLabel.setVerticalAlignment(JLabel.TOP);
       CAreaTwoFloorFourLabel.setHorizontalAlignment(JLabel.CENTER);
       CAreaTwoFloorFourLabel.setBounds(240,200, 550, 400);
       CAreaTwoFloorFourFrame.add(CAreaTwoFloorFourLabel);
    }
     /** 
     * This method displays area two floor five 
     */
    public void displayAreaTwoFloorFive(){
        CAreaTwoFloorFiveLabel.setIcon(CAreaTwoFloorFiveImage);
        CAreaTwoFloorFiveLabel.setVerticalAlignment(JLabel.TOP);
        CAreaTwoFloorFiveLabel.setHorizontalAlignment(JLabel.CENTER);
        CAreaTwoFloorFiveLabel.setBounds(240,200, 550, 400);
        CAreaTwoFloorFiveFrame.add(CAreaTwoFloorFiveLabel);
     }
}
