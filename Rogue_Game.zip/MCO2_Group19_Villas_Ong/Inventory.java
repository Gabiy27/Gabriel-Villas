import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
/** 
 * This is the Inventory class
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class Inventory 
{
    /**
     * This field is for the frame
     */
    private JFrame CInventorySelectFrame; 
    /**
     * This field is for the frame
     */
    private JFrame CCheckInventoryFrame;
    /**
     * This field is for the image
     */
    private ImageIcon CInventoryTitleImage;
    /**
     * This field is for the text field
     */
    private TextField CWeaponNameTextField;
    /**
     * This field is for the label
     */
    private JLabel CWeaponNameLabel;
     /**
     * This field is for the label
     */
    private JLabel CInventoryTitleLabel;
     /**
     * This field is for the label
     */
    private JLabel CWeaponNameListLabel [];
     /**
     * This field is for the label
     */
    private JLabel CWeaponStatsLabel;
     /**
     * This field is for the button
     */
    private JButton CSubmitButton;
     /**
     * This field is for the button
     */
    private JButton CCheckInventoryButton;
     /**
     * This field is for the button
     */
    private JButton CBackButton;
     /**
     * This field is for the button
     */
    private JButton CDefaultWeaponButton;
     /**
     * This field is for chosen weapon
     */
    private String strChosenWeapon;
     /**
     * This field is for the label
     */
    private JLabel CDisplayWeaponLabel;
     /**
     * This field is for the arraylist
     */
    private ArrayList <String> arrName; 
    /**
     * This field is for the arraylist
     */
    private ArrayList <Integer> arrHp;
    /**
     * This field is for the arraylist
     */
    private ArrayList <Integer> arrDex;
    /**
     * This field is for the arraylist
     */
    private ArrayList <Integer> arrInt;
    /**
     * This field is for the arraylist
     */
    private ArrayList <Integer> arrEnd;
    /**
     * This field is for the arraylist
     */
    private ArrayList <Integer> arrStr;
    /**
     * This field is for the arraylist
     */
    private ArrayList <Integer> arrFth;
    /**
     * This field is for the hp
     */
    private int nHp; 
    /**
     * This field is for the dexteity
     */
    private int nDexterity;
    /**
     * This field is for the intelligence
     */
    private int nIntelligence; 
    /**
     * This field is for the endurance
     */
    private int nEndurance; 
    /**
     * This field is for the strength
     */
    private int nStrength; 
    /**
     * This field is for the faith
     */
    private int nFaith; 
    /**
     * This field is for the current weapon name
     */
    private String strCurrentWeaponName;
    /**
     * This field is for the Index number
     */
    private int nIndex;
    /**
     * This constructor is for the inventory
     */
    public Inventory ()
    {
        CInventoryTitleLabel = new JLabel();
        CInventoryTitleImage = new ImageIcon("InventoryTitle.png");
        CInventorySelectFrame = new JFrame();
        CCheckInventoryFrame = new JFrame();
        CWeaponNameTextField = new TextField();
        CWeaponNameLabel = new JLabel(); 
        CWeaponStatsLabel = new JLabel();
        CDisplayWeaponLabel = new JLabel();
        CSubmitButton = new JButton();
        CCheckInventoryButton = new JButton();
        CBackButton = new JButton();
        arrHp = new ArrayList<Integer>();
        arrDex = new ArrayList<Integer>();
        arrInt = new ArrayList<Integer>();
        arrEnd = new ArrayList<Integer>();
        arrStr = new ArrayList<Integer>();
        arrFth = new ArrayList<Integer>();
        arrName = new ArrayList<String>();
        strChosenWeapon = "";
        strCurrentWeaponName = "";
        nHp = 0;
        nDexterity = 0;
        nIntelligence = 0;
        nEndurance = 0;
        nStrength = 0;
        nFaith = 0;
        nIndex = 0;
        CDefaultWeaponButton = new JButton();
    }
    /**
     * This method displays Inventory title
     */
    public void displayInventoryTitle (){
        CInventoryTitleLabel.setIcon(CInventoryTitleImage);
        CInventoryTitleLabel.setVerticalAlignment(JLabel.TOP);
        CInventoryTitleLabel.setHorizontalAlignment(JLabel.CENTER);
        CInventoryTitleLabel.setBounds(300, 5, 400, 400);
        CInventorySelectFrame.add( CInventoryTitleLabel);
    }
    /**
     * This method displays 
     */
    public void displayFreeDefaultWeaponButton ()
    {
        CDefaultWeaponButton.setBounds(450, 450, 300, 50);
        CDefaultWeaponButton.setText ("Choose Default Sword");
        CDefaultWeaponButton.setBackground(Color.BLACK);
        CDefaultWeaponButton.setForeground(Color.YELLOW);
        CDefaultWeaponButton.setFocusable(false);
        CDefaultWeaponButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                strChosenWeapon = "Default Sword";
                nHp = 0;
                nDexterity = 5;
                nIntelligence = 7;
                nEndurance = 7;
                nStrength = 7;
                nFaith = 7;
                setWeaponToInventory(strChosenWeapon, nHp, nDexterity, nIntelligence, nEndurance, nStrength, nFaith);
            }
        });
        CInventorySelectFrame.add (CDefaultWeaponButton);
    }
    /**
     * This method opens frame
     */
    public void openInventorySelectionMenu ()
    {
        displaySelectInventoryFrame();
        displayWeaponNameTextField();
        displaySubmitButton();
        displayInventoryTitle();
        displayBackButton();
        displayCheckInventoryButton();
        displayFreeDefaultWeaponButton();
        CInventorySelectFrame.setVisible(true);
    }
    /**
     * This method displays text field
     */
    public void displayWeaponNameTextField () {
        CWeaponNameLabel.setText ("Weapon:");
        CWeaponNameLabel.setBounds(100, 280, 100, 100);
        CWeaponNameLabel.setFont (new Font ("Times New Roman", Font.PLAIN, 20));
        CWeaponNameLabel.setForeground (Color.white);
        CWeaponNameTextField.setPreferredSize(new Dimension(600,40));
        CWeaponNameTextField.setFont(new Font ("Consolas", Font.PLAIN, 35));
        CWeaponNameTextField.setBackground(Color.WHITE);
        CWeaponNameTextField.setBounds(200, 300, 600, 50);
        CInventorySelectFrame.add (CWeaponNameLabel);
        CInventorySelectFrame.add (CWeaponNameTextField);
    }
    /**
     * This method displays frame
     */
    public void displaySelectInventoryFrame ()
    {
        CInventorySelectFrame.setSize (900, 900);
        CInventorySelectFrame.setTitle("Inventory Selection");
        CInventorySelectFrame.setLayout(null);
        CInventorySelectFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        CInventorySelectFrame.getContentPane().setBackground(Color.BLACK);
    }
    /**
     * This method displays frame
     */
    public void displayCheckInventoryFrame () {
        CCheckInventoryFrame.setSize (900, 900);
        CCheckInventoryFrame.setTitle("Check Inventory");
        CCheckInventoryFrame.setLayout(null);
        CCheckInventoryFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        CCheckInventoryFrame.getContentPane().setBackground(Color.BLACK);
    }
    /**
     * This method displays weapons list
     */
    public void displayWeaponList  ()
    {
        CWeaponNameListLabel = new JLabel[arrName.size()];
        int nY = 5;
        for (int i = 0; i < arrName.size(); i++)
        {   
            nY += 20;
            CWeaponNameListLabel[i] = new JLabel();
            CWeaponNameListLabel[i].setText("[" + (i+1) + "]" + arrName.get(i));
            CWeaponNameListLabel[i].setBounds(10, nY, 600, 200);
            CWeaponNameListLabel[i].setFont(new Font ("Consolas", Font.PLAIN, 20));
            CWeaponNameListLabel[i].setHorizontalAlignment(JLabel.CENTER);
            CWeaponNameListLabel[i].setVerticalAlignment(JLabel.BOTTOM);
            CWeaponNameListLabel[i].setForeground(Color.WHITE);
           CCheckInventoryFrame.add (CWeaponNameListLabel[i]);
        }
    }
    /**
     * This method displays  button
     */
    public void displaySubmitButton (){
        CSubmitButton.setBounds(200, 400, 200, 50);
        CSubmitButton.setText ("Choose Weapon");
        CSubmitButton.setBackground(Color.BLACK);
        CSubmitButton.setForeground(Color.YELLOW);
        CSubmitButton.setFocusable(false);
        CSubmitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
             strChosenWeapon = CWeaponNameTextField.getText();
             if (strChosenWeapon.length() > 0)
             {
                searchWeapon(strChosenWeapon);
             }
             else 
             {
                displayInvalidInputPrompt();
             }
                
            }
        });
        CInventorySelectFrame.add (CDisplayWeaponLabel);
        CInventorySelectFrame.add (CSubmitButton);
    }
    /**
     * This method displays  button
     */
    public void displayCheckInventoryButton (){
        CCheckInventoryButton.setBounds(450, 400, 200, 50);
        CCheckInventoryButton.setText ("Check Inventory");
        CCheckInventoryButton.setBackground(Color.BLACK);
        CCheckInventoryButton.setForeground(Color.YELLOW);
        CCheckInventoryButton.setFocusable(false);
        CCheckInventoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
           
                displayCheckInventoryFrame();
                displayWeaponList();
                CCheckInventoryFrame.setVisible (true);

            }
        });
        CInventorySelectFrame.add (CCheckInventoryButton);
    }
    /**
     * This method search weapons 
     */
    public void searchWeapon (String strChosenWeapon)
    {
        for (int i = 0; i < arrName.size (); i++)
        {
            if (arrName.get(i).equals(strChosenWeapon))
            {
                nIndex = i;
                displayWeaponName(strChosenWeapon);
                displayWeaponStats(nIndex);
                setCurrentWeapon (nIndex);
            }
            else
            {
                displayWeaponDoesNotExistPrompt();
            }
        }
        
    }
    /**
     * This method displays  button
     */
    public void displayBackButton(){
        CBackButton.setBounds(200, 460, 100, 50);
        CBackButton.setText("Back");
        CBackButton.setBackground(Color.BLACK);
        CBackButton.setForeground (Color.YELLOW);
        CBackButton.setFocusable(false);
        CBackButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CInventorySelectFrame.dispose();
            }
        });
        CInventorySelectFrame.add (CBackButton);
    }
    /**
     * This method displays weapon does not exist
     */
    public void displayWeaponDoesNotExistPrompt () {
        CDisplayWeaponLabel.setText("Weapon Does Not Exist!");
        CDisplayWeaponLabel.setBounds(100, 500, 500, 100);
        CDisplayWeaponLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CDisplayWeaponLabel.setHorizontalAlignment(JLabel.CENTER);
        CDisplayWeaponLabel.setVerticalAlignment(JLabel.BOTTOM);
        CDisplayWeaponLabel.setForeground(Color.WHITE);
        CWeaponStatsLabel.setVisible(false);
        CInventorySelectFrame.add (CWeaponStatsLabel);
        CInventorySelectFrame.add (CDisplayWeaponLabel);
    }
    /**
     * This method displays invalid prompt
     */
    public void displayInvalidInputPrompt () {
        CDisplayWeaponLabel.setText("Invalid Input!");
        CDisplayWeaponLabel.setBounds(100, 500, 500, 100);
        CDisplayWeaponLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CDisplayWeaponLabel.setHorizontalAlignment(JLabel.CENTER);
        CDisplayWeaponLabel.setVerticalAlignment(JLabel.BOTTOM);
        CDisplayWeaponLabel.setForeground(Color.WHITE);
    }
    /**
     * This method set Weapons
     */
    public void setWeaponToInventory (String strName, int nHp, int nDexterity, int nIntelligence, int nEndurance, int nStrength, int nFaith)
    {
        arrName.add (strName);
        arrHp.add (nHp);
        arrDex.add (nDexterity);
        arrInt.add (nIntelligence);
        arrEnd.add (nEndurance);
        arrStr.add (nStrength);
        arrFth.add (nFaith);
    }
    /**
     * This method displays name
     */
    public void displayWeaponName (String strName){
        CDisplayWeaponLabel.setText("Current Weapon :"+ strName);
        CDisplayWeaponLabel.setBounds(200, 500, 500, 100);
        CDisplayWeaponLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CDisplayWeaponLabel.setHorizontalAlignment(JLabel.CENTER);
        CDisplayWeaponLabel.setVerticalAlignment(JLabel.BOTTOM);
        CDisplayWeaponLabel.setForeground(Color.WHITE);
        CInventorySelectFrame.add (CDisplayWeaponLabel);
    }
    /**
     * This method displays stats
     */
    public void displayWeaponStats (int nIndex){
        CWeaponStatsLabel.setText("[HP :" + arrHp.get(nIndex) + "] [DEX : " + arrDex.get(nIndex) + "] [INT:" + arrInt.get(nIndex) 
        + "] [END " + arrEnd.get(nIndex) + "] [STR :" + arrStr.get(nIndex) +  "] [FTH : "  + arrFth.get(nIndex) + "]");
        CWeaponStatsLabel.setBounds(100, 480, 600, 200);
        CWeaponStatsLabel.setFont(new Font ("Consolas", Font.BOLD, 15));
        CWeaponStatsLabel.setHorizontalAlignment(JLabel.CENTER);
        CWeaponStatsLabel.setVerticalAlignment(JLabel.BOTTOM);
        CWeaponStatsLabel.setForeground(Color.WHITE);
        CWeaponStatsLabel.setVisible(true);
        CInventorySelectFrame.add(CWeaponStatsLabel);
    }
    /**
     * This method sets current weapon
     */
    public void setCurrentWeapon (int nIndex)
    {
        System.out.println ("Hp Weapon: " + nHp);
        this.strCurrentWeaponName= arrName.get(nIndex);
        this.nHp = arrHp.get(nIndex);
        this.nEndurance = arrEnd.get(nIndex);
        this.nDexterity = arrDex.get(nIndex);
        this.nStrength = arrStr.get(nIndex);
        this.nIntelligence = arrInt.get(nIndex);
        this.nFaith = arrFth.get(nIndex);

    }
    /**
     * This method getters
     */
    public int getWeaponHp ()
    {
        return nHp;
    }
    /**
     * This method getters
     */
    public int getWeaponEndurance ()
    {
        return nEndurance;
    }
    /**
     * This method getters
     */
    public int getWeaponDexterity ()
    {
        return nDexterity;
    }
    /**
     * This method getters
     */
    public int getWeaponStrength ()
    {
        return nStrength;
    }
    /**
     * This method getters
     */
    public int getWeaponIntelligence ()
    {
        return nIntelligence;
    }
    /**
     * This method getters
     */
    public int getWeaponFaith ()
    {
        return nFaith;
    }
    /**
     * This method getters
     */
    public String getCurrentWeapon (){
        return arrName.get (nIndex);
    }
    /**
     * This sets arraylist 
     * @param setArrayList
     */
    public void setArrayList (ArrayList <String> arrPurchasedWeapon, int nSize)
    {
        for (int i= 0; i < nSize; i++)
        {
            arrName.add (arrPurchasedWeapon.get(i));
        }
    }
    
}