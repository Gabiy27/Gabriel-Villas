import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/** 
 * This is the Weapon class
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class Weapon extends JobClasses {
    /**
     * This field is for the frame
     */
    private JFrame CSwordsFrame; 
    /**
     * This field is for the frame
     */
    private JFrame CKatanasFrame;
    /**
     * This field is for the frame
     */
    private JFrame CWhipsFrame; 
    /**
     * This field is for the frame
     */
    private JFrame CGreatSwordsFrame;
    /**
     * This field is for the frame
     */
    private JFrame CStavesFrame;
    /**
     * This field is for the frame
     */
    private JFrame CSealsFrame;
    /**
     * This field is for the frame
     */
    private JFrame CInsufficientRunesFrame;
    /**
     * This field is for the frame
     */
    private JFrame CWeaponBoughtFrame;
    // Swords Button
    /**
     * This field is for the button
     */
    private JButton CShortSwordButton; 
    /**
     * This field is for the button
     */
    private JButton CRogiersRapierButton;
    /**
     * This field is for the button
     */
    private JButton CCodedSwordButton;
    /**
     * This field is for the button
     */
    private JButton CSwordOfNightAndFlameButton;
    // Katanas Button
    private JButton CUchigatanaButton;
    /**
     * This field is for the button
     */
    private JButton CMoonveilButton;
    /**
     * This field is for the button
     */
    private JButton CRiversOfBloodButton;
    /**
     * This field is for the button
     */
    private JButton CHandOfMaleniaButton;
    // Whips Button
    /**
     * This field is for the button
     */
    private JButton CWhipButton;
    /**
     * This field is for the button
     */
    private JButton CUrumiButton;
    /**
     * This field is for the button
     */
    private JButton CThornedWhipButton;
    /**
     * This field is for the button
     */
    private JButton CHoslowsPetalWhipButton;
    // GreatSwords
    private JButton CClayMoreButton;
    /**
     * This field is for the button
     */
    private JButton CStarsCourgeButton;
    /**
     * This field is for the button
     */
    private JButton CInseparableSwordButton;
    /**
     * This field is for the button
     */
    private JButton CMalikethsBlackBladeButton; 
    // Staves
    private JButton CAstrologersStaffButton;
    /**
     * This field is for the button
     */
    private JButton CAlbinauricButton;
    /**
     * This field is for the button
     */
    private JButton CStaffOfTheGuiltyButton;
    /**
     * This field is for the button
     */
    private JButton CCarianRegalScepterButton;

    // Seals 
    private JButton CFingerSealButton;
    /**
     * This field is for the button
     */
    private JButton CGodSlayersSealButton;
    /**
     * This field is for the button
     */
    private JButton CGoldenOrderSealButton;
    /**
     * This field is for the button
     */
    private JButton CDragonCommunionSealButton;
    // Swords
    /**
     * This field is for the image
     */
    private ImageIcon CShortSwordImage;
    /**
     * This field is for the image
     */
    private ImageIcon CRogiersRapierImage;
    /**
     * This field is for the image
     */
    private ImageIcon CCodedSwordImage;
    /**
     * This field is for the image
     */
    private ImageIcon CSwordOfNightAndFlameImage;
    // Katanas
    /**
     * This field is for the image
     */
    private ImageIcon CUchigatanaImage;
    /**
     * This field is for the image
     */
    private ImageIcon CMoonveilImage;
    /**
     * This field is for the image
     */
    private ImageIcon CRiversOfBloodImage;
    /**
     * This field is for the image
     */
    private ImageIcon CHandOfMaleniaImage;
    // Whips image
    /**
     * This field is for the image
     */
    private ImageIcon CWhipImage; 
    /**
     * This field is for the image
     */
    private ImageIcon CUrumiImage; 
    /**
     * This field is for the image
     */
    private ImageIcon CThornedWhipImage;
    /**
     * This field is for the image
     */
    private ImageIcon CHoslowsPetalWhipImage; 
    // GreatSword Image
    private ImageIcon CClayMoreImage;
    /**
     * This field is for the image
     */
    private ImageIcon CStarsCourgeImage;
    /**
     * This field is for the image
     */
    private ImageIcon CInseparableSwordImage;
    /**
     * This field is for the image
     */
    private ImageIcon CMalikethsBlackBladeImage; 
    // Staves
    /**
     * This field is for the image
     */
    private ImageIcon CAstrologersStaffImage;
    /**
     * This field is for the image
     */
    private ImageIcon CAlbinauricImage;
    /**
     * This field is for the image
     */
    private ImageIcon CStaffOfTheGuiltyImage;
    /**
     * This field is for the image
     */
    private ImageIcon CCarianRegalScepterImage;
  
      // Seals 
      /**
     * This field is for the image
     */
    private ImageIcon CFingerSealImage;
    /**
     * This field is for the image
     */
    private ImageIcon CGodSlayersSealImage;
    /**
     * This field is for the image
     */
    private ImageIcon CGoldenOrderSealImage;
    /**
     * This field is for the image
     */
    private ImageIcon CDragonCommunionSealImage;
    /**
     * This field is for the label
     */
    private JLabel CInsufficientRunesPromptLabel;
    /**
     * This field is for the label
     */
    private JLabel CWeaponBoughtPromtLabel;
    /**
     * This field is for the button
     */
    private JButton CInsufficientBackButton;
    /**
     * This field is for the button
     */
    private JButton CWeaponBoughtBackButton;
    /**
     * This field is for the button
     */
    private JButton CBackButton; 
    // Fields
    private int nRuneCost;
    /**
     * This field is for the runes
     */
    private int nRunes; 
    // Class 
    /**
     * This field is for the inventory
     */
    private Inventory CInventory;
    /**
     * This field is for the arraylist
     */
    private ArrayList <String> arrPurchasedWeapon;
    /**
     * This constructor is for the weapon
     */
    public Weapon (){

    }
    /**
     * This constructor is for the weapon
     * @param nRunes
     */
    public Weapon (int nRunes) {
        this.CInventory = new Inventory();
        this.CInsufficientBackButton = new JButton();
        this.CWeaponBoughtBackButton = new JButton();
        this.CSwordsFrame = new JFrame();
        this.CKatanasFrame = new JFrame();
        this.CWhipsFrame = new JFrame();
        this.CGreatSwordsFrame= new JFrame();
        this.CStavesFrame = new JFrame();
        this.CSealsFrame = new JFrame();
        this.CInsufficientRunesFrame = new JFrame();
        this.CWeaponBoughtFrame = new JFrame(); 
        this.CWeaponBoughtPromtLabel = new JLabel();
        this.CInsufficientRunesPromptLabel = new JLabel();
        // Swords
        this.CShortSwordButton = new JButton();
        this.CRogiersRapierButton = new JButton(); 
        this.CCodedSwordButton = new JButton();
        this.CSwordOfNightAndFlameButton = new JButton();
        // Katanas
        this.CUchigatanaButton = new JButton();
        this.CMoonveilButton = new JButton();
        this.CRiversOfBloodButton = new JButton();
        this.CHandOfMaleniaButton = new JButton();
        // Whips
        this.CWhipButton = new JButton();
        this.CUrumiButton = new JButton();
        this.CThornedWhipButton = new JButton();
        this.CHoslowsPetalWhipButton = new JButton(); 
         // GreatSwords
        this.CClayMoreButton = new JButton();
        this.CStarsCourgeButton = new JButton();
        this.CInseparableSwordButton = new JButton();
        this.CMalikethsBlackBladeButton = new JButton();
        // Staves
        this.CAstrologersStaffButton = new JButton();
        this.CAlbinauricButton = new JButton();
        this.CStaffOfTheGuiltyButton = new JButton();
        this.CCarianRegalScepterButton = new JButton();

        // Seals 
        this.CFingerSealButton = new JButton();
        this.CGodSlayersSealButton = new JButton();
        this.CGoldenOrderSealButton = new JButton();
        this.CDragonCommunionSealButton = new JButton();

        this.CUchigatanaImage = new ImageIcon("Uchigatana.png");
        this.CMoonveilImage = new ImageIcon("Moonveil.png");
        this.CRiversOfBloodImage = new ImageIcon("RiversOfBlood.png");
        this.CHandOfMaleniaImage = new ImageIcon("HandOfMalenia.png");
        this.CShortSwordImage = new ImageIcon("ShortSword.png");
        this.CRogiersRapierImage = new ImageIcon("RogiersRapier.png");
        this.CCodedSwordImage = new ImageIcon("CodedSword.png");
        this.CSwordOfNightAndFlameImage = new ImageIcon("SwordOfNightAndFlame.png");
        this.CWhipImage = new ImageIcon("Whip.png");
        this.CUrumiImage = new ImageIcon("Urumi.png");
        this.CThornedWhipImage = new ImageIcon("ThornedWhip.png");
        this.CHoslowsPetalWhipImage = new ImageIcon("HoslowsPetalWhip.png");
        // GreatSword Image
        this.CClayMoreImage = new ImageIcon("Claymore.png");
        this.CStarsCourgeImage = new ImageIcon("StarsCourgeGreatsword.png");
        this.CInseparableSwordImage = new ImageIcon("InseparableSword.png");
        this.CMalikethsBlackBladeImage = new ImageIcon("MalikethsBlackBlade.png");
        // Staves
        this.CAstrologersStaffImage = new ImageIcon("AstrologersStaff.png");
        this.CAlbinauricImage = new ImageIcon("AlbinauricStaff.png");
        this.CStaffOfTheGuiltyImage = new ImageIcon("StaffOfTheGuilty.png");
        this.CCarianRegalScepterImage = new ImageIcon("CarianRegalScepter.png");
    
        // Seals 
        this.CFingerSealImage= new ImageIcon("FingerSeal.png");
        this.CGodSlayersSealImage = new ImageIcon("GodslayersSeal.png");
        this.CGoldenOrderSealImage = new ImageIcon("GoldenOrderSeal.png");
        this.CDragonCommunionSealImage = new ImageIcon("DragonCommunionSeal.png");
        this.CBackButton = new JButton();
        this.nRuneCost = 0;
        this.strName = "";
        this.nDexterity = 0;
        this.nHp = 0;
        this.nEndurance = 0; 
        this.nStrength = 0; 
        this.nIntelligence = 0;
        this.nFaith = 0;
        this.nRunes = 10000;
        this.arrPurchasedWeapon = new ArrayList<String>();
    }
    /**
     * this method opens the menu
     */
    public void openSwordsMenu (){
        displaySwordsFrame();
        displayShortSwordButton(CInventory);
        displayRogiersRapierButton();
        displayCodedSwordButton();
        displaySwordOfNightAndFlameButton();
        displayBackButton();
        CSwordsFrame.add(CBackButton);
        CSwordsFrame.setVisible(true);
     
      
      
    }
    /**
     * this method opens the menu
     */
    public void openKatanasMenu (){
        displayKatanasFrame();
        displayUchigatanaButton();
        displayMoonveilButton();
        displayRiversOfBloodButton();
        displayHandOfMileniaButton();
        displayBackButton();
        CKatanasFrame.add(CBackButton);
        CKatanasFrame.setVisible (true); 
    }
    /**
     * this method opens the menu
     */
    public void openWhipMenu (){
        displayWhipFrame();
        displayWhipButton();
        displayUrumiButton();
        displayThornedWhipButton();
        displayHosLowsPetalWhipButton();
        displayBackButton();
        CWhipsFrame.add(CBackButton);
        CWhipsFrame.setVisible (true);
    }
    /**
     * this method opens the menu
     */
    public void openGreatSwordsMenu (){
        displayGreatSwordsFrame();
        displayClaymoreButton();
        displayStarsCourageGreatSwordButton();
        displayInseparableSwordButton();
        displaysMalikethsBlackBladeButton();
        displayBackButton();
        CGreatSwordsFrame.add(CBackButton);
        CGreatSwordsFrame.setVisible (true);
    }
    /**
     * this method opens the menu
     */
    public void openStavesMenu (){
        displayStavesFrame();
        displayAstrologersStaffButton();
        displayAlbinauricStaffButton();
        displayStaffOfTheGuiltyButton();
        displayCarianRegalScepterButton();
        displayBackButton();
        CStavesFrame.add(CBackButton);
        CStavesFrame.setVisible (true);
    }
    /**
     * this method opens the menu
     */
    public void openSealsMenu (){
        displaySealsFrame();
        displayFingerSealButton();
        displayGodslayersSealButton();
        displayGoldenOrderSealButton();
        displayDragonCommunionSealButton();
        displayBackButton();
        CSealsFrame.add(CBackButton);
        CSealsFrame.setVisible (true);
    }
    /**
     * this method opens the menu
     */
    public void displaySwordsFrame (){
        CSwordsFrame.setSize (800, 500);
        CSwordsFrame.setTitle("Swords Menu");
        CSwordsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CSwordsFrame.getContentPane().setBackground(Color.BLACK);
        CSwordsFrame.setLayout(new GridLayout(1,4, 5, 5));
        CSwordsFrame.setVisible(true);
    }
    /**
     * this method opens the frame
     */
    public void displayKatanasFrame (){
        CKatanasFrame.setSize (800, 500);
        CKatanasFrame.setTitle("Katanas Menu");
        CKatanasFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CKatanasFrame.getContentPane().setBackground(Color.BLACK);
        CKatanasFrame.setLayout(new GridLayout(1,4, 5, 5));
    }
     /**
     * this method opens the frame
     */
    public void displayWhipFrame (){
        CWhipsFrame.setSize (800, 500);
        CWhipsFrame.setTitle("Whips Menu");
        CWhipsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CWhipsFrame.getContentPane().setBackground(Color.BLACK);
        CWhipsFrame.setLayout(new GridLayout(1,4, 5, 5));
    }
     /**
     * this method opens the frame
     */
    public void displayGreatSwordsFrame (){
        CGreatSwordsFrame.setSize (800, 500);
        CGreatSwordsFrame.setTitle("GreatSwords Menu");
        CGreatSwordsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CGreatSwordsFrame.getContentPane().setBackground(Color.BLACK);
        CGreatSwordsFrame.setLayout(new GridLayout(1,4, 5, 5));
    }
     /**
     * this method opens the frame
     */
    public void displayStavesFrame (){
        CStavesFrame.setSize (800, 500);
        CStavesFrame.setTitle("Staves Menu");
        CStavesFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CStavesFrame.getContentPane().setBackground(Color.BLACK);
        CStavesFrame.setLayout(new GridLayout(1,4, 5, 5));
    }
     /**
     * this method opens the frame
     */
    public void displaySealsFrame (){
        CSealsFrame.setSize (800, 500);
        CSealsFrame.setTitle("Seals Menu");
        CSealsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CSealsFrame.getContentPane().setBackground(Color.BLACK);
        CSealsFrame.setLayout(new GridLayout(1,4, 5, 5));
    }
     /**
     * this method displays button
     */
    public void displayShortSwordButton (Inventory CInventory){
        
        CShortSwordButton.setBounds(100, 300, 50, 150);
        CShortSwordButton.setIcon(CShortSwordImage);
        CShortSwordButton.setFocusable(false);
        CShortSwordButton.setBackground (Color.BLACK);
        CShortSwordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            nRuneCost = 1000;
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                strName = "Short Sword "; 
                nHp = 30;
                nDexterity = 25;
                nIntelligence = 55;
                nEndurance = 45;
                nStrength = 55;
                nFaith = 55;
                nRunes = subtractRunes(nRunes, nRuneCost);
                displayWeaponBoughtPromptFrame(strName);
                // Inventory CInventory = new Inventory();
                // CInventory.setWeaponToInventory(strName, nHp, nDexterity, nIntelligence, nEndurance, nStrength, nFaith);
                // CInventory.printWeapons();
                arrPurchasedWeapon.add(strName);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
            
            }
        });
        CSwordsFrame.add (CShortSwordButton);
    }
     /**
     * this method displays button
     */
    public void displayRogiersRapierButton (){
        CRogiersRapierButton.setBounds(100, 300, 50, 150);
        CRogiersRapierButton.setIcon(CRogiersRapierImage);
        CRogiersRapierButton.setFocusable(false);
        CRogiersRapierButton.setBackground (Color.BLACK);
        CRogiersRapierButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 2000;
                strName = "Rogiers Rapier";
                displayWeaponBoughtPromptFrame(strName); 
                nHp = 10;
                nDexterity = 18;
                nIntelligence = 35;
                nEndurance = 25;
                nStrength = 35;
                nFaith = 35;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
            }
        });
        CSwordsFrame.add (CRogiersRapierButton);
    }
     /**
     * this method displays button
     */
    public void displayCodedSwordButton (){
        CCodedSwordButton.setBounds(100, 300, 50, 150);
        CCodedSwordButton.setIcon(CCodedSwordImage);
        CCodedSwordButton.setFocusable(false);
        CCodedSwordButton.setBackground (Color.BLACK);
        CCodedSwordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkSufficientRunes(nRunes, nRuneCost) == true)
                {
                    nRuneCost = 4000;
                    strName = "Coded Sword";
                    displayWeaponBoughtPromptFrame(strName); 
                    nHp = 10;
                    nDexterity = 18;
                    nIntelligence = 35;
                    nEndurance = 25;
                    nStrength = 35;
                    nFaith = 35;
                    nRunes = subtractRunes(nRunes, nRuneCost);
                } 
                else 
                {
                    displayInsufficientRunesFrame();
                }
          
            }
        });
        CSwordsFrame.add (CCodedSwordButton);
    }
     /**
     * this method displays button
     */
    public void displaySwordOfNightAndFlameButton (){
    
        CSwordOfNightAndFlameButton.setBounds(100, 300, 50, 50);
        CSwordOfNightAndFlameButton.setIcon(CSwordOfNightAndFlameImage);
        CSwordOfNightAndFlameButton.setFocusable(false);
        CSwordOfNightAndFlameButton.setBackground (Color.BLACK);
        CSwordOfNightAndFlameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkSufficientRunes(nRunes, nRuneCost) == true)
                {
                    nRuneCost = 8000;
                    strName = "Sword Of Night And Flame"; 
                    displayWeaponBoughtPromptFrame(strName);
                    nHp = 10;
                    nDexterity = 18;
                    nIntelligence = 35;
                    nEndurance = 25;
                    nStrength = 35;
                    nFaith = 35;
                    nRunes = subtractRunes(nRunes, nRuneCost);
                } 
                else 
                {
                    displayInsufficientRunesFrame();
                }
           
            }
        });
        CSwordsFrame.add (CSwordOfNightAndFlameButton);
    }
    /**
     * this method displays button
     */
    public void displayBackButton (){
        CBackButton.setBounds(200, 730, 100, 50);
        CBackButton.setText("Back");
        CBackButton.setBackground(Color.BLACK);
        CBackButton.setForeground (Color.YELLOW);
        CBackButton.setFocusable(false);
        CBackButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CSwordsFrame.dispose();
                CKatanasFrame.dispose();
                CWhipsFrame.dispose();
                CGreatSwordsFrame.dispose ();
                CStavesFrame.dispose ();
                CSealsFrame.dispose ();
            }   
        });
        CSwordsFrame.add (CBackButton);
    }
    /**
     * this method displays button
     */
    public void displayUchigatanaButton (){
        CUchigatanaButton.setBounds(100, 300, 50, 50);
        CUchigatanaButton.setIcon(CUchigatanaImage);
        CUchigatanaButton.setFocusable(false);
        CUchigatanaButton.setBackground (Color.BLACK);
        CUchigatanaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkSufficientRunes(nRunes, nRuneCost) == true)
                {
                    nRuneCost = 1875;
                    strName = "Uchigatana"; 
                    displayWeaponBoughtPromptFrame(strName);
                    nHp = 20;
                    nDexterity = 15;
                    nIntelligence = 0;
                    nEndurance = 35;
                    nStrength = 30;
                    nFaith = 0;
                    nRunes = subtractRunes(nRunes, nRuneCost);
                } 
                else 
                {
                    displayInsufficientRunesFrame();
                }
           
            }
        });
        CKatanasFrame.add (CUchigatanaButton);
    }
    /**
     * this method displays button
     */
    public void displayMoonveilButton (){
        CMoonveilButton.setBounds(100, 300, 50, 50);
        CMoonveilButton.setIcon(CMoonveilImage);
        CMoonveilButton.setFocusable(false);
        CMoonveilButton.setBackground (Color.BLACK);
        CMoonveilButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkSufficientRunes(nRunes, nRuneCost) == true)
                {
                    nRuneCost = 3750;
                    strName = "Moonveil"; 
                    displayWeaponBoughtPromptFrame(strName);
                    nHp = 30;
                    nDexterity = 20;
                    nIntelligence = 0;
                    nEndurance = 40;
                    nStrength = 45;
                    nFaith = 0;
                    nRunes = subtractRunes(nRunes, nRuneCost);
                } 
                else 
                {
                    displayInsufficientRunesFrame();
                }
           
            }
        });
        CKatanasFrame.add (CMoonveilButton);
    }
        /**
     * this method displays button
     */
    public void displayRiversOfBloodButton (){
        CRiversOfBloodButton.setBounds(100, 300, 50, 50);
        CRiversOfBloodButton.setIcon(CRiversOfBloodImage);
        CRiversOfBloodButton.setFocusable(false);
        CRiversOfBloodButton.setBackground (Color.BLACK);
        CRiversOfBloodButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkSufficientRunes(nRunes, nRuneCost) == true)
                {
                    nRuneCost = 7500;
                    strName = "Rivers Of Blood"; 
                    displayWeaponBoughtPromptFrame(strName);
                    nHp = 40;
                    nDexterity = 25;
                    nIntelligence = 0;
                    nEndurance = 45;
                    nStrength = 60;
                    nFaith = 0;
                    nRunes = subtractRunes(nRunes, nRuneCost);
                } 
                else 
                {
                    displayInsufficientRunesFrame();
                }
           
            }
        });
        CKatanasFrame.add (CRiversOfBloodButton);
    }
    /**
     * this method displays button
     */
    public void displayHandOfMileniaButton (){
        CHandOfMaleniaButton.setBounds(100, 300, 50, 50);
        CHandOfMaleniaButton.setIcon(CHandOfMaleniaImage);
        CHandOfMaleniaButton.setFocusable(false);
        CHandOfMaleniaButton.setBackground (Color.BLACK);
        CHandOfMaleniaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkSufficientRunes(nRunes, nRuneCost) == true)
                {
                    nRuneCost = 15000;
                    strName = "Hand Of Milena"; 
                    displayWeaponBoughtPromptFrame(strName);
                    nHp = 50;
                    nDexterity = 30;
                    nIntelligence = 0;
                    nEndurance = 50;
                    nStrength = 75;
                    nFaith = 0;
                    nRunes = subtractRunes(nRunes, nRuneCost);
                } 
                else 
                {
                    displayInsufficientRunesFrame();
                }
           
            }
        });
        CKatanasFrame.add (CHandOfMaleniaButton);
    }
        /**
     * this method displays button
     */
   public void displayWhipButton (){
    CWhipButton.setBounds(100, 300, 50, 50);
    CWhipButton.setIcon(CWhipImage);
    CWhipButton.setFocusable(false);
    CWhipButton.setBackground (Color.BLACK);
    CWhipButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 1500;
                strName = "Whip"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 15;
                nDexterity = 20;
                nIntelligence = 0;
                nEndurance = 60;
                nStrength = 20;
                nFaith = 0;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CWhipsFrame.add (CWhipButton);
   }
       /**
     * this method displays button
     */
   public void displayUrumiButton (){
    CUrumiButton.setBounds(100, 300, 50, 50);
    CUrumiButton.setIcon(CUrumiImage);
    CUrumiButton.setFocusable(false);
    CUrumiButton.setBackground (Color.BLACK);
    CUrumiButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 3000;
                strName = "Urumi"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 20;
                nDexterity = 25;
                nIntelligence = 10;
                nEndurance = 70;
                nStrength = 40;
                nFaith = 0;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CWhipsFrame.add (CUrumiButton);
   }
       /**
     * this method displays button
     */
   public void displayThornedWhipButton (){
    CThornedWhipButton.setBounds(100, 300, 50, 50);
    CThornedWhipButton.setIcon(CThornedWhipImage);
    CThornedWhipButton.setFocusable(false);
    CThornedWhipButton.setBackground (Color.BLACK);
    CThornedWhipButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 5000;
                strName = "Thorned Whip"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 30;
                nDexterity = 30;
                nIntelligence = 0;
                nEndurance = 80;
                nStrength = 50;
                nFaith = 40;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CWhipsFrame.add (CThornedWhipButton);
    
   }
       /**
     * this method displays button
     */
   public void displayHosLowsPetalWhipButton (){
    CHoslowsPetalWhipButton.setBounds(100, 300, 50, 50);
    CHoslowsPetalWhipButton.setIcon(CHoslowsPetalWhipImage);
    CHoslowsPetalWhipButton.setFocusable(false);
    CHoslowsPetalWhipButton.setBackground (Color.BLACK);
    CHoslowsPetalWhipButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 10000;
                strName = "Thorned Whip"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 35;
                nDexterity = 35;
                nIntelligence = 20;
                nEndurance = 90;
                nStrength = 55;
                nFaith = 20;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CWhipsFrame.add (CHoslowsPetalWhipButton);
   }
       /**
     * this method displays button
     */
   public void displayClaymoreButton (){
    CClayMoreButton.setBounds(100, 300, 50, 50);
    CClayMoreButton.setIcon(CClayMoreImage);
    CClayMoreButton.setFocusable(false);
    CClayMoreButton.setBackground (Color.BLACK);
    CClayMoreButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 3000;
                strName = "Claymore"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 15;
                nDexterity = 9;
                nIntelligence = 0;
                nEndurance = 10;
                nStrength = 20;
                nFaith = 0;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CGreatSwordsFrame.add (CClayMoreButton);
   }
       /**
     * this method displays button
     */
   public void displayStarsCourageGreatSwordButton (){
    CStarsCourgeButton.setBounds(100, 300, 50, 50);
    CStarsCourgeButton.setIcon(CStarsCourgeImage);
    CStarsCourgeButton.setFocusable(false);
    CStarsCourgeButton.setBackground (Color.BLACK);
    CStarsCourgeButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 6000;
                strName = "Starscourage Greatsword"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 20;
                nDexterity = 14;
                nIntelligence = 0;
                nEndurance = 15;
                nStrength = 40;
                nFaith = 20;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CGreatSwordsFrame.add (CStarsCourgeButton);
   }
       /**
     * this method displays button
     */
   public void displayInseparableSwordButton (){
    CInseparableSwordButton.setBounds(100, 300, 50, 50);
    CInseparableSwordButton.setIcon(CInseparableSwordImage);
    CInseparableSwordButton.setFocusable(false);
    CInseparableSwordButton.setBackground (Color.BLACK);
    CInseparableSwordButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 12000;
                strName = "Inseparable Sword"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 25;
                nDexterity = 19;
                nIntelligence = 60;
                nEndurance = 20;
                nStrength = 70;
                nFaith = 60;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CGreatSwordsFrame.add (CInseparableSwordButton);
   }
       /**
     * this method displays button
     */
   public void displaysMalikethsBlackBladeButton (){
    CMalikethsBlackBladeButton.setBounds(100, 300, 50, 50);
    CMalikethsBlackBladeButton.setIcon(CMalikethsBlackBladeImage);
    CMalikethsBlackBladeButton.setFocusable(false);
    CMalikethsBlackBladeButton.setBackground (Color.BLACK);
    CMalikethsBlackBladeButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 24000;
                strName = "Malkeths Black Blade"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 30;
                nDexterity = 24;
                nIntelligence = 40;
                nEndurance = 25;
                nStrength = 80;
                nFaith = 60;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CGreatSwordsFrame.add (CMalikethsBlackBladeButton);
   }
       /**
     * this method displays button
     */
   public void displayAstrologersStaffButton (){
    CAstrologersStaffButton.setBounds(100, 300, 50, 50);
    CAstrologersStaffButton.setIcon(CAstrologersStaffImage);
    CAstrologersStaffButton.setFocusable(false);
    CAstrologersStaffButton.setBackground (Color.BLACK);
    CAstrologersStaffButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 2000;
                strName = "Astrologers Staff"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 5;
                nDexterity = 12;
                nIntelligence = 25;
                nEndurance = 20;
                nStrength = 5;
                nFaith = 15;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CStavesFrame.add (CAstrologersStaffButton);
   }
       /**
     * this method displays button
     */
   public void displayAlbinauricStaffButton (){
    CAlbinauricButton.setBounds(100, 300, 50, 50);
    CAlbinauricButton.setIcon( CAlbinauricImage);
    CAlbinauricButton.setFocusable(false);
    CAlbinauricButton.setBackground (Color.BLACK);
    CAlbinauricButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 4000;
                strName = "Albinauric Staff"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 10;
                nDexterity = 14;
                nIntelligence = 45;
                nEndurance = 30;
                nStrength = 10;
                nFaith = 35;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CStavesFrame.add ( CAlbinauricButton);
   }
       /**
     * this method displays button
     */
   public void displayStaffOfTheGuiltyButton (){
    CStaffOfTheGuiltyButton.setBounds(100, 300, 50, 50);
    CStaffOfTheGuiltyButton.setIcon( CStaffOfTheGuiltyImage);
    CStaffOfTheGuiltyButton.setFocusable(false);
    CStaffOfTheGuiltyButton.setBackground (Color.BLACK);
    CStaffOfTheGuiltyButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 8000;
                strName = "Staff Of The Guilty"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 15;
                nDexterity = 16;
                nIntelligence = 65;
                nEndurance = 40;
                nStrength = 15;
                nFaith = 60;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CStavesFrame.add ( CStaffOfTheGuiltyButton);
   }
       /**
     * this method displays button
     */
   public void displayCarianRegalScepterButton (){
    CCarianRegalScepterButton.setBounds(100, 300, 50, 50);
    CCarianRegalScepterButton.setIcon(CCarianRegalScepterImage);
    CCarianRegalScepterButton.setFocusable(false);
    CCarianRegalScepterButton.setBackground (Color.BLACK);
    CCarianRegalScepterButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 16000;
                strName = "Carian Regal Scepter"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 25;
                nDexterity = 18;
                nIntelligence = 85;
                nEndurance = 50;
                nStrength = 20;
                nFaith = 75;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CStavesFrame.add ( CCarianRegalScepterButton);
   }
       /**
     * this method displays button
     */
   public void displayFingerSealButton (){
    CFingerSealButton.setBounds(100, 300, 50, 50);
    CFingerSealButton.setIcon( CFingerSealImage);
    CFingerSealButton.setFocusable(false);
    CFingerSealButton.setBackground (Color.BLACK);
    CFingerSealButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 2500;
                strName = "Finger Seal"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 10;
                nDexterity = 10;
                nIntelligence = 15;
                nEndurance = 45;
                nStrength = 0;
                nFaith = 20;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CSealsFrame.add ( CFingerSealButton);
   }
       /**
     * this method displays button
     */
   public void displayGodslayersSealButton (){
    CGodSlayersSealButton.setBounds(100, 300, 50, 50);
    CGodSlayersSealButton.setIcon( CGodSlayersSealImage);
    CGodSlayersSealButton.setFocusable(false);
    CGodSlayersSealButton.setBackground (Color.BLACK);
    CGodSlayersSealButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 5000;
                strName = "Godslayers Seal"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 15;
                nDexterity = 12;
                nIntelligence = 35;
                nEndurance = 50;
                nStrength = 0;
                nFaith = 40;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CSealsFrame.add ( CGodSlayersSealButton);
   }
       /**
     * this method displays button
     */
   public void displayGoldenOrderSealButton (){
    CGoldenOrderSealButton.setBounds(100, 300, 50, 50);
    CGoldenOrderSealButton.setIcon( CGoldenOrderSealImage);
    CGoldenOrderSealButton.setFocusable(false);
    CGoldenOrderSealButton.setBackground (Color.BLACK);
    CGoldenOrderSealButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 10000;
                strName = "Golden Order Seal"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 20;
                nDexterity = 14;
                nIntelligence = 65;
                nEndurance = 55;
                nStrength = 0;
                nFaith = 65;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CSealsFrame.add (CGoldenOrderSealButton);
   }
       /**
     * this method displays button
     */
   public void displayDragonCommunionSealButton (){
    CDragonCommunionSealButton.setBounds(100, 300, 50, 50);
    CDragonCommunionSealButton.setIcon( CDragonCommunionSealImage);
    CDragonCommunionSealButton.setFocusable(false);
    CDragonCommunionSealButton.setBackground (Color.BLACK);
    CDragonCommunionSealButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (checkSufficientRunes(nRunes, nRuneCost) == true)
            {
                nRuneCost = 15000;
                strName = "Dragon Communion Seal"; 
                displayWeaponBoughtPromptFrame(strName);
                nHp = 25;
                nDexterity = 18;
                nIntelligence = 75;
                nEndurance = 60;
                nStrength = 0;
                nFaith = 80;
                nRunes = subtractRunes(nRunes, nRuneCost);
            } 
            else 
            {
                displayInsufficientRunesFrame();
            }
       
        }
    });
    CSealsFrame.add (CDragonCommunionSealButton);
   }
       /**
     * this method displays button
     */
    public void displayWeaponBoughtPromptFrame (String strName){
        CWeaponBoughtFrame.setSize (800, 300);
        CWeaponBoughtFrame.setLayout(null);
        CWeaponBoughtFrame.setTitle("Weapon Bought");
        CWeaponBoughtFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CWeaponBoughtFrame.getContentPane().setBackground(Color.BLACK);
        displayWeaponBoughtPrompt(strName);
        displayWeaponBoughtBackButton();
        CWeaponBoughtFrame.setVisible(true);
    }
        /**
     * this method displays button
     */
    public void displayWeaponBoughtPrompt (String strName){
        CWeaponBoughtPromtLabel.setText("Weapon Added to Inventory ! Weapon Bought: " + strName);
        CWeaponBoughtPromtLabel.setBounds(10, 100, 700, 100);
        CWeaponBoughtPromtLabel.setHorizontalAlignment(JLabel.CENTER);
        CWeaponBoughtPromtLabel.setVerticalTextPosition(JLabel.TOP);
        CWeaponBoughtPromtLabel.setForeground(Color.WHITE);
        CWeaponBoughtPromtLabel.setFont (new Font ("Impact", Font.PLAIN, 20));
        CWeaponBoughtFrame.add( CWeaponBoughtPromtLabel);
    }
        /**
     * this method displays button
     */
    public void displayInsufficientRunesFrame (){
        CInsufficientRunesFrame.setSize (800, 300);
        CInsufficientRunesFrame.setTitle("Insufficient Runes Prompt");
        CInsufficientRunesFrame.setLayout(null);
        CInsufficientRunesFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CInsufficientRunesFrame.getContentPane().setBackground(Color.BLACK);
        displayInsufficientRunesPrompt();
        displayInsufficientBackButton();
        CInsufficientRunesFrame.setVisible(true);
    }
    /**
     * this method displays button
     */
    public void displayInsufficientRunesPrompt (){
        CInsufficientRunesPromptLabel.setText("Insufficient Runes!");
        CInsufficientRunesPromptLabel.setHorizontalAlignment(JLabel.CENTER);
        CInsufficientRunesPromptLabel.setVerticalTextPosition(JLabel.TOP);
        CInsufficientRunesPromptLabel.setForeground(Color.WHITE);
        CInsufficientRunesPromptLabel.setFont (new Font ("Impact", Font.PLAIN, 20));
        CInsufficientRunesPromptLabel.setBounds(100, 100, 500, 100);
        CInsufficientRunesFrame.add(CInsufficientRunesPromptLabel);
    }
        /**
     * this method displays button
     */
    public void displayInsufficientBackButton (){
        CInsufficientBackButton.setBounds(300, 200, 100, 50);
        CInsufficientBackButton.setText("Back");
        CInsufficientBackButton.setBackground(Color.BLACK);
        CInsufficientBackButton.setForeground (Color.YELLOW);
        CInsufficientBackButton.setFocusable(false);
        CInsufficientBackButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CInsufficientBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CInsufficientRunesFrame.dispose();
            }   
        });
        CInsufficientRunesFrame.add (CInsufficientBackButton);
    }
    /**
     * this method displays button
     */
    public void displayWeaponBoughtBackButton (){
        CWeaponBoughtBackButton.setBounds(300, 200, 100, 50);
        CWeaponBoughtBackButton.setText("Back");
        CWeaponBoughtBackButton.setBackground(Color.BLACK);
        CWeaponBoughtBackButton.setForeground (Color.YELLOW);
        CWeaponBoughtBackButton.setFocusable(false);
        CWeaponBoughtBackButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CWeaponBoughtBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CWeaponBoughtFrame.dispose();
            }   
        });
        CWeaponBoughtFrame.add (CWeaponBoughtBackButton);
    }
        /**
     * this method sets runes
     */
    public void setRunes (int nRunes){
        this.nRunes = nRunes;
    }
     /**
     * this method gets runes
     */
    public int getRunes (int nRunes){
        return nRunes; 
    }
     /**
     * this method checks sufficient runes
     */
    public boolean checkSufficientRunes (int nRunes, int nRuneCost)
    {
        if (nRunes >= nRuneCost)
        {
            return true;
        }
        else
        {
            return false; 
        }
    }
     /**
     * this method subtract runes
     */
    public int subtractRunes (int nRunes, int nRuneCost){

        return  nRunes - nRuneCost;
    }
     /**
     * this method gets purchased weapon list 
     */
    public ArrayList <String> getPurchasedWeaponList ()
    {
        return arrPurchasedWeapon;
    }
     /**
     * this method gets purchased weapon size
     */
    public int getPurchasedWeaponSize ()
    {
        return arrPurchasedWeapon.size();
    }
}

