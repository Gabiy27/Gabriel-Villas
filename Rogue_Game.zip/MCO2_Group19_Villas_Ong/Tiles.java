import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/** 
 * This is the tiles class
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class Tiles {
    /**
     * this field is for the frame
     */
    private JFrame CTreasureTileFrame; 
    /**
     * this field is for the frame
     */
    private JFrame CCreditsFrame; 
    /**
     * this field is for the frame
     */
    private JFrame CFastTravelPromptFrame; 
    /**
     * this field is for the label
     */
    private JLabel CTreasureRunesLabel;
      /**
     * this field is for the label
     */
    private JLabel CTreasureRunesTextLabel; 
      /**
     * this field is for the label
     */
    private JLabel CCreditsLabel; 
      /**
     * this field is for the Image
     */
    private ImageIcon CTreasureRunesImage; 
      /**
     * this field is for the image
     */
    private ImageIcon CCreditsImage;
      /**
     * this field is for the back button
     */
    private JButton CBackButton; 
      /**
     * this field is for the index area
     */
    private int nAreaIndex;
      /**
     * this field is for the treasure runes
     */
    private int nTreasureRunes; 
      /**
     * this field is for the label
     */
    private JLabel CFastTravelPromptLabel;
     /**
     * this field is for the treasue
     */
    private boolean bTreasure;
     /**
     * this field is for the name
     */
    protected String strName;
     /**
     * this field is for the player hp
     */
    protected int nPlayerHp;
    /** 
    * This field is for the player dexterity
    */
   protected int nPlayerDex;
    /** 
    * This field is for the player intelligence
    */
   protected int nPlayerInt;
    /** 
    * This field is for the player endurance
    */
   protected int nPlayerEnd;
    /** 
    * This field is for the strength
    */
   protected int nPlayerStr;
    /** 
    * This field is for the player faith
    */
   protected int nPlayerFth;
    /** 
    * This field is for the weapon hp
    */
   protected int nWeaponHp;
    /** 
    * This field is for the weapon dexterity
    */
   protected int nWeaponDex;
    /** 
    * This field is for the weapon intelligence
    */
   protected int nWeaponInt;
    /** 
    * This field is for the weapon endurance
    */
   protected int nWeaponEnd;
    /** 
    * This field is for the weapon strength
    */
   protected int nWeaponStr;
    /** 
    * This field is for the weapon faith
    */
   protected int nWeaponFth;
    /**
     * this field is for the runes
     */
    protected int nRunes;
     /** 
     * This constructor is for the area one
     * @param nAreaIndex for area index
     * @param strName for the name
     * @param nLevel for the level
     * @param nRunes for the runes
     * @param nPlayerHp for the player hp
     * @param nPlayerDex for the player dexterity 
     * @param nPlayerInt for the Player intelligence
     * @param nPlayerEnd for the player Endurance
     * @param nPlayerStr for the player strength
     * @param nPlayerFth for the player faith
     * @param nWeaponHp for the weapon hp
     * @param nWeaponDex for the weapon dexterity
     * @param nWeaponInt for the weapon intellgence
     * @param nWeaponEnd for the weapon endurance
     * @param nWeaponStr for the weapon strength 
     * @param nWeaponFth for the weapon faith
     */
    public Tiles (int nAreaIndex, String strName, int nRunes, int nPlayerHp, int nPlayerDex, int nPlayerInt, int nPlayerEnd, int nPlayerStr, int nPlayerFth, int nWeaponHp, int nWeaponDex, int nWeaponInt, int nWeaponEnd,int nWeaponStr, int nWeaponFth){
        CFastTravelPromptFrame = new JFrame();
        CTreasureTileFrame = new JFrame();
        CCreditsFrame = new JFrame();
        CTreasureRunesLabel = new JLabel();
        CTreasureRunesTextLabel = new JLabel(); 
        CFastTravelPromptLabel = new JLabel();
        CCreditsLabel = new JLabel ();
        CTreasureRunesImage = new ImageIcon("TreasureRunes.png");
        CCreditsImage = new ImageIcon("Credits.png");
        CBackButton = new JButton();
        this.nAreaIndex = nAreaIndex; 
        nTreasureRunes = 0;
        bTreasure = true;
        this.strName = strName;
        this.nRunes = nRunes;
        this.nPlayerHp = nPlayerHp;
        this.nPlayerDex = nPlayerDex;
        this.nPlayerInt = nPlayerInt;
        this.nPlayerEnd = nPlayerEnd;
        this.nPlayerStr = nPlayerStr;
        this.nPlayerFth = nPlayerFth;
        this.nWeaponHp = nWeaponHp;
        this.nWeaponDex = nWeaponDex;
        this.nWeaponInt= nWeaponInt;
        this.nWeaponEnd = nWeaponEnd;
        this.nWeaponStr = nWeaponStr;
        this.nWeaponFth = nWeaponFth;
    }
    /**
     * This  method is for the enemy class
     * @param CEnemy is for the enemy
     */
    public void openSpawnTile (Enemy CEnemy){
         // Random Enemy or Treasure
         int nSpawnRandNum;
         int nSpawnMinNum = 1; 
         int nSpawnMaxNum = 100; 
         // Random Enemy Type 
         int nSpawnEnemyMinNum = 1;
         int nSpawnEnemyMaxNum = 3; 
         int nSpawnEnemyRandNum = 0; 
         // Random Runes
        
         nSpawnRandNum = (int) Math.floor (Math.random() * (nSpawnMaxNum - nSpawnMinNum) + nSpawnMinNum); 

         if (nSpawnRandNum <= 75)
         {
            Battle CBattle = new Battle(CEnemy, nSpawnEnemyMinNum, nSpawnEnemyMaxNum, nSpawnEnemyRandNum, nAreaIndex, strName, nRunes, nPlayerHp, nPlayerDex, nPlayerInt, nPlayerEnd, nPlayerStr, nPlayerFth, nWeaponHp, nWeaponDex, nWeaponInt, nWeaponEnd, nWeaponStr, nWeaponFth);
            CBattle.OpenEnemyBattle();
            System.out.println ("Battle Runes" + CBattle.getRunes());
            nRunes += CBattle.getRunes();
         }
         else if (nSpawnRandNum > 75)
         {
           openTreasureRunesFrame();
         }

    }
    /**
     * this method opens treasure runes frame
     */
    public void openTreasureRunesFrame (){
        int nRuneMin = 50;
        int nRuneMax = 150; 
        int nRuneRandNum = 0; 
        CTreasureTileFrame.setSize (1000, 700);
        CTreasureTileFrame.setTitle("Spawn Tile");
        CTreasureTileFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CTreasureTileFrame.setLayout(null);
        CTreasureTileFrame.getContentPane().setBackground(Color.BLACK);
        spawnTreasure(nRuneMin, nRuneMax, nRuneRandNum, nTreasureRunes);
        setTreasureBoolean(true);
        CTreasureTileFrame.setVisible(true);
    }
     /**
     * this method spawns treasure
     */
    public void spawnTreasure (int nRuneMin, int nRuneMax, int nRuneRandNum, int nTreasureRunes){
        nRuneRandNum = (int) Math.floor (Math.random() * (nRuneMax - nRuneMin) + nRuneMin);
        nTreasureRunes = computeTreasure(nRuneRandNum, nAreaIndex);
        displayTreasureRunes(nTreasureRunes);
        setTreasureRunes(nTreasureRunes);
        displayTreasureBackButton();
    }
    /**
     * this method opens boss tile
     */
     public void openBossTile (int nAreaIndex) {
        Battle CBattle = new Battle(nAreaIndex, strName, nRunes, nPlayerHp, nPlayerDex, nPlayerInt, nPlayerEnd, nPlayerStr, nPlayerFth, nWeaponHp, nWeaponDex, nWeaponInt, nWeaponEnd, nWeaponStr, nWeaponFth);
        CBattle.openBossBattle();
    }
    /**
     * this method opens credits frame
     */
    public void openCreditsTileFrame (){
        CCreditsFrame.setSize (1000, 700);
        CCreditsFrame.setTitle("Credits.png");
        CCreditsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CCreditsFrame.setLayout(null);
        CCreditsFrame.getContentPane().setBackground(Color.BLACK);
        openCreditsTile();
        CCreditsFrame.setVisible(true);
    }
    /**
     * this method opens credits tile 
     */
    public void openCreditsTile (){
        CCreditsLabel.setIcon(CCreditsImage);
        CCreditsLabel.setVerticalAlignment(JLabel.TOP);
        CCreditsLabel.setHorizontalAlignment(JLabel.CENTER);
        CCreditsLabel.setBounds(200,100, 550, 550);
        CCreditsFrame.add(CCreditsLabel);
    }
  
     /** 
     * This method computes treasure
     * @param num is for the number
     * @param index is for the index
     */
    public int computeTreasure (int num, int index){
        return num * index;
    }
     /** 
     * This method displays Tile Used
     */
    public void displayTileUsed ()
    {
    }
    /** 
     * This method set Runes
     */
    public void setTreasureRunes (int nTreasureRunes){
        this.nTreasureRunes = nTreasureRunes;
    }
    /** 
     * This method gets the Treasure Runes
     */
    public int getTreasureRunes (){
        return nTreasureRunes;
    }
    /**
     * this method sets treasure boolean
     */
    public void setTreasureBoolean (boolean bTreasure) {
        this.bTreasure= bTreasure;
    }
    /**
     * this method gets treasure boolean
     */
    public boolean getTreasureboolean ()
    {
        return bTreasure;
    }
    /**
     * this method gets treasure boolean
     */
    public void displayTreasureRunes (int nTreasureRunes){
        CTreasureRunesLabel.setIcon(CTreasureRunesImage);
        CTreasureRunesLabel.setVerticalAlignment(JLabel.TOP);
        CTreasureRunesLabel.setHorizontalAlignment(JLabel.CENTER);
        CTreasureRunesLabel.setBounds(200,100, 550, 400);
        CTreasureRunesTextLabel.setText("Runes Found [" + nTreasureRunes + "]");
        CTreasureRunesTextLabel.setVerticalAlignment(JLabel.BOTTOM);
        CTreasureRunesTextLabel.setHorizontalAlignment(JLabel.CENTER);
        CTreasureRunesTextLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CTreasureRunesTextLabel.setForeground(Color.YELLOW);
        CTreasureRunesTextLabel.setBounds(250, 250, 440, 300);
        CTreasureTileFrame.add(CTreasureRunesLabel);
        CTreasureTileFrame.add(CTreasureRunesTextLabel);
    }
    /**
     * this method displays button
     */
    public void displayTreasureBackButton (){
        CBackButton.setBounds(400, 600, 100, 50);
        CBackButton.setText("Back");
        CBackButton.setBackground(Color.BLACK);
        CBackButton.setForeground (Color.YELLOW);
        CBackButton.setFocusable(false);
        CBackButton.setFont (new Font ("Caveat", Font.BOLD, 15));
        CBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               CTreasureTileFrame.dispose();
            }
        });
        CTreasureTileFrame.add (CBackButton);
    }
     /**
     * this method checks fast travel
     */
    public boolean checkFastTravel (boolean bBossAlive){
        if (bBossAlive == true)
        {
            displayFastTravelPromptFrame();
            return false;
        }
        else
        {
            return true;
        }
    }
     /**
     * this method displays frame
     */
    public void displayFastTravelPromptFrame (){
            CFastTravelPromptFrame.setSize (600, 400);
            CFastTravelPromptFrame.setTitle("Spawn Tile");
            CFastTravelPromptFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            CFastTravelPromptFrame.setLayout(null);
            CFastTravelPromptFrame.getContentPane().setBackground(Color.BLACK);
            displayFastTravelPrompt();
            CFastTravelPromptFrame.setVisible(true);
    }
     /**
     * this method displays prompt
     */
    public void displayFastTravelPrompt (){
        CFastTravelPromptLabel.setText("LOCKED ! [TO UNLOCK DEFEAT THE BOSS !]");
        CFastTravelPromptLabel.setHorizontalAlignment(JLabel.CENTER);
        CFastTravelPromptLabel.setVerticalAlignment(JLabel.BOTTOM);
        CFastTravelPromptLabel.setBounds(50, 50, 500, 200);
        CFastTravelPromptLabel.setFont(new Font ("Consolas", Font.PLAIN, 20));
        CFastTravelPromptLabel.setForeground(Color.RED);
        CFastTravelPromptFrame.add ( CFastTravelPromptLabel);  
    }
     /**
     * this method checks active tile
     */
    public boolean checkActiveTile (boolean bActiveTiles)
    {
        if (bActiveTiles == true)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
     /**
     * this method get runes
     */
    public int getRunes ()
    {
        return nRunes; 
    }
}
