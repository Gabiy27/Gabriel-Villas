/** 
 * This is the player class
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class Player {
    /**
     * this field is for name
     */
    private String strPlayerName;
    /**
     * this field is for player health
     */
    private int nPlayerMaxHealth;
    /**
     * this field is for stat health
     */
    private int nStatHealth;
    /**
     * this field is for stat endurance
     */
    private int nStatEndurance;
    /**
     * this field is for weapon endurance
     */
    private int nWeaponEndurance;
    /**
     * this field is for the weapon health
     */
    private int nWeaponHealth;
    /**
     * this field is for stat strength
     */
    private int nStatStrength;
    /**
     * this field is for weapon strength 
     */
    private int nWeaponStrength;
    /**
     * this field is for stat intelligence
     */
    private int nStatInt;
    /**
     * this field is for weapon intelligence
     */
    private int nWeaponInt;
    /**
     * this field is for stat faoth
     */
    private int nStatFaith;
    /**
     * this field is for weapon faith
     */
    private int nWeaponFaith;
    /**
     * this field is for runes
     */
    private int nRunes; 
    /**
     * this constructor is for the player
     * @param strPlayerName player name
     * @param nStatHealth for the player hp
     * @param nStatDexterity for the player dexterity 
     * @param nStatIntelligence for the Player intelligence
     * @param nStatEndurance for the player Endurance
     * @param nStatStrength for the player strength
     * @param nStatFaith for the player faith
     * @param nWeaponHealth for the weapon hp
     * @param nWeaponDexterity for the weapon dexterity
     * @param nWeaponIntelligence for the weapon intellgence
     * @param nWeaponEndurance for the weapon endurance
     * @param nWeaponStrength for the weapon strength 
     * @param nWeaponFaith for the weapon faith
     */
    public Player (String strPlayerName, int nStatEndurance, int nWeaponEndurance, int nStatHealth, int nWeaponHealth, int nStatStrength, int nWeaponStrength, int nStatInt, int nWeaponInt, int nStatFaith, int nWeaponFaith, int nRunes) {
        this.strPlayerName = strPlayerName; 
        this.nStatEndurance = nStatEndurance;
        this.nWeaponEndurance = nWeaponEndurance;
        this.nStatHealth = nStatHealth;
        this.nWeaponHealth = nWeaponHealth;
        this.nStatStrength = nStatStrength;
        this.nWeaponStrength = nWeaponStrength;
        this.nStatInt = nStatInt;
        this.nWeaponInt = nWeaponInt;
        this.nStatFaith = nStatFaith;
        this.nWeaponFaith = nWeaponFaith; 
        this.nRunes = nRunes;
    }

    /**
     * this method is for the setter
     * @param strPlayerName
     */
    public void setPlayerName (String strPlayerName)
    {
        this.strPlayerName = strPlayerName;
    }
    /** 
     *this method is for the getters
     */
    public String getPlayerName ()
    {
        return strPlayerName;
    }
    /**
     * this method is for the setter
     * @param nPlayerMaxHealth for the player max health
     */
    public void setPlayerMaxHealth (int nPlayerMaxHealth)
    {
        this.nPlayerMaxHealth = nPlayerMaxHealth;
    }
      /**
     * this method is for the getter
     */
    public int getPlayerMaxHealth ()
    {
       return nPlayerMaxHealth;
    }
    /**
     * this method is for the setter
     * @param statHealth
     */
    public void setPlayerHealth (int nStatHealth){
        this.nStatHealth = nStatHealth;
    }
    /**
     * This method is for the runes
     * @param nRunes
     */
    public void setRunes (int nRunes)
    {
        this.nRunes = nRunes;
    }
     /**
     * this method is for the getter
     */
    public int getRunes ()
    {
        return nRunes; 
    }
     /**
     * this method is for the getter
     */
    public int getPlayerHealth (){
        return nStatHealth;
    }
     /**
     * this method is for the getter
     */
    public int getPlayerEndurance (){
        return nStatEndurance;
    }
     /**
     * this method is for the getter
     */
    public int getPlayerStrength (){
        return nStatStrength;
    }
     /**
     * this method is for the getter
     */
    public int getPlayerIntelligence (){
        return nStatInt;
    }
     /**
     * this method is for the getter
     */
    public int getPlayerFaith (){
        return nStatFaith;
    }
     /**
     * this method is for the getter
     */
    public int getWeaponHealth (){
        return nWeaponHealth;
    }
     /**
     * this method is for the getter
     */
    public int getWeaponStrength (){
        return nWeaponStrength;
    }
     /**
     * this method is for the getter
     */
    public int getWeaponEndurance (){
        return nWeaponEndurance;
    }
     /**
     * this method is for the getter
     */
    public int getWeaponIntelligence (){
        return nWeaponInt;
    }
     /**
     * this method is for the getter
     */
    public int getWeaponFaith (){
        return nWeaponFaith;
    }

}
