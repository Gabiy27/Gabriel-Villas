import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/** 
 * This is the class where the application will run
 * 
 * @author Daniel Ryan Baysa Ong
 * @author Gabriel Navoa Villas
 * @version %I%, %G%
 * @since 1.0
 */
public class TitleScreen {
    // GUI Fields
    /** 
     * This field is for the title screen frame
     */
    private JFrame CTitleScreenFrame;
    /** 
     * This field is for the title screen image
     */
    private ImageIcon CTitleImage;
    /** 
     * This field is for the start image
     */
    private ImageIcon CStartImage;
    /** 
     * This field is for the start image
     */
    private ImageIcon CExitImage;
    /** 
     * This field is for the title screen label
     */
    private JLabel CTitleScreenLabel;
    /** 
     * This field is for the start button
     */
    private JButton CStartButton;
    /** 
     * This field is for the exit button
     */
    private JButton CExitButton;  
    /** 
     * This constructor is for the title screen
     */
    public TitleScreen (){
        this.CTitleScreenFrame = new JFrame ();
        this.CTitleImage = new ImageIcon("GameTitle.PNG"); 
        this.CStartImage = new ImageIcon("Start.png");
        this.CExitImage = new ImageIcon("Exit.png");
        this.CTitleScreenLabel = new JLabel ();
        this.CStartButton = new JButton(); 
        this.CExitButton = new JButton();
    }
    /** 
     * This method opens the title screens
     */
    public void openTitleScreen (){
        displayStartButton();
        displayExitButton();
        displayTitleImage();
        displayTitleScreenFrame();
        CTitleScreenLabel.setLayout(null);
        CTitleScreenFrame.setVisible (true); 
    }
    /** 
     * This method displays title screen frame
     */
    public void displayTitleScreenFrame (){
        CTitleScreenFrame.setSize (600, 500);
        CTitleScreenFrame.setTitle("VILLAS_ONG_MCO2");
        CTitleScreenFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CTitleScreenFrame.getContentPane().setBackground(Color.BLACK);
    }

    /** 
     * This method displays title screen image
     */
    public void displayTitleImage (){
        CTitleScreenLabel.setIcon(CTitleImage);
         CTitleScreenLabel.setHorizontalAlignment(JLabel.CENTER);
        CTitleScreenFrame.add(CTitleScreenLabel);
    }

    /** 
     * This method displays start button
     */
    public void displayStartButton (){
        CStartButton.setBounds(100, 300, 150, 100);
        CStartButton.setIcon(CStartImage);
        CStartButton.setFocusable(false);
        CStartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CharacterCreation CharacterCreation = new CharacterCreation();
                CharacterCreation.openCharacterCreation();
                CTitleScreenFrame.setVisible (false);
                
            }
        });
        CTitleScreenFrame.add (CStartButton);
    }
    /** 
     * This method displays exit button
     */
    public void displayExitButton (){
        CExitButton.setBounds(300, 300, 150, 100);
        CExitButton.setIcon (CExitImage);
        CExitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // ExitButton.
                System.exit(0);
            }
        });
        CTitleScreenFrame.add (CExitButton);
    }

    
}
